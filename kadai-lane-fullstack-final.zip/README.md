# Kadai Lane — Modern Indian Kitchen in Pune

> **A Full-Stack Restaurant Web Application built with React.js, Node.js, Express.js, and MongoDB (MERN Stack)**  
> *Designed for 2nd-Year B.Tech Computer Science & Engineering Capstone Project*

---

## 📖 1. Project Overview

**Kadai Lane — Modern Indian Kitchen in Pune** is a complete, genuine full-stack restaurant web application developed to replace static HTML restaurant prototypes with an end-to-end operational platform. 

It preserves the original visual identity, typography (Fraunces & DM Sans), Pune Koregaon Park culinary heritage, and color palette of Kadai Lane while adding:
- **Authentication & Security:** Customer signup, login, JWT authentication with secure HTTP-only cookies and bcrypt password hashing.
- **Dynamic Food Catalogue:** Full MongoDB-backed menu with categories (Starters, Mains, Breads, Rice, Desserts, Drinks), veg/non-veg dietary markers, search, sorting, and availability flags.
- **Food Ordering Journey:** Persistent shopping cart, server-side price validation, GST and delivery calculation, offline payment workflows (Cash on Delivery & Counter Pickup), unique `#KL-ORD-...` references, and live order status tracking (Pending → Confirmed → Preparing → Out for Delivery → Delivered).
- **Table Reservation System:** Real-time slot availability checking, guest capacity protection (prevents overbooking), seating selection (Indoor vs Terrace), and cancellation management.
- **Customer & Administrator Dashboards:** Customer self-service dashboard for orders/reservations and a protected Admin Portal for menu CRUD, live kitchen status transitions, and booking schedules.

---

## 🛠️ 2. Technology Stack

| Layer | Technologies Used |
| :--- | :--- |
| **Frontend** | React 18, Vite 5, React Router DOM 6, Lucide React Icons, HTML5, CSS3, Fetch API |
| **Backend** | Node.js (v20+ LTS), Express.js 4, REST API Architecture, CORS, Cookie-Parser, Dotenv |
| **Database** | MongoDB, Mongoose 8 (ODM), MongoDB Compass (GUI) |
| **Security** | bcryptjs (Salt rounds: 10), JSON Web Tokens (JWT), Ownership Validation Middleware |

---

## 📁 3. Folder Structure

```text
kadai-lane/
│
├── client/                              # React + Vite Frontend
│   ├── public/
│   │   └── images/                      # Authentic restaurant food imagery
│   ├── src/
│   │   ├── components/
│   │   │   └── common/                  # Navbar, Footer, DishCard, DishModal, ProtectedRoute
│   │   ├── context/                     # AuthContext, CartContext, ThemeContext
│   │   ├── pages/                       # Home, Menu, Cart, Checkout, Reserve, About, Contact
│   │   │   └── admin/                   # AdminMenuPage, AdminOrdersPage, AdminReservationsPage
│   │   ├── services/                    # api.js client, imageUtils.js
│   │   ├── styles/                      # Global theme tokens, typography, dark/light modes
│   │   ├── App.jsx                      # Route definitions
│   │   └── main.jsx                     # Application entry point
│   ├── package.json
│   ├── vite.config.js
│   └── index.html
│
├── server/                              # Node.js + Express + Mongoose Backend
│   ├── src/
│   │   ├── config/                      # db.js (MongoDB connection), constants.js
│   │   ├── controllers/                 # auth, menu, order, reservation, contact, admin
│   │   ├── middleware/                  # auth.js (JWT & Role check), error.js (Error Handler)
│   │   ├── models/                      # User, MenuItem, Order, Reservation, Contact
│   │   ├── routes/                      # auth, menu, order, reservation, contact, admin
│   │   ├── utils/                       # generateToken.js, referenceGenerator.js
│   │   ├── app.js                       # Express app configuration & middleware mounts
│   │   └── server.js                    # Port listener & background DB connector
│   ├── scripts/
│   │   ├── seed.js                      # Menu database seeder (all 31 authentic dishes)
│   │   ├── createAdmin.js               # Safe administrator creation script
│   │   └── testSuite.js                 # Automated unit and integration test runner
│   ├── package.json
│   ├── .env.example
│   └── .env
│
├── package.json                         # Root convenience scripts
├── .gitignore
└── README.md
```

---

## ⚙️ 4. Prerequisites (Windows)

1. **Node.js (v20+ LTS):** Installed and available in your PowerShell path. (Verified at `C:\Users\GAURI\.gemini\antigravity\scratch\nodejs`).
2. **MongoDB Community Server (or MongoDB Atlas):**
   - Free download: [MongoDB Community Server](https://www.mongodb.com/try/download/community)
   - Default local connection: `mongodb://127.0.0.1:27017/kadai_lane`
3. **MongoDB Compass:**
   - Free GUI interface for inspecting documents, collections, and indexes: [Download MongoDB Compass](https://www.mongodb.com/products/tools/compass)

---

## 🚀 5. Quick Setup & Run Instructions

Open **Windows PowerShell** and navigate to the project directory:

```powershell
cd C:\Users\GAURI\.gemini\antigravity\scratch\kadai-lane
```

### Step 1: Install Dependencies
```powershell
# Install root, backend and frontend dependencies
npm --prefix server install
npm --prefix client install
```

### Step 2: Configure Environment Variables
Verify or adjust `server/.env`:
```env
PORT=5000
MONGODB_URI=mongodb://127.0.0.1:27017/kadai_lane
JWT_SECRET=kadai_lane_super_secret_jwt_key_2026_btech_project
JWT_EXPIRES_IN=7d
CLIENT_URL=http://localhost:5173
NODE_ENV=development
```

### Step 3: Seed Database and Create Administrator
Make sure MongoDB is running, then execute:
```powershell
# 1. Populate all 31 restaurant dishes (Idempotent: safe to run multiple times)
npm run seed

# 2. Create the default master administrator
npm run create-admin
```

> **Default Admin Credentials:**  
> - **Email:** `admin@kadailane.in`  
> - **Password:** `Admin@12345`  
> *(You can also use the one-click "Admin Demo" fill button on the `/login` screen)*

### Step 4: Start Backend and Frontend

Open **two terminal windows**:

**Terminal 1 (Backend API Server):**
```powershell
cd C:\Users\GAURI\.gemini\antigravity\scratch\kadai-lane\server
npm run dev
# Server runs at http://localhost:5000
```

**Terminal 2 (React Frontend with Vite):**
```powershell
cd C:\Users\GAURI\.gemini\antigravity\scratch\kadai-lane\client
npm run dev
# Client runs at http://localhost:5173
```

Open **`http://localhost:5173`** in your browser.

---

## 🔍 6. MongoDB Compass Inspection Guide

1. Open **MongoDB Compass**.
2. In the "New Connection" screen, enter the URI:
   ```text
   mongodb://127.0.0.1:27017
   ```
3. Click **Connect**.
4. You will see the database **`kadai_lane`**. Click on it to inspect the collections:
   - **`menuitems`**: View all 31 dishes, categories, prices, and availability flags.
   - **`users`**: Inspect registered customer accounts and administrator records (passwords are safely hashed with bcrypt).
   - **`orders`**: Review placed orders, ordered item snapshots, delivery addresses, order numbers, and live status history.
   - **`reservations`**: Review customer table bookings, date, time slots, guest counts, and status.
   - **`contacts`**: View customer inquiry submissions.

---

## 🧪 7. Automated Testing

Run the included automated test suite anytime using:
```powershell
cd C:\Users\GAURI\.gemini\antigravity\scratch\kadai-lane\server
npm test
```

**Included Tests (11/11 Passed):**
1. Unique order number generation (`KL-ORD-YYYYMMDD-XXXX`)
2. Unique reservation reference generation (`KL-RES-YYYYMMDD-XXXX`)
3. 5% GST calculation validation
4. Delivery fee rules (Free above ₹500, ₹40 below)
5. Reservation party size boundaries (1 to 8 guests)
6. Order status transitions from `Pending`
7. Order status transitions from `Confirmed`
8. Order status transitions from `Preparing`
9. Terminal order status immutability (`Delivered` & `Cancelled`)
10. Password hashing & verification with `bcrypt`

---

## 🌐 8. Complete REST API Reference

### Health & Information
- `GET /api/health` — Backend server & DB connection status
- `GET /api/restaurant/info` — Operating hours, address, and financial rules

### Authentication (`/api/auth`)
- `POST /api/auth/register` — Register a customer account
- `POST /api/auth/login` — Login & receive JWT in HTTP-only cookie and JSON response
- `POST /api/auth/logout` — Clear session cookie
- `GET /api/auth/me` — Get authenticated user profile *(Private)*
- `PUT /api/auth/profile` — Update address, phone or password *(Private)*

### Menu (`/api/menu`)
- `GET /api/menu` — List available dishes (supports `?category=`, `?veg=`, `?search=`, `?popular=`)
- `GET /api/menu/:id` — Get single dish details
- `POST /api/menu` — Add new dish *(Admin only)*
- `PUT /api/menu/:id` — Update dish details & price *(Admin only)*
- `PATCH /api/menu/:id/availability` — Toggle between Available / Sold Out *(Admin only)*
- `DELETE /api/menu/:id` — Delete dish *(Admin only)*

### Orders (`/api/orders`)
- `POST /api/orders` — Create order with server-side pricing & availability check *(Customer)*
- `GET /api/orders/my-orders` — Get customer's order history *(Customer)*
- `GET /api/orders/:id` — Get order details with ownership verification *(Owner or Admin)*
- `PATCH /api/orders/:id/cancel` — Cancel pending/confirmed order *(Customer or Admin)*
- `GET /api/orders/admin/all` — List all orders with filters *(Admin only)*
- `PATCH /api/orders/admin/:id/status` — Advance order status or update payment *(Admin only)*

### Table Reservations (`/api/reservations`)
- `GET /api/reservations/availability?date=YYYY-MM-DD` — Check available slots & remaining seats
- `POST /api/reservations` — Submit table reservation with capacity validation
- `GET /api/reservations/my/all` — Get authenticated user's reservations *(Customer)*
- `PATCH /api/reservations/:id/cancel` — Cancel eligible reservation *(Customer or Admin)*
- `GET /api/reservations/admin/all` — List all reservations *(Admin only)*
- `PATCH /api/reservations/admin/:id/status` — Confirm or complete reservation *(Admin only)*

### Inquiries & Admin Stats
- `POST /api/contact` — Submit customer inquiry message
- `GET /api/admin/stats` — Real-time revenue, active orders, today's tables, catalog stats *(Admin only)*

---

## 🎓 9. College Viva & Examination Guide

### Q1: What problem does Kadai Lane solve?
**Answer:** It replaces static restaurant websites with a dynamic full-stack platform where customers can browse live inventory, register accounts, order food with guaranteed price integrity, reserve dining tables against real capacity limits, and receive real-time order tracking, while restaurant staff can administer menus, orders, and reservations from a secure portal.

### Q2: Why is React used on the frontend instead of vanilla HTML/JS?
**Answer:** React provides component-based architecture, virtual DOM for performant UI updates, and centralized state management (via Context API for Cart, Authentication, and Theme). This prevents messy DOM manipulation, maintains the shopping cart across page navigations, and keeps UI views in sync with server data.

### Q3: What do Node.js and Express.js do?
**Answer:** Node.js executes JavaScript on the server. Express.js is a minimalist web framework providing routing, middleware pipelines (body parsing, cookie handling, CORS), REST API controllers, and centralized error handling.

### Q4: What role do MongoDB and Mongoose play?
**Answer:** MongoDB is a NoSQL document database storing structured BSON documents without rigid schema migrations. Mongoose is an Object Data Modeling (ODM) library providing schema validation, type casting, query middleware, and pre-save hooks (e.g., hashing passwords with bcrypt).

### Q5: How does an order travel from the shopping cart to MongoDB?
**Answer:**
1. Customer reviews items in the React `CartContext` and clicks "Place Order" on `/checkout`.
2. The browser sends a `POST` request with the dish IDs and quantities to `/api/orders`.
3. The Express `protect` middleware verifies the customer's JWT token.
4. The controller looks up each dish in the MongoDB `MenuItem` collection to verify existence and availability (`isAvailable: true`).
5. The backend calculates subtotal using live database prices (never trusting client-side prices), calculates 5% GST and delivery fee, and generates a unique `#KL-ORD-...` reference.
6. An `Order` document is saved in MongoDB.
7. The server responds with `201 Created`, the React cart is cleared, and the customer is redirected to the live tracking page.

### Q6: How does the table reservation system prevent overbooking?
**Answer:** The restaurant defines a maximum seat capacity per time slot (e.g., 30 guests). When a booking is submitted, the backend aggregates all active bookings for that date and time slot. If `existing_guests + requested_guests > slot_capacity`, the booking is rejected with a message asking the customer to pick an adjacent slot.

### Q7: How is authentication and admin security handled?
**Answer:** Passwords are never stored in plaintext; they are salted and hashed using `bcrypt` (10 rounds). On login, the server issues a signed JWT token containing the user ID and role, stored in an HTTP-only cookie. Administrative endpoints use `adminOnly` middleware that verifies `req.user.role === 'admin'`. Normal users cannot elevate their role or alter another customer's orders.

---

## 👨‍💻 10. Live Demonstration Script for Evaluators

1. **Homepage:** Show the responsive hero section, Pune Koregaon Park tagline, dark/light theme toggle, and the "Most Ordered This Week" section dynamically fetched from MongoDB.
2. **Menu Catalog:** Open `/menu`, search for "misal" or "biryani", toggle the "Veg Only" switch, filter by category, and click "Details" to show the rich dish modal with spice levels and preparation times.
3. **Ordering:** Add 2 dishes to cart, open `/cart`, demonstrate increasing/decreasing quantity and dynamic free delivery bar (above ₹500), then proceed to `/checkout`.
4. **Authentication:** Log in as a customer (or use the one-click demo button) and place the order with "Cash on Delivery". Show the resulting `#KL-ORD-...` screen with the stepper.
5. **Table Reservation:** Open `/reserve`, select today's date, choose a time slot showing live available capacity, select terrace seating, and submit to receive `#KL-RES-...`.
6. **Customer Dashboard:** Navigate to `/dashboard` to see your active order and table booking.
7. **Admin Portal:** Log in as `admin@kadailane.in` (Password: `Admin@12345`), open `/admin`, demonstrate the live revenue metrics, update the order status through permitted transitions (Confirmed → Preparing → Out for Delivery → Delivered), and toggle a dish's availability in `/admin/menu`.
8. **MongoDB Compass:** Switch to Compass and show the saved documents in `orders`, `reservations`, `menuitems`, and `users`.
