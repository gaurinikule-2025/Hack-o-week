import React from 'react';
import { useCart } from '../../context/CartContext';
import { handleImageError, generateDishSvg } from '../../services/imageUtils';
import { Plus, Minus, Info } from 'lucide-react';

export const DishCard = ({ dish, onQuickView }) => {
  const { cart, addToCart, updateQuantity } = useCart();

  const cartItem = cart.find((item) => item._id === dish._id);
  const qty = cartItem ? cartItem.quantity : 0;

  const imgSrc = dish.image && dish.image.trim() !== ''
    ? dish.image
    : generateDishSvg(dish);

  return (
    <article className="dish-card">
      <div className="dish-img-wrap" onClick={() => onQuickView && onQuickView(dish)} style={{ cursor: 'pointer' }}>
        <img
          src={imgSrc}
          alt={dish.name}
          className="dish-img"
          onError={(e) => handleImageError(e, dish)}
          loading="lazy"
        />

        {dish.isPopular && (
          <span
            className="badge saffron"
            style={{ position: 'absolute', top: '10px', left: '10px' }}
          >
            ★ Most Ordered
          </span>
        )}

        {!dish.isAvailable && (
          <div
            style={{
              position: 'absolute',
              inset: 0,
              background: 'rgba(0, 0, 0, 0.6)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#ffffff',
              fontWeight: 800,
              fontSize: '1rem',
              letterSpacing: '0.05em',
            }}
          >
            SOLD OUT
          </div>
        )}

        {/* Quick View Pill */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onQuickView && onQuickView(dish);
          }}
          className="btn sm alt"
          style={{
            position: 'absolute',
            bottom: '8px',
            right: '8px',
            padding: '0.25rem 0.6rem',
            background: 'var(--surface)',
            fontSize: '0.78rem',
            opacity: 0.9,
          }}
          aria-label={`View details for ${dish.name}`}
        >
          <Info size={13} /> Details
        </button>
      </div>

      <div className="body">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span className={`diet ${dish.isVeg ? 'veg' : 'nv'}`}>
            {dish.isVeg ? 'Vegetarian' : 'Non-veg'}
          </span>
          <span style={{ fontSize: '0.8rem', color: 'var(--muted)', fontWeight: 600 }}>
            {dish.category}
          </span>
        </div>

        <h3
          onClick={() => onQuickView && onQuickView(dish)}
          style={{ cursor: 'pointer', margin: '0.2rem 0' }}
        >
          {dish.name}
        </h3>

        <p>{dish.description}</p>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 'auto', paddingTop: '0.75rem' }}>
          <span className="price">₹{dish.price}</span>

          {dish.isAvailable ? (
            qty === 0 ? (
              <button
                type="button"
                className="btn sm"
                onClick={() => addToCart(dish, 1)}
                style={{ padding: '0.4rem 0.9rem' }}
              >
                <Plus size={15} /> Add
              </button>
            ) : (
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  background: 'var(--soft)',
                  borderRadius: '999px',
                  border: '1px solid var(--green)',
                  overflow: 'hidden',
                }}
              >
                <button
                  type="button"
                  onClick={() => updateQuantity(dish._id, qty - 1)}
                  style={{
                    background: 'none',
                    border: 'none',
                    padding: '0.35rem 0.6rem',
                    cursor: 'pointer',
                    color: 'var(--ink)',
                    display: 'flex',
                    alignItems: 'center',
                  }}
                  aria-label="Decrease quantity"
                >
                  <Minus size={14} />
                </button>
                <span style={{ fontWeight: 800, minWidth: '22px', textAlign: 'center', fontSize: '0.9rem' }}>
                  {qty}
                </span>
                <button
                  type="button"
                  onClick={() => updateQuantity(dish._id, qty + 1)}
                  style={{
                    background: 'none',
                    border: 'none',
                    padding: '0.35rem 0.6rem',
                    cursor: 'pointer',
                    color: 'var(--ink)',
                    display: 'flex',
                    alignItems: 'center',
                  }}
                  aria-label="Increase quantity"
                >
                  <Plus size={14} />
                </button>
              </div>
            )
          ) : (
            <button type="button" className="btn sm alt" disabled>
              Unavailable
            </button>
          )}
        </div>
      </div>
    </article>
  );
};
