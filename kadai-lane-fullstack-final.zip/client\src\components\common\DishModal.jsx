import React, { useState } from 'react';
import { useCart } from '../../context/CartContext';
import { handleImageError, generateDishSvg } from '../../services/imageUtils';
import { X, Plus, Minus, Clock, Flame, ShieldCheck } from 'lucide-react';

export const DishModal = ({ dish, onClose }) => {
  const { cart, addToCart } = useCart();
  const [qty, setQty] = useState(1);

  if (!dish) return null;

  const imgSrc = dish.image && dish.image.trim() !== ''
    ? dish.image
    : generateDishSvg(dish);

  const handleAdd = () => {
    addToCart(dish, qty);
    onClose();
  };

  return (
    <div className="modal-overlay" onClick={onClose} role="dialog" aria-modal="true">
      <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '580px', padding: 0 }}>
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          style={{
            position: 'absolute',
            top: '12px',
            right: '12px',
            background: 'var(--surface)',
            border: '1px solid var(--line)',
            borderRadius: '50%',
            width: '32px',
            height: '32px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            zIndex: 10,
          }}
          aria-label="Close dialog"
        >
          <X size={18} />
        </button>

        {/* Dish Image */}
        <div style={{ position: 'relative', width: '100%', height: '260px', overflow: 'hidden' }}>
          <img
            src={imgSrc}
            alt={dish.name}
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
            onError={(e) => handleImageError(e, dish)}
          />
          <div style={{ position: 'absolute', bottom: '12px', left: '16px' }}>
            <span className={`diet ${dish.isVeg ? 'veg' : 'nv'}`} style={{ background: 'var(--surface)', padding: '0.2rem 0.6rem', borderRadius: '999px' }}>
              {dish.isVeg ? 'Vegetarian' : 'Non-veg'}
            </span>
          </div>
        </div>

        {/* Modal Body */}
        <div style={{ padding: '1.5rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: '1rem', marginBottom: '0.5rem' }}>
            <h2 style={{ fontSize: '1.6rem' }}>{dish.name}</h2>
            <span className="price" style={{ fontSize: '1.5rem', color: 'var(--green)' }}>₹{dish.price}</span>
          </div>

          <p style={{ color: 'var(--muted)', fontSize: '0.98rem', lineHeight: 1.6, margin: '0 0 1.25rem' }}>
            {dish.description}
          </p>

          {/* Quick Specs */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', padding: '0.85rem 1rem', background: 'var(--soft)', borderRadius: '12px', marginBottom: '1.5rem', fontSize: '0.88rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <Clock size={16} color="var(--green)" />
              <span>Prep: <b>{dish.prepTime || '15 mins'}</b></span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <Flame size={16} color="var(--chili)" />
              <span>Spice: <b>{dish.spiceLevel || 'Medium'}</b></span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <ShieldCheck size={16} color="var(--green)" />
              <span>Separate Kitchen</span>
            </div>
          </div>

          {/* Tags */}
          {dish.tags && dish.tags.length > 0 && (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem', marginBottom: '1.5rem' }}>
              {dish.tags.map((tag, i) => (
                <span key={i} className="badge gray" style={{ fontSize: '0.75rem' }}>
                  #{tag}
                </span>
              ))}
            </div>
          )}

          {/* Add to Cart Actions */}
          {dish.isAvailable ? (
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  background: 'var(--bg)',
                  border: '2px solid var(--line)',
                  borderRadius: '10px',
                  overflow: 'hidden',
                }}
              >
                <button
                  type="button"
                  onClick={() => setQty((q) => Math.max(1, q - 1))}
                  style={{ background: 'none', border: 'none', padding: '0.6rem 0.85rem', cursor: 'pointer' }}
                >
                  <Minus size={16} />
                </button>
                <span style={{ fontWeight: 800, padding: '0 0.5rem', fontSize: '1.05rem', minWidth: '30px', textAlign: 'center' }}>
                  {qty}
                </span>
                <button
                  type="button"
                  onClick={() => setQty((q) => q + 1)}
                  style={{ background: 'none', border: 'none', padding: '0.6rem 0.85rem', cursor: 'pointer' }}
                >
                  <Plus size={16} />
                </button>
              </div>

              <button
                type="button"
                className="btn full"
                onClick={handleAdd}
                style={{ flex: 1, padding: '0.75rem' }}
              >
                Add {qty} to Cart • ₹{dish.price * qty}
              </button>
            </div>
          ) : (
            <div className="alert error" style={{ margin: 0, justifyContent: 'center' }}>
              This item is currently sold out and unavailable for order.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
