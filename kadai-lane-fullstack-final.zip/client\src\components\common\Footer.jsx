import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Phone, Mail, Clock, ShieldCheck, Heart } from 'lucide-react';

export const Footer = () => {
  return (
    <footer style={{ borderTop: '2px solid var(--line)', background: 'var(--surface)', marginTop: 'auto', paddingBlock: '3rem 2rem' }}>
      <div className="wrap">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(230px, 1fr))', gap: '2.5rem', marginBottom: '2.5rem' }}>
          {/* Brand & Story */}
          <div>
            <Link to="/" className="brand" style={{ marginBottom: '0.75rem', display: 'inline-flex' }}>
              Kadai<i>.</i>Lane
            </Link>
            <p style={{ color: 'var(--muted)', fontSize: '0.9rem', lineHeight: 1.6, margin: '0 0 1rem' }}>
              Slow-cooked classics, fast Pune evenings. Our kitchen grinds its own masalas every morning in Koregaon Park.
            </p>
            <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center', fontSize: '0.85rem', color: 'var(--muted)' }}>
              <ShieldCheck size={16} color="var(--green)" />
              <span>Veg & non-veg kitchens kept separate</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 style={{ fontSize: '1.1rem', marginBottom: '1rem' }}>Explore</h4>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '0.5rem', fontSize: '0.92rem', color: 'var(--muted)' }}>
              <li><Link to="/menu" style={{ transition: 'color 0.15s' }}>Online Menu</Link></li>
              <li><Link to="/reserve" style={{ transition: 'color 0.15s' }}>Table Reservation</Link></li>
              <li><Link to="/cart" style={{ transition: 'color 0.15s' }}>My Cart</Link></li>
              <li><Link to="/about" style={{ transition: 'color 0.15s' }}>Our Story & Philosophy</Link></li>
              <li><Link to="/contact" style={{ transition: 'color 0.15s' }}>Contact & Directions</Link></li>
            </ul>
          </div>

          {/* Hours */}
          <div>
            <h4 style={{ fontSize: '1.1rem', marginBottom: '1rem' }}>Kitchen Hours</h4>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '0.45rem', fontSize: '0.88rem', color: 'var(--muted)' }}>
              <li style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Mon – Thu</span>
                <b style={{ color: 'var(--ink)' }}>12:00 – 22:30</b>
              </li>
              <li style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Fri – Sat</span>
                <b style={{ color: 'var(--ink)' }}>12:00 – 23:30</b>
              </li>
              <li style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Sunday</span>
                <b style={{ color: 'var(--ink)' }}>11:00 – 22:30</b>
              </li>
              <li style={{ marginTop: '0.5rem', fontSize: '0.8rem', color: 'var(--chili)' }}>
                * Kitchen closes 30 mins prior
              </li>
            </ul>
          </div>

          {/* Contact Details */}
          <div>
            <h4 style={{ fontSize: '1.1rem', marginBottom: '1rem' }}>Visit Us</h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem', fontSize: '0.9rem', color: 'var(--muted)' }}>
              <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'flex-start' }}>
                <MapPin size={18} style={{ flexShrink: 0, marginTop: '2px', color: 'var(--green)' }} />
                <span>14 Lane 5, Koregaon Park, Pune 411001</span>
              </div>
              <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                <Phone size={18} style={{ flexShrink: 0, color: 'var(--green)' }} />
                <span>+91 98230 45678</span>
              </div>
              <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                <Mail size={18} style={{ flexShrink: 0, color: 'var(--green)' }} />
                <span>hello@kadailane.in</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Banner */}
        <div
          style={{
            borderTop: '1px solid var(--line)',
            paddingTop: '1.5rem',
            display: 'flex',
            flexWrap: 'wrap',
            justifyContent: 'space-between',
            alignItems: 'center',
            gap: '1rem',
            fontSize: '0.85rem',
            color: 'var(--muted)',
          }}
        >
          <div>
            © {new Date().getFullYear()} Kadai Lane. All rights reserved. Prices in ₹ (INR), taxes extra.
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
            <span>Created for 2nd Year B.Tech CSE Project with</span>
            <Heart size={14} color="var(--chili)" fill="var(--chili)" />
          </div>
        </div>
      </div>
    </footer>
  );
};
