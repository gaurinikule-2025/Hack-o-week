import React, { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import { useTheme } from '../../context/ThemeContext';
import {
  ShoppingBag,
  Sun,
  Moon,
  User as UserIcon,
  Menu as MenuIcon,
  X,
  ShieldCheck,
  LogOut,
  Calendar,
  Package,
  LayoutDashboard,
} from 'lucide-react';

export const Navbar = () => {
  const { user, isAdmin, logout } = useAuth();
  const { cartCount } = useCart();
  const { theme, toggleTheme } = useTheme();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    setUserDropdownOpen(false);
    navigate('/');
  };

  return (
    <header className="header-top">
      <div className="wrap" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '1rem' }}>
        {/* Brand Wordmark */}
        <Link to="/" className="brand" aria-label="Kadai Lane Home">
          <span>Kadai<i>.</i>Lane</span>
        </Link>

        {/* Desktop Navigation Links */}
        <nav style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }} className="desktop-nav">
          <NavLink
            to="/"
            end
            className={({ isActive }) => `btn sm alt ${isActive ? 'active-link' : ''}`}
            style={({ isActive }) => (isActive ? { background: 'var(--soft)', borderColor: 'var(--green)' } : {})}
          >
            Home
          </NavLink>
          <NavLink
            to="/menu"
            className={({ isActive }) => `btn sm alt ${isActive ? 'active-link' : ''}`}
            style={({ isActive }) => (isActive ? { background: 'var(--soft)', borderColor: 'var(--green)' } : {})}
          >
            Menu
          </NavLink>
          <NavLink
            to="/reserve"
            className={({ isActive }) => `btn sm alt ${isActive ? 'active-link' : ''}`}
            style={({ isActive }) => (isActive ? { background: 'var(--soft)', borderColor: 'var(--green)' } : {})}
          >
            Reserve Table
          </NavLink>
          <NavLink
            to="/about"
            className={({ isActive }) => `btn sm alt ${isActive ? 'active-link' : ''}`}
            style={({ isActive }) => (isActive ? { background: 'var(--soft)', borderColor: 'var(--green)' } : {})}
          >
            About
          </NavLink>
          <NavLink
            to="/contact"
            className={({ isActive }) => `btn sm alt ${isActive ? 'active-link' : ''}`}
            style={({ isActive }) => (isActive ? { background: 'var(--soft)', borderColor: 'var(--green)' } : {})}
          >
            Contact
          </NavLink>
        </nav>

        {/* Right Side Actions: Theme, Cart, User / Admin */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
          {/* Theme Toggle Button */}
          <button
            type="button"
            className="btn sm alt"
            onClick={toggleTheme}
            aria-label="Toggle dark/light theme"
            title="Toggle color theme"
            style={{ padding: '0.45rem', borderRadius: '50%' }}
          >
            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          </button>

          {/* Cart Button with Count Badge */}
          <Link
            to="/cart"
            className="btn sm"
            style={{
              position: 'relative',
              background: 'var(--soft)',
              color: 'var(--ink)',
              borderColor: 'var(--line)',
            }}
            aria-label={`View cart with ${cartCount} items`}
          >
            <ShoppingBag size={18} color="var(--green)" />
            <span style={{ fontWeight: 700, marginLeft: '0.2rem' }}>Cart</span>
            {cartCount > 0 && (
              <span
                style={{
                  position: 'absolute',
                  top: '-7px',
                  right: '-7px',
                  background: 'var(--saffron)',
                  color: '#10261f',
                  fontSize: '0.75rem',
                  fontWeight: 800,
                  width: '20px',
                  height: '20px',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                {cartCount}
              </span>
            )}
          </Link>

          {/* User Account Dropdown or Login */}
          {user ? (
            <div style={{ position: 'relative' }}>
              <button
                type="button"
                className="btn sm alt"
                onClick={() => setUserDropdownOpen((prev) => !prev)}
                style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}
              >
                {isAdmin ? <ShieldCheck size={16} color="var(--green)" /> : <UserIcon size={16} />}
                <span style={{ maxWidth: '100px', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {user.name.split(' ')[0]}
                </span>
              </button>

              {userDropdownOpen && (
                <div
                  className="card"
                  style={{
                    position: 'absolute',
                    right: 0,
                    top: 'calc(100% + 8px)',
                    width: '210px',
                    padding: '0.5rem',
                    zIndex: 200,
                  }}
                >
                  <div style={{ padding: '0.5rem 0.75rem', borderBottom: '1px solid var(--line)' }}>
                    <div style={{ fontWeight: 700, fontSize: '0.9rem' }}>{user.name}</div>
                    <div style={{ fontSize: '0.78rem', color: 'var(--muted)' }}>{user.email}</div>
                  </div>

                  <Link
                    to="/dashboard"
                    className="dropdown-item"
                    style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem 0.75rem', borderRadius: '8px', fontSize: '0.9rem' }}
                    onClick={() => setUserDropdownOpen(false)}
                  >
                    <LayoutDashboard size={15} /> Dashboard
                  </Link>

                  <Link
                    to="/orders"
                    className="dropdown-item"
                    style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem 0.75rem', borderRadius: '8px', fontSize: '0.9rem' }}
                    onClick={() => setUserDropdownOpen(false)}
                  >
                    <Package size={15} /> My Orders
                  </Link>

                  <Link
                    to="/reservations"
                    className="dropdown-item"
                    style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem 0.75rem', borderRadius: '8px', fontSize: '0.9rem' }}
                    onClick={() => setUserDropdownOpen(false)}
                  >
                    <Calendar size={15} /> My Reservations
                  </Link>

                  {isAdmin && (
                    <Link
                      to="/admin"
                      className="dropdown-item"
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.5rem',
                        padding: '0.5rem 0.75rem',
                        borderRadius: '8px',
                        fontSize: '0.9rem',
                        color: 'var(--green)',
                        fontWeight: 700,
                      }}
                      onClick={() => setUserDropdownOpen(false)}
                    >
                      <ShieldCheck size={15} /> Admin Portal
                    </Link>
                  )}

                  <button
                    type="button"
                    onClick={handleLogout}
                    style={{
                      width: '100%',
                      background: 'none',
                      border: 'none',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.5rem',
                      padding: '0.5rem 0.75rem',
                      borderRadius: '8px',
                      fontSize: '0.9rem',
                      color: 'var(--chili)',
                      cursor: 'pointer',
                      textAlign: 'left',
                    }}
                  >
                    <LogOut size={15} /> Log Out
                  </button>
                </div>
              )}
            </div>
          ) : (
            <Link to="/login" className="btn sm">
              Sign In
            </Link>
          )}

          {/* Mobile Menu Hamburger Button */}
          <button
            type="button"
            className="btn sm alt mobile-menu-toggle"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            aria-label="Toggle navigation menu"
            style={{ display: 'none', padding: '0.45rem' }}
          >
            {mobileMenuOpen ? <X size={20} /> : <MenuIcon size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div
          className="mobile-nav-drawer"
          style={{
            borderTop: '1px solid var(--line)',
            marginTop: '0.85rem',
            padding: '1rem 1.25rem',
            display: 'flex',
            flexDirection: 'column',
            gap: '0.75rem',
            background: 'var(--surface)',
          }}
        >
          <Link to="/" onClick={() => setMobileMenuOpen(false)} style={{ padding: '0.4rem 0', fontWeight: 600 }}>Home</Link>
          <Link to="/menu" onClick={() => setMobileMenuOpen(false)} style={{ padding: '0.4rem 0', fontWeight: 600 }}>Menu</Link>
          <Link to="/reserve" onClick={() => setMobileMenuOpen(false)} style={{ padding: '0.4rem 0', fontWeight: 600 }}>Reserve Table</Link>
          <Link to="/about" onClick={() => setMobileMenuOpen(false)} style={{ padding: '0.4rem 0', fontWeight: 600 }}>About</Link>
          <Link to="/contact" onClick={() => setMobileMenuOpen(false)} style={{ padding: '0.4rem 0', fontWeight: 600 }}>Contact</Link>
          {user && (
            <>
              <div style={{ height: '1px', background: 'var(--line)', margin: '0.5rem 0' }} />
              <Link to="/dashboard" onClick={() => setMobileMenuOpen(false)}>Dashboard</Link>
              <Link to="/orders" onClick={() => setMobileMenuOpen(false)}>My Orders</Link>
              <Link to="/reservations" onClick={() => setMobileMenuOpen(false)}>My Reservations</Link>
              {isAdmin && (
                <Link to="/admin" onClick={() => setMobileMenuOpen(false)} style={{ color: 'var(--green)', fontWeight: 700 }}>
                  Admin Portal
                </Link>
              )}
            </>
          )}
        </div>
      )}
    </header>
  );
};
