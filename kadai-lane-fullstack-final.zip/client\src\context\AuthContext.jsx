import React, { createContext, useContext, useState, useEffect } from 'react';
import { apiClient } from '../services/api';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Load current user on initial mount
  useEffect(() => {
    const fetchUser = async () => {
      try {
        const data = await apiClient('/auth/me');
        if (data.success && data.user) {
          setUser(data.user);
        }
      } catch (err) {
        // Not logged in or expired token
        setUser(null);
        localStorage.removeItem('kadai_token');
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, []);

  const login = async (email, password) => {
    const data = await apiClient('/auth/login', {
      method: 'POST',
      body: { email, password },
    });

    if (data.success && data.user) {
      setUser(data.user);
      if (data.token) {
        localStorage.setItem('kadai_token', data.token);
      }
    }
    return data;
  };

  const register = async (userData) => {
    const data = await apiClient('/auth/register', {
      method: 'POST',
      body: userData,
    });

    if (data.success && data.user) {
      setUser(data.user);
      if (data.token) {
        localStorage.setItem('kadai_token', data.token);
      }
    }
    return data;
  };

  const logout = async () => {
    try {
      await apiClient('/auth/logout', { method: 'POST' });
    } catch (err) {
      console.error('Logout error:', err);
    } finally {
      setUser(null);
      localStorage.removeItem('kadai_token');
    }
  };

  const updateProfile = async (updates) => {
    const data = await apiClient('/auth/profile', {
      method: 'PUT',
      body: updates,
    });

    if (data.success && data.user) {
      setUser(data.user);
    }
    return data;
  };

  const isAdmin = user && user.role === 'admin';

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        isAdmin,
        login,
        register,
        logout,
        updateProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
