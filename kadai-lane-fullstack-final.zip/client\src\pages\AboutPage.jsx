import React from 'react';
import { Link } from 'react-router-dom';
import { ShieldCheck, Sparkles, Utensils, Heart, Clock, MapPin } from 'lucide-react';

export const AboutPage = () => {
  return (
    <div className="main-content">
      <div className="wrap">
        {/* Header */}
        <div style={{ textAlign: 'center', maxWidth: '750px', margin: '0 auto 3.5rem' }}>
          <span className="badge saffron" style={{ marginBottom: '1rem' }}>
            <Sparkles size={13} /> The Story of Kadai Lane
          </span>
          <h1 style={{ fontSize: 'clamp(2.4rem, 5vw, 3.8rem)', fontWeight: 800, marginBottom: '1rem' }}>
            Slow-cooked classics, fast Pune evenings.
          </h1>
          <p style={{ color: 'var(--muted)', fontSize: '1.15rem', lineHeight: 1.6, margin: 0 }}>
            Founded in Koregaon Park, Kadai Lane bridges old Maharashtrian kitchen traditions with modern culinary care.
          </p>
        </div>

        {/* Narrative Grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '3rem', alignItems: 'center', marginBottom: '4rem' }}>
          <div>
            <h2 style={{ fontSize: '2rem', marginBottom: '1rem' }}>Our Heritage & Masalas</h2>
            <p style={{ color: 'var(--muted)', fontSize: '1rem', lineHeight: 1.7, marginBottom: '1.25rem' }}>
              At Kadai Lane, we believe that great Indian cooking cannot be rushed with pre-packaged pastes. Every morning before the ovens are fired, our kitchen grinds whole coriander, cumin, dry coconut, and stone flowers (dagad phool) into fresh house spice blends.
            </p>
            <p style={{ color: 'var(--muted)', fontSize: '1rem', lineHeight: 1.7, margin: 0 }}>
              From fiery Kolhapuri red curries and Misal Pav with crunchy farsan to 16-hour slow-cooked Dal Makhani and clay-tandoor flatbreads, each recipe honors authentic regional technique.
            </p>
          </div>

          <div className="card" style={{ padding: '2rem', background: 'var(--soft)' }}>
            <h3 style={{ fontSize: '1.3rem', marginBottom: '1.25rem' }}>Our Core Kitchen Pillars</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              <div style={{ display: 'flex', gap: '0.85rem' }}>
                <ShieldCheck size={24} color="var(--green)" style={{ flexShrink: 0 }} />
                <div>
                  <b style={{ display: 'block', fontSize: '1rem' }}>Separate Veg & Non-Veg Kitchens</b>
                  <span style={{ fontSize: '0.88rem', color: 'var(--muted)' }}>
                    Complete isolation of cooking stations, vessels, and cutlery to ensure total dietary integrity.
                  </span>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '0.85rem' }}>
                <Utensils size={24} color="var(--green)" style={{ flexShrink: 0 }} />
                <div>
                  <b style={{ display: 'block', fontSize: '1rem' }}>Pure Ghee & Charcoal Tandoor</b>
                  <span style={{ fontSize: '0.88rem', color: 'var(--muted)' }}>
                    Breads baked directly on earthen clay walls with natural charcoal smoke and brushed with fresh butter.
                  </span>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '0.85rem' }}>
                <Heart size={24} color="var(--chili)" style={{ flexShrink: 0 }} />
                <div>
                  <b style={{ display: 'block', fontSize: '1rem' }}>Community & Hospitality</b>
                  <span style={{ fontSize: '0.88rem', color: 'var(--muted)' }}>
                    Warm Puneri welcoming culture, quick digital ordering, and comfortable indoor or open terrace dining.
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Location & CTA Banner */}
        <div className="card" style={{ padding: '2.5rem', background: 'var(--surface)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1.5rem' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.4rem', color: 'var(--green)', fontWeight: 700 }}>
              <MapPin size={18} /> 14 Lane 5, Koregaon Park, Pune 411001
            </div>
            <h3 style={{ fontSize: '1.4rem', margin: '0 0 0.35rem' }}>Ready to experience authentic flavors?</h3>
            <p style={{ color: 'var(--muted)', margin: 0, fontSize: '0.95rem' }}>Browse our complete catalogue or reserve your table in advance.</p>
          </div>

          <div style={{ display: 'flex', gap: '0.75rem' }}>
            <Link to="/menu" className="btn">Explore Menu</Link>
            <Link to="/reserve" className="btn alt">Reserve a Table</Link>
          </div>
        </div>
      </div>
    </div>
  );
};
