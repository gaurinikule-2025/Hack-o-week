import React from 'react';
import { Link } from 'react-router-dom';
import { ShieldAlert } from 'lucide-react';

export const AccessDeniedPage = () => {
  return (
    <div className="main-content wrap" style={{ textAlign: 'center', padding: '5rem 1rem' }}>
      <div style={{ color: 'var(--chili)', display: 'inline-flex', marginBottom: '1.25rem' }}>
        <ShieldAlert size={64} />
      </div>
      <h1 style={{ fontSize: '2.5rem', fontWeight: 800, marginBottom: '0.5rem' }}>403 — Access Denied</h1>
      <p style={{ color: 'var(--muted)', maxWidth: '44ch', margin: '0 auto 2rem' }}>
        You do not have administrative permissions to view this section of Kadai Lane.
      </p>
      <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center' }}>
        <Link to="/" className="btn">Return Home</Link>
        <Link to="/login" className="btn alt">Log in as Admin</Link>
      </div>
    </div>
  );
};
