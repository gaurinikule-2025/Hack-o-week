import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { apiClient } from '../services/api';
import {
  DollarSign,
  Package,
  Calendar,
  Utensils,
  ChevronRight,
  TrendingUp,
  ShieldCheck,
  Clock,
} from 'lucide-react';

export const AdminDashboard = () => {
  const [stats, setStats] = useState(null);
  const [recentOrders, setRecentOrders] = useState([]);
  const [upcomingReservations, setUpcomingReservations] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchStats = async () => {
    try {
      const data = await apiClient('/admin/stats');
      if (data.success) {
        setStats(data.stats);
        setRecentOrders(data.recentOrders || []);
        setUpcomingReservations(data.upcomingReservations || []);
      }
    } catch (err) {
      console.error('Failed to load admin stats:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  return (
    <div className="main-content">
      <div className="wrap">
        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', flexWrap: 'wrap', gap: '1rem', marginBottom: '2.5rem' }}>
          <div>
            <span className="badge saffron" style={{ marginBottom: '0.4rem' }}>
              <ShieldCheck size={14} /> Master Administrator Portal
            </span>
            <h1 style={{ fontSize: 'clamp(2rem, 4vw, 2.8rem)', fontWeight: 800 }}>
              Kadai Lane Management
            </h1>
            <p style={{ color: 'var(--muted)', margin: 0 }}>
              Live metrics calculated directly from MongoDB database collections.
            </p>
          </div>

          <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
            <Link to="/admin/menu" className="btn sm">
              <Utensils size={15} /> Manage Menu
            </Link>
            <Link to="/admin/orders" className="btn sm alt">
              <Package size={15} /> Manage Orders
            </Link>
            <Link to="/admin/reservations" className="btn sm alt">
              <Calendar size={15} /> Reservations
            </Link>
          </div>
        </div>

        {/* 4 Metric Tiles */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1.25rem', marginBottom: '2.5rem' }}>
          <div className="card" style={{ padding: '1.5rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
              <span style={{ fontSize: '0.85rem', color: 'var(--muted)', fontWeight: 700 }}>Total Revenue</span>
              <div style={{ background: 'var(--soft)', padding: '0.5rem', borderRadius: '10px', color: 'var(--green)' }}>
                <TrendingUp size={20} />
              </div>
            </div>
            <div className="price" style={{ fontSize: '1.9rem', color: 'var(--green)' }}>
              ₹{stats ? stats.orders.revenue.toLocaleString('en-IN') : '0'}
            </div>
            <div style={{ fontSize: '0.8rem', color: 'var(--muted)', marginTop: '0.2rem' }}>
              From completed & active orders
            </div>
          </div>

          <div className="card" style={{ padding: '1.5rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
              <span style={{ fontSize: '0.85rem', color: 'var(--muted)', fontWeight: 700 }}>Active Orders</span>
              <div style={{ background: 'var(--soft)', padding: '0.5rem', borderRadius: '10px', color: 'var(--green)' }}>
                <Package size={20} />
              </div>
            </div>
            <div style={{ fontSize: '1.9rem', fontWeight: 800 }}>
              {stats ? stats.orders.active : 0}
            </div>
            <div style={{ fontSize: '0.8rem', color: 'var(--muted)', marginTop: '0.2rem' }}>
              Out of {stats ? stats.orders.total : 0} total placed
            </div>
          </div>

          <div className="card" style={{ padding: '1.5rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
              <span style={{ fontSize: '0.85rem', color: 'var(--muted)', fontWeight: 700 }}>Today's Tables</span>
              <div style={{ background: 'var(--soft)', padding: '0.5rem', borderRadius: '10px', color: 'var(--green)' }}>
                <Calendar size={20} />
              </div>
            </div>
            <div style={{ fontSize: '1.9rem', fontWeight: 800 }}>
              {stats ? stats.reservations.today : 0}
            </div>
            <div style={{ fontSize: '0.8rem', color: 'var(--muted)', marginTop: '0.2rem' }}>
              {stats ? stats.reservations.upcoming : 0} upcoming reservations
            </div>
          </div>

          <div className="card" style={{ padding: '1.5rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
              <span style={{ fontSize: '0.85rem', color: 'var(--muted)', fontWeight: 700 }}>Menu Catalog</span>
              <div style={{ background: 'var(--soft)', padding: '0.5rem', borderRadius: '10px', color: 'var(--green)' }}>
                <Utensils size={20} />
              </div>
            </div>
            <div style={{ fontSize: '1.9rem', fontWeight: 800 }}>
              {stats ? stats.menu.available : 0} / {stats ? stats.menu.total : 0}
            </div>
            <div style={{ fontSize: '0.8rem', color: 'var(--muted)', marginTop: '0.2rem' }}>
              Dishes currently available
            </div>
          </div>
        </div>

        {/* Recent Orders & Reservations Tables */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '2rem' }}>
          {/* Recent Orders */}
          <div className="card" style={{ padding: '1.75rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
              <h2 style={{ fontSize: '1.3rem', margin: 0 }}>Latest Customer Orders</h2>
              <Link to="/admin/orders" style={{ fontSize: '0.88rem', color: 'var(--green)', fontWeight: 700 }}>
                View All →
              </Link>
            </div>

            {loading ? (
              <p style={{ color: 'var(--muted)' }}>Loading latest orders...</p>
            ) : recentOrders.length > 0 ? (
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>Order #</th>
                      <th>Customer</th>
                      <th>Total</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentOrders.map((o) => (
                      <tr key={o._id}>
                        <td>
                          <Link to={`/orders/${o.orderNumber}`} style={{ fontWeight: 700, color: 'var(--green)' }}>
                            #{o.orderNumber.slice(-8)}
                          </Link>
                        </td>
                        <td>
                          <div>{o.customerName}</div>
                          <div style={{ fontSize: '0.78rem', color: 'var(--muted)' }}>{o.orderType}</div>
                        </td>
                        <td><b>₹{o.total}</b></td>
                        <td>
                          <span className={`badge ${o.orderStatus === 'Delivered' ? 'green' : o.orderStatus === 'Cancelled' ? 'red' : 'saffron'}`} style={{ fontSize: '0.75rem' }}>
                            {o.orderStatus}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '1.5rem' }}>No orders recorded yet.</p>
            )}
          </div>

          {/* Upcoming Reservations */}
          <div className="card" style={{ padding: '1.75rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
              <h2 style={{ fontSize: '1.3rem', margin: 0 }}>Upcoming Reservations</h2>
              <Link to="/admin/reservations" style={{ fontSize: '0.88rem', color: 'var(--green)', fontWeight: 700 }}>
                View All →
              </Link>
            </div>

            {loading ? (
              <p style={{ color: 'var(--muted)' }}>Loading reservations...</p>
            ) : upcomingReservations.length > 0 ? (
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>Ref #</th>
                      <th>Guest</th>
                      <th>Date / Time</th>
                      <th>Seats</th>
                    </tr>
                  </thead>
                  <tbody>
                    {upcomingReservations.map((r) => (
                      <tr key={r._id}>
                        <td><b>#{r.reservationNumber.slice(-8)}</b></td>
                        <td>
                          <div>{r.name}</div>
                          <div style={{ fontSize: '0.78rem', color: 'var(--muted)' }}>{r.phone}</div>
                        </td>
                        <td>
                          <div>{r.date}</div>
                          <div style={{ fontSize: '0.78rem', color: 'var(--green)', fontWeight: 700 }}>{r.time}</div>
                        </td>
                        <td>{r.guests} ({r.seatingArea})</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '1.5rem' }}>No upcoming bookings.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
