import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { handleImageError, generateDishSvg } from '../services/imageUtils';
import { Trash2, Plus, Minus, ArrowRight, ShoppingBag, Truck } from 'lucide-react';

export const CartPage = () => {
  const { cart, updateQuantity, removeFromCart, clearCart, subtotal, gst, deliveryFee, total } = useCart();
  const navigate = useNavigate();

  const freeDeliveryThreshold = 500;
  const amountNeededForFreeDelivery = Math.max(0, freeDeliveryThreshold - subtotal);

  if (cart.length === 0) {
    return (
      <div className="main-content wrap" style={{ textAlign: 'center', padding: '4rem 1rem' }}>
        <div className="card" style={{ maxWidth: '520px', margin: '0 auto', padding: '3.5rem 2rem' }}>
          <div style={{ fontSize: '3.5rem', marginBottom: '1.25rem' }}>🛍️</div>
          <h2 style={{ fontSize: '1.8rem', marginBottom: '0.65rem' }}>Your Cart is Empty</h2>
          <p style={{ color: 'var(--muted)', marginBottom: '2rem', fontSize: '1rem', lineHeight: 1.5 }}>
            You haven't added any dishes to your order yet. Explore our authentic Puneri misal, tandoori breads and slow-simmered biryani!
          </p>
          <Link to="/menu" className="btn lg">
            <ShoppingBag size={18} /> Explore Our Menu
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="main-content">
      <div className="wrap">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: '1.75rem', flexWrap: 'wrap', gap: '1rem' }}>
          <div>
            <h1 style={{ fontSize: 'clamp(2rem, 4vw, 2.8rem)', fontWeight: 800 }}>Your Food Cart</h1>
            <p style={{ color: 'var(--muted)', margin: '0.2rem 0 0' }}>
              Review your items, change quantities, and proceed to checkout.
            </p>
          </div>
          <button type="button" onClick={clearCart} className="btn sm alt" style={{ color: 'var(--chili)' }}>
            <Trash2 size={15} /> Clear Cart
          </button>
        </div>

        {/* Free Delivery Bar */}
        {amountNeededForFreeDelivery > 0 ? (
          <div className="alert info" style={{ marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <Truck size={18} color="var(--saffron)" />
            <span>
              Add <b>₹{amountNeededForFreeDelivery}</b> more to unlock <b>FREE Delivery</b>!
            </span>
          </div>
        ) : (
          <div className="alert success" style={{ marginBottom: '1.5rem' }}>
            🎉 You have qualified for <b>FREE Delivery</b> on this order!
          </div>
        )}

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '2rem', alignItems: 'flex-start' }}>
          {/* Cart Item List */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {cart.map((item) => {
              const imgSrc = item.image && item.image.trim() !== ''
                ? item.image
                : generateDishSvg(item);

              return (
                <div
                  key={item._id}
                  className="card"
                  style={{
                    padding: '1rem',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '1rem',
                    flexWrap: 'wrap',
                  }}
                >
                  <img
                    src={imgSrc}
                    alt={item.name}
                    style={{ width: '80px', height: '80px', borderRadius: '12px', objectFit: 'cover' }}
                    onError={(e) => handleImageError(e, item)}
                  />

                  <div style={{ flex: 1, minWidth: '150px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.2rem' }}>
                      <span className={`diet ${item.isVeg ? 'veg' : 'nv'}`} style={{ fontSize: '0.75rem' }}>
                        {item.isVeg ? 'Veg' : 'Non-veg'}
                      </span>
                    </div>
                    <h3 style={{ fontSize: '1.15rem', margin: 0 }}>{item.name}</h3>
                    <div style={{ color: 'var(--muted)', fontSize: '0.88rem' }}>₹{item.price} each</div>
                  </div>

                  {/* Quantity Stepper */}
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      background: 'var(--soft)',
                      borderRadius: '8px',
                      border: '1px solid var(--line)',
                    }}
                  >
                    <button
                      type="button"
                      onClick={() => updateQuantity(item._id, item.quantity - 1)}
                      style={{ background: 'none', border: 'none', padding: '0.4rem 0.65rem', cursor: 'pointer' }}
                      aria-label="Decrease"
                    >
                      <Minus size={14} />
                    </button>
                    <span style={{ fontWeight: 800, padding: '0 0.4rem', minWidth: '24px', textAlign: 'center', fontSize: '0.95rem' }}>
                      {item.quantity}
                    </span>
                    <button
                      type="button"
                      onClick={() => updateQuantity(item._id, item.quantity + 1)}
                      style={{ background: 'none', border: 'none', padding: '0.4rem 0.65rem', cursor: 'pointer' }}
                      aria-label="Increase"
                    >
                      <Plus size={14} />
                    </button>
                  </div>

                  <div style={{ minWidth: '80px', textAlign: 'right' }}>
                    <div className="price" style={{ fontSize: '1.15rem' }}>₹{item.price * item.quantity}</div>
                  </div>

                  <button
                    type="button"
                    onClick={() => removeFromCart(item._id)}
                    style={{
                      background: 'none',
                      border: 'none',
                      color: 'var(--muted)',
                      cursor: 'pointer',
                      padding: '0.4rem',
                    }}
                    title="Remove item"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              );
            })}

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '0.5rem' }}>
              <Link to="/menu" className="btn sm alt">
                ← Continue Ordering Food
              </Link>
            </div>
          </div>

          {/* Bill Summary Card */}
          <div className="card" style={{ padding: '1.75rem', position: 'sticky', top: '100px' }}>
            <h3 style={{ fontSize: '1.3rem', marginBottom: '1.25rem', paddingBottom: '0.75rem', borderBottom: '1px solid var(--line)' }}>
              Order Bill Summary
            </h3>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', fontSize: '0.95rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--muted)' }}>Item Subtotal</span>
                <span>₹{subtotal}</span>
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--muted)' }}>GST & Restaurant Tax (5%)</span>
                <span>₹{gst}</span>
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ color: 'var(--muted)' }}>Standard Delivery Fee</span>
                <span>{deliveryFee === 0 ? <b style={{ color: 'var(--green)' }}>FREE</b> : `₹${deliveryFee}`}</span>
              </div>

              <div
                style={{
                  borderTop: '2px solid var(--line)',
                  paddingTop: '0.85rem',
                  marginTop: '0.5rem',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'baseline',
                }}
              >
                <b style={{ fontSize: '1.15rem' }}>Final Total</b>
                <span className="price" style={{ fontSize: '1.6rem', color: 'var(--green)' }}>
                  ₹{total}
                </span>
              </div>
            </div>

            <button
              type="button"
              className="btn lg full saffron"
              style={{ marginTop: '1.5rem', fontWeight: 800 }}
              onClick={() => navigate('/checkout')}
            >
              Proceed to Checkout <ArrowRight size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
