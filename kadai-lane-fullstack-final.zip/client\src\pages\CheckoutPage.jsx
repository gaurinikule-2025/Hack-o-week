import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { apiClient } from '../services/api';
import { MapPin, Phone, User, CheckCircle2, ShieldCheck, AlertCircle } from 'lucide-react';

export const CheckoutPage = () => {
  const { user } = useAuth();
  const { cart, subtotal, gst, deliveryFee, total, clearCart } = useCart();
  const navigate = useNavigate();

  const [orderType, setOrderType] = useState('Delivery');
  const [customerName, setCustomerName] = useState(user ? user.name : '');
  const [customerPhone, setCustomerPhone] = useState(user ? user.phone : '');
  const [street, setStreet] = useState(user?.address?.street || '');
  const [area, setArea] = useState(user?.address?.area || 'Koregaon Park');
  const [city, setCity] = useState(user?.address?.city || 'Pune');
  const [pincode, setPincode] = useState(user?.address?.pincode || '411001');
  const [specialInstructions, setSpecialInstructions] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('Cash on Delivery');

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  if (cart.length === 0) {
    return (
      <div className="main-content wrap" style={{ textAlign: 'center', padding: '4rem 1rem' }}>
        <h2>No Items to Checkout</h2>
        <p style={{ color: 'var(--muted)', margin: '1rem 0 1.5rem' }}>Your shopping cart is currently empty.</p>
        <Link to="/menu" className="btn sm">Go to Menu</Link>
      </div>
    );
  }

  const effectiveDeliveryFee = orderType === 'Pickup' ? 0 : deliveryFee;
  const effectiveTotal = subtotal + gst + effectiveDeliveryFee;

  const handleSubmitOrder = async (e) => {
    e.preventDefault();
    setError('');

    if (!user) {
      navigate('/login', { state: { from: { pathname: '/checkout' } } });
      return;
    }

    if (!customerName.trim() || !customerPhone.trim()) {
      setError('Please provide your name and contact phone number.');
      return;
    }

    if (!/^\d{10}$/.test(customerPhone.replace(/\s+/g, ''))) {
      setError('Phone number must be a valid 10-digit mobile number.');
      return;
    }

    if (orderType === 'Delivery' && !street.trim()) {
      setError('Please enter your complete delivery address.');
      return;
    }

    setSubmitting(true);

    try {
      const orderPayload = {
        items: cart.map((c) => ({ menuItemId: c._id, quantity: c.quantity })),
        orderType,
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim(),
        specialInstructions: specialInstructions.trim(),
        paymentMethod: orderType === 'Pickup' ? 'Pay at Restaurant / Pickup' : paymentMethod,
        deliveryAddress:
          orderType === 'Delivery'
            ? {
                street: street.trim(),
                area: area.trim(),
                city: city.trim(),
                pincode: pincode.trim(),
              }
            : undefined,
      };

      const response = await apiClient('/orders', {
        method: 'POST',
        body: orderPayload,
      });

      if (response.success && response.order) {
        clearCart();
        navigate(`/orders/${response.order.orderNumber}`);
      }
    } catch (err) {
      setError(err.message || 'Failed to place order. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="main-content">
      <div className="wrap">
        <h1 style={{ fontSize: 'clamp(2rem, 4vw, 2.8rem)', fontWeight: 800, marginBottom: '0.5rem' }}>
          Checkout & Confirm Order
        </h1>
        <p style={{ color: 'var(--muted)', margin: '0 0 2rem' }}>
          Please verify your details and preferred fulfillment option.
        </p>

        {error && (
          <div className="alert error">
            <AlertCircle size={18} />
            <span>{error}</span>
          </div>
        )}

        {!user && (
          <div className="alert info" style={{ marginBottom: '1.5rem', justifyContent: 'space-between' }}>
            <span>Sign in to save this order to your account history and track real-time kitchen progress.</span>
            <Link to="/login" className="btn sm">Sign In</Link>
          </div>
        )}

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '2rem', alignItems: 'flex-start' }}>
          {/* Checkout Form */}
          <form onSubmit={handleSubmitOrder} className="card" style={{ padding: '2rem' }}>
            {/* Fulfillment Type */}
            <div style={{ marginBottom: '1.75rem' }}>
              <label style={{ display: 'block', marginBottom: '0.6rem' }}>Fulfillment Method</label>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                <button
                  type="button"
                  className={`btn ${orderType === 'Delivery' ? '' : 'alt'}`}
                  onClick={() => setOrderType('Delivery')}
                  style={{ width: '100%', borderRadius: '12px' }}
                >
                  🚴 Home Delivery
                </button>
                <button
                  type="button"
                  className={`btn ${orderType === 'Pickup' ? '' : 'alt'}`}
                  onClick={() => setOrderType('Pickup')}
                  style={{ width: '100%', borderRadius: '12px' }}
                >
                  🥡 Restaurant Pickup
                </button>
              </div>
            </div>

            {/* Customer Details */}
            <h3 style={{ fontSize: '1.25rem', marginBottom: '1rem', borderBottom: '1px solid var(--line)', paddingBottom: '0.5rem' }}>
              1. Customer Information
            </h3>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div className="form-group">
                <label>Full Name *</label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="e.g. Rahul Sharma"
                />
              </div>

              <div className="form-group">
                <label>Mobile Number *</label>
                <input
                  type="tel"
                  required
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="10-digit number"
                />
              </div>
            </div>

            {/* Delivery Address (if Delivery) */}
            {orderType === 'Delivery' && (
              <>
                <h3 style={{ fontSize: '1.25rem', margin: '1.5rem 0 1rem', borderBottom: '1px solid var(--line)', paddingBottom: '0.5rem' }}>
                  2. Delivery Destination
                </h3>

                <div className="form-group">
                  <label>House / Flat / Society & Street *</label>
                  <input
                    type="text"
                    required
                    value={street}
                    onChange={(e) => setStreet(e.target.value)}
                    placeholder="e.g. Flat 302, Green Acres, Lane 7"
                  />
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                  <div className="form-group">
                    <label>Area in Pune</label>
                    <input
                      type="text"
                      value={area}
                      onChange={(e) => setArea(e.target.value)}
                      placeholder="e.g. Koregaon Park"
                    />
                  </div>

                  <div className="form-group">
                    <label>Pincode</label>
                    <input
                      type="text"
                      value={pincode}
                      onChange={(e) => setPincode(e.target.value)}
                      placeholder="411001"
                    />
                  </div>
                </div>
              </>
            )}

            {/* Special Instructions */}
            <div className="form-group" style={{ marginTop: '1rem' }}>
              <label>Special Instructions / Allergies (Optional)</label>
              <textarea
                rows={2}
                value={specialInstructions}
                onChange={(e) => setSpecialInstructions(e.target.value)}
                placeholder="e.g. Less spicy tarri for Misal, extra green chutney, please ring bell once."
              />
            </div>

            {/* Payment Method */}
            <h3 style={{ fontSize: '1.25rem', margin: '1.5rem 0 1rem', borderBottom: '1px solid var(--line)', paddingBottom: '0.5rem' }}>
              3. Payment Selection
            </h3>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '1.5rem' }}>
              <label
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.75rem',
                  padding: '0.85rem 1rem',
                  border: '2px solid var(--line)',
                  borderRadius: '10px',
                  cursor: 'pointer',
                  background: paymentMethod === 'Cash on Delivery' ? 'var(--soft)' : 'transparent',
                }}
              >
                <input
                  type="radio"
                  name="payment"
                  checked={paymentMethod === 'Cash on Delivery'}
                  onChange={() => setPaymentMethod('Cash on Delivery')}
                />
                <div>
                  <b style={{ display: 'block' }}>Cash on Delivery / UPI at Doorstep</b>
                  <span style={{ fontSize: '0.82rem', color: 'var(--muted)' }}>
                    Pay in cash or scan delivery rider's UPI QR code upon arrival.
                  </span>
                </div>
              </label>

              {orderType === 'Pickup' && (
                <label
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.75rem',
                    padding: '0.85rem 1rem',
                    border: '2px solid var(--line)',
                    borderRadius: '10px',
                    cursor: 'pointer',
                    background: paymentMethod === 'Pay at Restaurant / Pickup' ? 'var(--soft)' : 'transparent',
                  }}
                >
                  <input
                    type="radio"
                    name="payment"
                    checked={paymentMethod === 'Pay at Restaurant / Pickup'}
                    onChange={() => setPaymentMethod('Pay at Restaurant / Pickup')}
                  />
                  <div>
                    <b style={{ display: 'block' }}>Pay at Counter on Pickup</b>
                    <span style={{ fontSize: '0.82rem', color: 'var(--muted)' }}>
                      Pay at our Koregaon Park kitchen counter via Cash/Card/UPI when collecting.
                    </span>
                  </div>
                </label>
              )}
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="btn lg full saffron"
              style={{ fontWeight: 800 }}
            >
              {submitting ? 'Placing Order in Kitchen...' : `Confirm & Place Order (₹${effectiveTotal})`}
            </button>
          </form>

          {/* Items Summary Sidecard */}
          <div className="card" style={{ padding: '1.75rem' }}>
            <h3 style={{ fontSize: '1.25rem', marginBottom: '1rem', borderBottom: '1px solid var(--line)', paddingBottom: '0.5rem' }}>
              Order Review ({cart.length} dishes)
            </h3>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '1.5rem', maxHeight: '300px', overflowY: 'auto' }}>
              {cart.map((item) => (
                <div key={item._id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '0.92rem' }}>
                  <div>
                    <span className={`diet ${item.isVeg ? 'veg' : 'nv'}`} style={{ marginRight: '0.4rem', fontSize: '0.75rem' }} />
                    <span><b>{item.quantity}×</b> {item.name}</span>
                  </div>
                  <b>₹{item.price * item.quantity}</b>
                </div>
              ))}
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem', borderTop: '1px solid var(--line)', paddingTop: '1rem', fontSize: '0.92rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--muted)' }}>Items Subtotal</span>
                <span>₹{subtotal}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--muted)' }}>GST (5%)</span>
                <span>₹{gst}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--muted)' }}>Delivery Fee</span>
                <span>{effectiveDeliveryFee === 0 ? <b style={{ color: 'var(--green)' }}>FREE</b> : `₹${effectiveDeliveryFee}`}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '2px solid var(--line)', paddingTop: '0.75rem', marginTop: '0.25rem' }}>
                <b style={{ fontSize: '1.1rem' }}>Final Amount</b>
                <span className="price" style={{ fontSize: '1.4rem', color: 'var(--green)' }}>₹{effectiveTotal}</span>
              </div>
            </div>

            <div style={{ marginTop: '1.5rem', padding: '0.85rem', background: 'var(--soft)', borderRadius: '10px', fontSize: '0.82rem', color: 'var(--muted)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.2rem', fontWeight: 700, color: 'var(--ink)' }}>
                <ShieldCheck size={16} color="var(--green)" /> Genuine Order Fulfillment
              </div>
              <span>Prices verified against live MongoDB menu records. No payment card required.</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
