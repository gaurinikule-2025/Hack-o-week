import React, { useState } from 'react';
import { apiClient } from '../services/api';
import { MapPin, Phone, Mail, Clock, Send, CheckCircle2, AlertCircle } from 'lucide-react';

export const ContactPage = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [subject, setSubject] = useState('General Inquiry');
  const [message, setMessage] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setSubmitting(true);

    try {
      const res = await apiClient('/contact', {
        method: 'POST',
        body: {
          name: name.trim(),
          email: email.trim(),
          phone: phone.trim(),
          subject,
          message: message.trim(),
        },
      });

      if (res.success) {
        setSuccessMsg(res.message || 'Thank you! Your message has been sent to Kadai Lane.');
        setName('');
        setEmail('');
        setPhone('');
        setMessage('');
      }
    } catch (err) {
      setErrorMsg(err.message || 'Failed to send message. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="main-content">
      <div className="wrap">
        <div style={{ textAlign: 'center', maxWidth: '650px', margin: '0 auto 3rem' }}>
          <h1 style={{ fontSize: 'clamp(2.2rem, 4.5vw, 3.2rem)', fontWeight: 800, marginBottom: '0.65rem' }}>
            Contact Kadai Lane
          </h1>
          <p style={{ color: 'var(--muted)', fontSize: '1.05rem', margin: 0 }}>
            Have a question regarding catering, table reservations, or our menu? We’d love to hear from you.
          </p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '2.5rem', alignItems: 'flex-start' }}>
          {/* Restaurant Contact Cards */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            <div className="card" style={{ padding: '2rem' }}>
              <h2 style={{ fontSize: '1.4rem', marginBottom: '1.25rem' }}>Restaurant Location</h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem', fontSize: '0.95rem' }}>
                <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'flex-start' }}>
                  <MapPin size={22} color="var(--green)" style={{ flexShrink: 0, marginTop: '2px' }} />
                  <div>
                    <b>Kadai Lane Kitchen</b>
                    <p style={{ color: 'var(--muted)', margin: '0.2rem 0 0' }}>
                      14 Lane 5, Koregaon Park, Pune 411001, Maharashtra<br />
                      Landmark: Near North Main Road Junction
                    </p>
                  </div>
                </div>

                <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center' }}>
                  <Phone size={22} color="var(--green)" style={{ flexShrink: 0 }} />
                  <div>
                    <b>Phone & WhatsApp</b>
                    <p style={{ color: 'var(--muted)', margin: '0.2rem 0 0' }}>+91 98230 45678 / +91 20 2615 8900</p>
                  </div>
                </div>

                <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center' }}>
                  <Mail size={22} color="var(--green)" style={{ flexShrink: 0 }} />
                  <div>
                    <b>Email Inquiries</b>
                    <p style={{ color: 'var(--muted)', margin: '0.2rem 0 0' }}>hello@kadailane.in</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="card" style={{ padding: '2rem', background: 'var(--soft)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', marginBottom: '1rem' }}>
                <Clock size={20} color="var(--green)" />
                <h3 style={{ fontSize: '1.2rem', margin: 0 }}>Opening Schedule</h3>
              </div>
              <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'grid', gap: '0.5rem', fontSize: '0.92rem' }}>
                <li style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span>Monday – Thursday</span>
                  <b>12:00 – 22:30</b>
                </li>
                <li style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span>Friday – Saturday</span>
                  <b>12:00 – 23:30</b>
                </li>
                <li style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span>Sunday</span>
                  <b>11:00 – 22:30</b>
                </li>
              </ul>
            </div>
          </div>

          {/* Interactive Inquiry Form */}
          <form onSubmit={handleSubmit} className="card" style={{ padding: '2.25rem' }}>
            <h2 style={{ fontSize: '1.4rem', marginBottom: '0.35rem' }}>Send Us a Message</h2>
            <p style={{ color: 'var(--muted)', fontSize: '0.9rem', marginBottom: '1.5rem' }}>
              We reply to inquiries within 2 hours during restaurant operating times.
            </p>

            {successMsg && (
              <div className="alert success">
                <CheckCircle2 size={18} />
                <span>{successMsg}</span>
              </div>
            )}

            {errorMsg && (
              <div className="alert error">
                <AlertCircle size={18} />
                <span>{errorMsg}</span>
              </div>
            )}

            <div className="form-group">
              <label>Your Name *</label>
              <input
                type="text"
                required
                placeholder="e.g. Vikram Joshi"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div className="form-group">
                <label>Email *</label>
                <input
                  type="email"
                  required
                  placeholder="vikram@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>

              <div className="form-group">
                <label>Phone Number</label>
                <input
                  type="tel"
                  placeholder="10-digit number"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                />
              </div>
            </div>

            <div className="form-group">
              <label>Inquiry Subject *</label>
              <select value={subject} onChange={(e) => setSubject(e.target.value)}>
                <option>General Inquiry</option>
                <option>Catering & Large Events (&gt;8 guests)</option>
                <option>Feedback & Experience</option>
                <option>Career Opportunities</option>
              </select>
            </div>

            <div className="form-group">
              <label>Message *</label>
              <textarea
                required
                rows={4}
                placeholder="How can we assist you?"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
              />
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="btn full lg saffron"
              style={{ fontWeight: 800, marginTop: '0.5rem' }}
            >
              <Send size={18} />
              {submitting ? 'Sending...' : 'Send Message'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
