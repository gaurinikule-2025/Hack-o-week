import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { apiClient } from '../services/api';
import { Package, Calendar, Utensils, Clock, ChevronRight, User } from 'lucide-react';

export const CustomerDashboard = () => {
  const { user } = useAuth();
  const [orders, setOrders] = useState([]);
  const [reservations, setReservations] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const [ordersRes, resRes] = await Promise.all([
          apiClient('/orders/my-orders'),
          apiClient('/reservations/my/all'),
        ]);

        if (ordersRes.success) setOrders(ordersRes.orders || []);
        if (resRes.success) setReservations(resRes.reservations || []);
      } catch (err) {
        console.error('Failed to load dashboard data:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, []);

  const activeOrders = orders.filter(
    (o) => !['Delivered', 'Cancelled'].includes(o.orderStatus)
  );

  return (
    <div className="main-content">
      <div className="wrap">
        {/* Header Greeting */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', flexWrap: 'wrap', gap: '1rem', marginBottom: '2.5rem' }}>
          <div>
            <span className="badge green" style={{ marginBottom: '0.5rem' }}>Customer Account</span>
            <h1 style={{ fontSize: 'clamp(2rem, 4vw, 2.8rem)', fontWeight: 800 }}>
              Welcome, {user?.name}!
            </h1>
            <p style={{ color: 'var(--muted)', margin: 0 }}>
              Track live food preparations, inspect your table bookings, and order favorites.
            </p>
          </div>

          <div style={{ display: 'flex', gap: '0.75rem' }}>
            <Link to="/menu" className="btn sm">
              <Utensils size={16} /> Order Food
            </Link>
            <Link to="/reserve" className="btn sm alt">
              <Calendar size={16} /> Book Table
            </Link>
          </div>
        </div>

        {/* Quick Stat Tiles */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1.25rem', marginBottom: '2.5rem' }}>
          <div className="card" style={{ padding: '1.5rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <div style={{ background: 'var(--soft)', padding: '0.85rem', borderRadius: '12px', color: 'var(--green)' }}>
              <Package size={24} />
            </div>
            <div>
              <div style={{ fontSize: '0.82rem', color: 'var(--muted)', fontWeight: 600 }}>Active Orders</div>
              <div style={{ fontSize: '1.8rem', fontWeight: 800 }}>{activeOrders.length}</div>
            </div>
          </div>

          <div className="card" style={{ padding: '1.5rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <div style={{ background: 'var(--soft)', padding: '0.85rem', borderRadius: '12px', color: 'var(--green)' }}>
              <Clock size={24} />
            </div>
            <div>
              <div style={{ fontSize: '0.82rem', color: 'var(--muted)', fontWeight: 600 }}>Total Orders Placed</div>
              <div style={{ fontSize: '1.8rem', fontWeight: 800 }}>{orders.length}</div>
            </div>
          </div>

          <div className="card" style={{ padding: '1.5rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <div style={{ background: 'var(--soft)', padding: '0.85rem', borderRadius: '12px', color: 'var(--green)' }}>
              <Calendar size={24} />
            </div>
            <div>
              <div style={{ fontSize: '0.82rem', color: 'var(--muted)', fontWeight: 600 }}>Table Reservations</div>
              <div style={{ fontSize: '1.8rem', fontWeight: 800 }}>{reservations.length}</div>
            </div>
          </div>
        </div>

        {/* Two-Column Grid: Recent Orders & Upcoming Bookings */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '2rem' }}>
          {/* Recent Orders Card */}
          <div className="card" style={{ padding: '1.75rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
              <h2 style={{ fontSize: '1.35rem', margin: 0 }}>Recent Orders</h2>
              <Link to="/orders" style={{ fontSize: '0.88rem', color: 'var(--green)', fontWeight: 700 }}>
                View All ({orders.length}) →
              </Link>
            </div>

            {loading ? (
              <p style={{ color: 'var(--muted)' }}>Loading orders...</p>
            ) : orders.length > 0 ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                {orders.slice(0, 3).map((order) => (
                  <Link
                    key={order._id}
                    to={`/orders/${order.orderNumber}`}
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      padding: '1rem',
                      borderRadius: '12px',
                      background: 'var(--bg)',
                      border: '1px solid var(--line)',
                      transition: 'border-color 0.15s',
                    }}
                  >
                    <div>
                      <div style={{ fontWeight: 700, fontSize: '0.95rem' }}>#{order.orderNumber}</div>
                      <div style={{ fontSize: '0.82rem', color: 'var(--muted)' }}>
                        {order.items.length} items • ₹{order.total} • {new Date(order.createdAt).toLocaleDateString('en-IN')}
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <span className={`badge ${order.orderStatus === 'Delivered' ? 'green' : order.orderStatus === 'Cancelled' ? 'red' : 'saffron'}`}>
                        {order.orderStatus}
                      </span>
                      <ChevronRight size={16} color="var(--muted)" />
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div style={{ textAlign: 'center', padding: '2rem 1rem', color: 'var(--muted)' }}>
                <Package size={32} style={{ marginBottom: '0.5rem', opacity: 0.5 }} />
                <p style={{ margin: '0 0 1rem' }}>No orders placed yet.</p>
                <Link to="/menu" className="btn sm">Browse Menu</Link>
              </div>
            )}
          </div>

          {/* Upcoming Reservations Card */}
          <div className="card" style={{ padding: '1.75rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
              <h2 style={{ fontSize: '1.35rem', margin: 0 }}>Table Reservations</h2>
              <Link to="/reservations" style={{ fontSize: '0.88rem', color: 'var(--green)', fontWeight: 700 }}>
                View All ({reservations.length}) →
              </Link>
            </div>

            {loading ? (
              <p style={{ color: 'var(--muted)' }}>Loading reservations...</p>
            ) : reservations.length > 0 ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                {reservations.slice(0, 3).map((res) => (
                  <div
                    key={res._id}
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      padding: '1rem',
                      borderRadius: '12px',
                      background: 'var(--bg)',
                      border: '1px solid var(--line)',
                    }}
                  >
                    <div>
                      <div style={{ fontWeight: 700, fontSize: '0.95rem' }}>#{res.reservationNumber}</div>
                      <div style={{ fontSize: '0.82rem', color: 'var(--muted)' }}>
                        {res.date} at {res.time} • {res.guests} Guests ({res.seatingArea})
                      </div>
                    </div>
                    <span className={`badge ${res.status === 'Confirmed' ? 'green' : res.status === 'Cancelled' ? 'red' : 'gray'}`}>
                      {res.status}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div style={{ textAlign: 'center', padding: '2rem 1rem', color: 'var(--muted)' }}>
                <Calendar size={32} style={{ marginBottom: '0.5rem', opacity: 0.5 }} />
                <p style={{ margin: '0 0 1rem' }}>No upcoming table bookings.</p>
                <Link to="/reserve" className="btn sm alt">Book a Table</Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
