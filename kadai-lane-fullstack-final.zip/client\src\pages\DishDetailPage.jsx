import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { apiClient } from '../services/api';
import { useCart } from '../context/CartContext';
import { handleImageError, generateDishSvg } from '../services/imageUtils';
import { Clock, Flame, ShieldCheck, Plus, Minus, ArrowLeft, Check } from 'lucide-react';

export const DishDetailPage = () => {
  const { id } = useParams();
  const [dish, setDish] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [qty, setQty] = useState(1);
  const [addedNotice, setAddedNotice] = useState(false);
  const { addToCart } = useCart();

  useEffect(() => {
    const fetchDish = async () => {
      setLoading(true);
      try {
        const data = await apiClient(`/menu/${id}`);
        if (data.success && data.item) {
          setDish(data.item);
        }
      } catch (err) {
        setError(err.message || 'Dish not found.');
      } finally {
        setLoading(false);
      }
    };

    fetchDish();
  }, [id]);

  const handleAdd = () => {
    if (!dish) return;
    addToCart(dish, qty);
    setAddedNotice(true);
    setTimeout(() => setAddedNotice(false), 2500);
  };

  if (loading) {
    return (
      <div className="main-content wrap" style={{ textAlign: 'center', padding: '4rem 0' }}>
        <p style={{ color: 'var(--muted)' }}>Loading dish details...</p>
      </div>
    );
  }

  if (error || !dish) {
    return (
      <div className="main-content wrap" style={{ textAlign: 'center', padding: '4rem 0' }}>
        <h2 style={{ marginBottom: '1rem' }}>Dish Not Found</h2>
        <p style={{ color: 'var(--muted)', marginBottom: '1.5rem' }}>{error || 'The requested dish does not exist on our menu.'}</p>
        <Link to="/menu" className="btn sm">Back to Menu</Link>
      </div>
    );
  }

  const imgSrc = dish.image && dish.image.trim() !== ''
    ? dish.image
    : generateDishSvg(dish);

  return (
    <div className="main-content">
      <div className="wrap">
        <Link to="/menu" className="btn sm alt" style={{ marginBottom: '1.5rem', display: 'inline-flex', alignItems: 'center', gap: '0.4rem' }}>
          <ArrowLeft size={16} /> Back to Menu
        </Link>

        <div
          className="card"
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
            overflow: 'hidden',
          }}
        >
          {/* Image */}
          <div style={{ position: 'relative', minHeight: '340px', background: 'var(--soft)' }}>
            <img
              src={imgSrc}
              alt={dish.name}
              style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
              onError={(e) => handleImageError(e, dish)}
            />
            <div style={{ position: 'absolute', top: '16px', left: '16px' }}>
              <span className={`diet ${dish.isVeg ? 'veg' : 'nv'}`} style={{ background: 'var(--surface)', padding: '0.3rem 0.75rem', borderRadius: '999px', boxShadow: 'var(--card-shadow)' }}>
                {dish.isVeg ? 'Vegetarian' : 'Non-veg'}
              </span>
            </div>
          </div>

          {/* Details */}
          <div style={{ padding: 'clamp(1.5rem, 4vw, 2.5rem)', display: 'flex', flexDirection: 'column' }}>
            <span style={{ fontSize: '0.85rem', color: 'var(--muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
              {dish.category}
            </span>
            <h1 style={{ fontSize: 'clamp(2rem, 4vw, 2.6rem)', margin: '0.3rem 0 0.75rem' }}>
              {dish.name}
            </h1>
            <span className="price" style={{ fontSize: '1.8rem', color: 'var(--green)', marginBottom: '1rem' }}>
              ₹{dish.price}
            </span>

            <p style={{ color: 'var(--muted)', fontSize: '1.05rem', lineHeight: 1.6, margin: '0 0 1.5rem' }}>
              {dish.description}
            </p>

            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1.2rem', padding: '1rem', background: 'var(--soft)', borderRadius: '12px', marginBottom: '1.5rem', fontSize: '0.92rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Clock size={18} color="var(--green)" />
                <span>Prep: <b>{dish.prepTime || '15 mins'}</b></span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Flame size={18} color="var(--chili)" />
                <span>Spice: <b>{dish.spiceLevel || 'Medium'}</b></span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <ShieldCheck size={18} color="var(--green)" />
                <span>Pure Preparation</span>
              </div>
            </div>

            {dish.isAvailable ? (
              <div style={{ marginTop: 'auto' }}>
                {addedNotice && (
                  <div className="alert success" style={{ marginBottom: '1rem' }}>
                    <Check size={16} /> Added {qty} × {dish.name} to your cart!
                  </div>
                )}
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', border: '2px solid var(--line)', borderRadius: '10px' }}>
                    <button
                      type="button"
                      onClick={() => setQty((q) => Math.max(1, q - 1))}
                      style={{ background: 'none', border: 'none', padding: '0.65rem 0.9rem', cursor: 'pointer' }}
                    >
                      <Minus size={16} />
                    </button>
                    <span style={{ fontWeight: 800, padding: '0 0.5rem', minWidth: '32px', textAlign: 'center' }}>{qty}</span>
                    <button
                      type="button"
                      onClick={() => setQty((q) => q + 1)}
                      style={{ background: 'none', border: 'none', padding: '0.65rem 0.9rem', cursor: 'pointer' }}
                    >
                      <Plus size={16} />
                    </button>
                  </div>
                  <button type="button" className="btn lg full" onClick={handleAdd}>
                    Add to Cart • ₹{dish.price * qty}
                  </button>
                </div>
              </div>
            ) : (
              <div className="alert error" style={{ marginTop: 'auto', justifyContent: 'center' }}>
                Currently unavailable.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
