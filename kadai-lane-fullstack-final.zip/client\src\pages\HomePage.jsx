import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { apiClient } from '../services/api';
import { DishCard } from '../components/common/DishCard';
import { DishModal } from '../components/common/DishModal';
import { handleImageError } from '../services/imageUtils';
import { Clock, ShieldCheck, ArrowRight, Utensils, Calendar, Sparkles } from 'lucide-react';

export const HomePage = () => {
  const [popularDishes, setPopularDishes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDish, setSelectedDish] = useState(null);

  useEffect(() => {
    const fetchPopular = async () => {
      try {
        const data = await apiClient('/menu?popular=true');
        if (data.success && data.items) {
          setPopularDishes(data.items);
        }
      } catch (err) {
        console.error('Failed to load popular dishes:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchPopular();
  }, []);

  const categories = [
    { name: 'Starters', emoji: '🍲', count: '6 items', desc: 'Misal, Vada Pav, Paneer Tikka' },
    { name: 'Mains', emoji: '🍗', count: '8 items', desc: 'Butter Chicken, Dal Makhani, Rogan Josh' },
    { name: 'Breads', emoji: '🫓', count: '4 items', desc: 'Tandoori Roti, Naan, Laccha Paratha' },
    { name: 'Rice', emoji: '🍛', count: '3 items', desc: 'Hyderabadi Biryani, Veg Dum, Jeera Rice' },
    { name: 'Desserts', emoji: '🍮', count: '5 items', desc: 'Gulab Jamun, Mango Shrikhand, Puran Poli' },
    { name: 'Drinks', emoji: '☕', count: '5 items', desc: 'Kadai Masala Chai, Sol Kadhi, Mango Lassi' },
  ];

  return (
    <div className="main-content" style={{ paddingBlock: '1.5rem 4rem' }}>
      <div className="wrap">
        {/* Hero Section */}
        <section
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
            gap: '3rem',
            alignItems: 'center',
            marginBottom: '4.5rem',
          }}
        >
          <div>
            <span
              className="badge saffron"
              style={{ marginBottom: '1.2rem', padding: '0.35rem 0.9rem', fontSize: '0.85rem' }}
            >
              <Sparkles size={14} /> Modern Indian Kitchen in Pune
            </span>
            <h1 style={{ fontSize: 'clamp(2.5rem, 5.5vw, 4.2rem)', fontWeight: 800, marginBottom: '1.25rem' }}>
              Slow-cooked classics, fast Pune evenings.
            </h1>
            <p style={{ fontSize: '1.18rem', color: 'var(--muted)', maxWidth: '44ch', margin: '0 0 2rem', lineHeight: 1.6 }}>
              Misal, biryani, tandoor and sweets from a kitchen that grinds its own masalas every morning in Koregaon Park.
            </p>

            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.85rem' }}>
              <Link to="/menu" className="btn lg">
                <Utensils size={18} /> See the Menu
              </Link>
              <Link to="/reserve" className="btn lg alt">
                <Calendar size={18} /> Reserve a Table
              </Link>
            </div>

            <ul
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                gap: '1.2rem 2rem',
                margin: '2.5rem 0 0',
                padding: 0,
                listStyle: 'none',
                color: 'var(--muted)',
                fontSize: '0.95rem',
              }}
            >
              <li style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Clock size={18} color="var(--green)" />
                <span><b>12:00 – 23:00</b> open daily</span>
              </li>
              <li style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <ShieldCheck size={18} color="var(--green)" />
                <span><b>Veg & non-veg</b> kitchens kept separate</span>
              </li>
            </ul>
          </div>

          {/* Mosaic Gallery */}
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gridTemplateRows: 'repeat(2, 170px)',
              gap: '1rem',
            }}
          >
            <div style={{ gridRow: 'span 2', borderRadius: 'var(--r)', overflow: 'hidden', boxShadow: 'var(--card-shadow)' }}>
              <img
                src="/images/misal.jpg"
                alt="Puneri spicy misal with farsan and soft pav"
                style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                onError={(e) => handleImageError(e, { dishKey: 'misal', emoji: '🍲', gradient: ['#f28c28', '#b3202f'] })}
              />
            </div>
            <div style={{ borderRadius: 'var(--r)', overflow: 'hidden', boxShadow: 'var(--card-shadow)' }}>
              <img
                src="/images/biryani.jpg"
                alt="Chicken dum biryani with fried onions"
                style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                onError={(e) => handleImageError(e, { dishKey: 'biryani', emoji: '🍛', gradient: ['#f2a900', '#a8610f'] })}
              />
            </div>
            <div style={{ borderRadius: 'var(--r)', overflow: 'hidden', boxShadow: 'var(--card-shadow)' }}>
              <img
                src="/images/jamun.jpg"
                alt="Warm gulab jamun in cardamom syrup"
                style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                onError={(e) => handleImageError(e, { dishKey: 'jamun', emoji: '🍮', gradient: ['#c2255c', '#6a0f34'] })}
              />
            </div>
          </div>
        </section>

        {/* Most Ordered This Week Section */}
        <section style={{ marginBottom: '4.5rem' }}>
          <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'flex-end', justifyContent: 'space-between', gap: '1rem', marginBottom: '1.75rem' }}>
            <div>
              <h2 style={{ fontSize: 'clamp(1.8rem, 3.5vw, 2.5rem)', fontWeight: 800 }}>
                Most Ordered This Week
              </h2>
              <p style={{ color: 'var(--muted)', margin: '0.35rem 0 0' }}>
                These dishes leave our kitchen the fastest. Made fresh daily with slow-simmered hand-ground masalas.
              </p>
            </div>
            <Link to="/menu" className="btn sm alt" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem' }}>
              View full menu <ArrowRight size={16} />
            </Link>
          </div>

          {loading ? (
            <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--muted)' }}>
              Loading popular dishes from Kadai Lane kitchen...
            </div>
          ) : (
            <div className="dish-grid">
              {popularDishes.slice(0, 4).map((dish) => (
                <DishCard key={dish._id} dish={dish} onQuickView={setSelectedDish} />
              ))}
            </div>
          )}
        </section>

        {/* Categories Section */}
        <section style={{ marginBottom: '4.5rem' }}>
          <div style={{ textAlign: 'center', maxWidth: '600px', margin: '0 auto 2.5rem' }}>
            <h2 style={{ fontSize: 'clamp(1.8rem, 3.5vw, 2.5rem)', fontWeight: 800, marginBottom: '0.5rem' }}>
              Explore by Category
            </h2>
            <p style={{ color: 'var(--muted)', margin: 0 }}>
              From sizzling street starters to slow-cooked handi mains and decadent Maharashtrian sweets.
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '1.25rem' }}>
            {categories.map((cat, i) => (
              <Link
                key={i}
                to={`/menu?category=${encodeURIComponent(cat.name)}`}
                className="card"
                style={{
                  padding: '1.5rem',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '1.2rem',
                  transition: 'transform 0.2s ease, border-color 0.2s ease',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-3px)';
                  e.currentTarget.style.borderColor = 'var(--green)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.borderColor = 'var(--line)';
                }}
              >
                <div
                  style={{
                    fontSize: '2.2rem',
                    background: 'var(--soft)',
                    width: '60px',
                    height: '60px',
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexShrink: 0,
                  }}
                >
                  {cat.emoji}
                </div>
                <div>
                  <h3 style={{ fontSize: '1.2rem', marginBottom: '0.2rem' }}>{cat.name}</h3>
                  <div style={{ fontSize: '0.82rem', color: 'var(--muted)', marginBottom: '0.3rem' }}>{cat.desc}</div>
                  <span style={{ fontSize: '0.8rem', color: 'var(--green)', fontWeight: 700 }}>
                    {cat.count} →
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* Table Reservation Teaser Card */}
        <section
          className="card"
          style={{
            background: 'var(--green)',
            color: 'var(--on-green)',
            padding: 'clamp(2rem, 5vw, 3.5rem)',
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
            gap: '2.5rem',
            alignItems: 'center',
          }}
        >
          <div>
            <h2 style={{ fontSize: 'clamp(2rem, 4vw, 3rem)', color: '#ffffff', marginBottom: '1rem' }}>
              Save us a table.
            </h2>
            <p style={{ fontSize: '1.05rem', opacity: 0.92, lineHeight: 1.6, margin: '0 0 1.5rem', maxWidth: '44ch' }}>
              Pick a date, time slot, and indoor or terrace seating. We confirm your table instantly and will have everything ready when you arrive.
            </p>
            <Link to="/reserve" className="btn saffron lg" style={{ fontWeight: 800 }}>
              <Calendar size={18} /> Book a Table Now
            </Link>
          </div>

          <div
            style={{
              background: 'rgba(255, 255, 255, 0.1)',
              backdropFilter: 'blur(10px)',
              borderRadius: '16px',
              padding: '1.75rem',
              border: '1px solid rgba(255, 255, 255, 0.2)',
            }}
          >
            <h3 style={{ fontSize: '1.25rem', color: '#ffffff', marginBottom: '1rem' }}>
              Dining Hours & Policy
            </h3>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'grid', gap: '0.75rem', fontSize: '0.95rem' }}>
              <li style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid rgba(255,255,255,0.2)', paddingBottom: '0.5rem' }}>
                <span>Mon – Thu</span>
                <b>12:00 – 22:30</b>
              </li>
              <li style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid rgba(255,255,255,0.2)', paddingBottom: '0.5rem' }}>
                <span>Fri – Sat</span>
                <b>12:00 – 23:30</b>
              </li>
              <li style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid rgba(255,255,255,0.2)', paddingBottom: '0.5rem' }}>
                <span>Sunday</span>
                <b>11:00 – 22:30</b>
              </li>
              <li style={{ display: 'flex', justifyContent: 'space-between', paddingTop: '0.2rem', opacity: 0.85, fontSize: '0.85rem' }}>
                <span>Groups over 8 guests</span>
                <b>Call +91 98230 45678</b>
              </li>
            </ul>
          </div>
        </section>
      </div>

      {/* Dish Quick View Modal */}
      {selectedDish && (
        <DishModal dish={selectedDish} onClose={() => setSelectedDish(null)} />
      )}
    </div>
  );
};
