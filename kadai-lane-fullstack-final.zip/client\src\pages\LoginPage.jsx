import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { LogIn, AlertCircle, ShieldCheck } from 'lucide-react';

export const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const from = location.state?.from?.pathname || '/dashboard';

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await login(email, password);
      navigate(from, { replace: true });
    } catch (err) {
      setError(err.message || 'Login failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoFill = (type) => {
    if (type === 'admin') {
      setEmail('admin@kadailane.in');
      setPassword('Admin@12345');
    } else {
      setEmail('rahul@example.com');
      setPassword('Rahul@123');
    }
  };

  return (
    <div className="main-content wrap" style={{ padding: '3rem 1rem' }}>
      <div className="card" style={{ maxWidth: '460px', margin: '0 auto', padding: '2.5rem' }}>
        <div style={{ textAlign: 'center', marginBottom: '1.75rem' }}>
          <h1 style={{ fontSize: '2rem', marginBottom: '0.4rem' }}>Welcome Back</h1>
          <p style={{ color: 'var(--muted)', fontSize: '0.95rem', margin: 0 }}>
            Sign in to track orders, manage reservations and view your Kadai Lane profile.
          </p>
        </div>

        {error && (
          <div className="alert error">
            <AlertCircle size={18} />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Email Address</label>
            <input
              type="email"
              required
              placeholder="e.g. yourname@gmail.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label>Password</label>
            <input
              type="password"
              required
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn full lg saffron"
            style={{ fontWeight: 800, marginTop: '0.75rem' }}
          >
            <LogIn size={18} />
            {loading ? 'Authenticating...' : 'Sign In'}
          </button>
        </form>

        {/* Quick Demo Logins for Examiner / Viva Evaluation */}
        <div style={{ marginTop: '2rem', paddingTop: '1.25rem', borderTop: '1px solid var(--line)', textAlign: 'center' }}>
          <span style={{ fontSize: '0.82rem', color: 'var(--muted)', display: 'block', marginBottom: '0.65rem', fontWeight: 600 }}>
            ⚡ Project Viva Evaluation Quick Fill:
          </span>
          <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'center' }}>
            <button
              type="button"
              className="btn sm alt"
              onClick={() => handleDemoFill('admin')}
              style={{ fontSize: '0.8rem', padding: '0.3rem 0.75rem' }}
            >
              <ShieldCheck size={14} color="var(--green)" /> Admin Demo
            </button>
            <button
              type="button"
              className="btn sm alt"
              onClick={() => handleDemoFill('customer')}
              style={{ fontSize: '0.8rem', padding: '0.3rem 0.75rem' }}
            >
              Customer Demo
            </button>
          </div>
        </div>

        <div style={{ marginTop: '1.5rem', textAlign: 'center', fontSize: '0.92rem', color: 'var(--muted)' }}>
          Don't have an account?{' '}
          <Link to="/register" style={{ color: 'var(--green)', fontWeight: 700 }}>
            Create one here
          </Link>
        </div>
      </div>
    </div>
  );
};
