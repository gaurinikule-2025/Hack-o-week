import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { apiClient } from '../services/api';
import { DishCard } from '../components/common/DishCard';
import { DishModal } from '../components/common/DishModal';
import { Search, X, Filter, Sparkles } from 'lucide-react';

export const MenuPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialCategory = searchParams.get('category') || 'All';

  const [dishes, setDishes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState(initialCategory);
  const [searchQuery, setSearchQuery] = useState('');
  const [vegOnly, setVegOnly] = useState(false);
  const [sortBy, setSortBy] = useState('default');
  const [selectedDish, setSelectedDish] = useState(null);

  const categories = ['All', 'Starters', 'Mains', 'Breads', 'Rice', 'Desserts', 'Drinks'];

  useEffect(() => {
    const fetchMenu = async () => {
      setLoading(true);
      try {
        const data = await apiClient('/menu');
        if (data.success && data.items) {
          setDishes(data.items);
        }
      } catch (err) {
        console.error('Failed to load menu:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchMenu();
  }, []);

  // Sync category state if URL parameter changes
  useEffect(() => {
    const cat = searchParams.get('category');
    if (cat && categories.includes(cat)) {
      setActiveCategory(cat);
    }
  }, [searchParams]);

  const handleCategoryChange = (cat) => {
    setActiveCategory(cat);
    if (cat === 'All') {
      searchParams.delete('category');
    } else {
      searchParams.set('category', cat);
    }
    setSearchParams(searchParams);
  };

  // Filter and sort items
  const filteredDishes = dishes.filter((dish) => {
    const matchCategory = activeCategory === 'All' || dish.category === activeCategory;
    const matchVeg = vegOnly ? dish.isVeg === true : true;
    const matchSearch =
      searchQuery.trim() === '' ||
      dish.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      dish.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (dish.tags && dish.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase())));

    return matchCategory && matchVeg && matchSearch;
  });

  const sortedDishes = [...filteredDishes].sort((a, b) => {
    if (sortBy === 'price-asc') return a.price - b.price;
    if (sortBy === 'price-desc') return b.price - a.price;
    if (sortBy === 'name') return a.name.localeCompare(b.name);
    return 0; // Default order
  });

  return (
    <div className="main-content">
      <div className="wrap">
        {/* Menu Header */}
        <div style={{ marginBottom: '2rem' }}>
          <span className="badge saffron" style={{ marginBottom: '0.75rem' }}>
            <Sparkles size={13} /> The Complete Food Catalogue
          </span>
          <h1 style={{ fontSize: 'clamp(2.2rem, 4.5vw, 3.2rem)', fontWeight: 800, marginBottom: '0.5rem' }}>
            Our Kitchen Menu
          </h1>
          <p style={{ color: 'var(--muted)', margin: 0, maxWidth: '60ch' }}>
            Every masala ground fresh in the morning. Real Pune flavors, clay tandoor breads, and fragrant dum rice.
          </p>
        </div>

        {/* Filter Controls Row */}
        <div
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '1rem',
            marginBottom: '1.5rem',
          }}
        >
          {/* Category Chips */}
          <ul className="chips" style={{ flex: 1, minWidth: '280px' }}>
            {categories.map((cat) => (
              <li key={cat}>
                <button
                  type="button"
                  className="chip"
                  aria-pressed={activeCategory === cat}
                  onClick={() => handleCategoryChange(cat)}
                >
                  {cat}
                </button>
              </li>
            ))}
          </ul>

          {/* Quick Filters: Veg Toggle & Sort */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
            <label
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.45rem',
                cursor: 'pointer',
                userSelect: 'none',
                background: vegOnly ? 'var(--soft)' : 'transparent',
                padding: '0.45rem 0.85rem',
                borderRadius: '999px',
                border: '1px solid var(--line)',
                fontSize: '0.88rem',
              }}
            >
              <input
                type="checkbox"
                checked={vegOnly}
                onChange={(e) => setVegOnly(e.target.checked)}
                style={{ width: '16px', height: '16px', accentColor: '#1b7a3a' }}
              />
              <span className="diet veg" style={{ fontSize: '0.85rem' }}>Veg Only</span>
            </label>

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              style={{ width: 'auto', padding: '0.45rem 0.85rem', fontSize: '0.88rem', borderRadius: '999px' }}
            >
              <option value="default">Sort by: Default</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="name">Name (A-Z)</option>
            </select>
          </div>
        </div>

        {/* Search Bar & Result Count */}
        <div
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '1rem',
            paddingBottom: '1.25rem',
            borderBottom: '1px solid var(--line)',
            marginBottom: '2rem',
          }}
        >
          <div style={{ position: 'relative', width: 'min(380px, 100%)' }}>
            <Search
              size={18}
              style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--muted)' }}
            />
            <input
              type="text"
              placeholder="Search by dish name, spice, or ingredient..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{ paddingLeft: '2.4rem', paddingRight: searchQuery ? '2.4rem' : '0.85rem' }}
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                style={{
                  position: 'absolute',
                  right: '10px',
                  top: '50%',
                  transform: 'translateY(-50%)',
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                  color: 'var(--muted)',
                }}
              >
                <X size={16} />
              </button>
            )}
          </div>

          <p style={{ margin: 0, color: 'var(--muted)', fontSize: '0.92rem' }}>
            Showing <b>{sortedDishes.length}</b> {activeCategory === 'All' ? 'dishes' : activeCategory.toLowerCase()}
            {vegOnly ? ' (Vegetarian)' : ''}.
          </p>
        </div>

        {/* Dish Grid Display */}
        {loading ? (
          <div style={{ textAlign: 'center', padding: '4rem 0', color: 'var(--muted)' }}>
            <div style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>🍲</div>
            Loading Kadai Lane menu from MongoDB database...
          </div>
        ) : sortedDishes.length > 0 ? (
          <div className="dish-grid">
            {sortedDishes.map((dish) => (
              <DishCard key={dish._id} dish={dish} onQuickView={setSelectedDish} />
            ))}
          </div>
        ) : (
          <div
            className="card"
            style={{
              textAlign: 'center',
              padding: '4rem 2rem',
              maxWidth: '500px',
              margin: '2rem auto',
            }}
          >
            <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🍽️</div>
            <h3 style={{ fontSize: '1.4rem', marginBottom: '0.5rem' }}>No dishes match your filter</h3>
            <p style={{ color: 'var(--muted)', marginBottom: '1.5rem', fontSize: '0.95rem' }}>
              We couldn't find any dishes matching "{searchQuery}" in {activeCategory}. Try clearing your filters or searching another keyword.
            </p>
            <button
              type="button"
              className="btn sm"
              onClick={() => {
                setActiveCategory('All');
                setSearchQuery('');
                setVegOnly(false);
                searchParams.delete('category');
                setSearchParams(searchParams);
              }}
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>

      {/* Quick View Modal */}
      {selectedDish && (
        <DishModal dish={selectedDish} onClose={() => setSelectedDish(null)} />
      )}
    </div>
  );
};
