import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { apiClient } from '../services/api';
import { Package, ChevronRight, Clock, ArrowRight } from 'lucide-react';

export const MyOrdersPage = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('All');

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const data = await apiClient('/orders/my-orders');
        if (data.success && data.orders) {
          setOrders(data.orders);
        }
      } catch (err) {
        console.error('Failed to load orders:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, []);

  const filteredOrders = orders.filter((order) => {
    if (filter === 'Active') {
      return !['Delivered', 'Cancelled'].includes(order.orderStatus);
    }
    if (filter === 'Completed') {
      return order.orderStatus === 'Delivered';
    }
    if (filter === 'Cancelled') {
      return order.orderStatus === 'Cancelled';
    }
    return true;
  });

  return (
    <div className="main-content">
      <div className="wrap">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
          <div>
            <h1 style={{ fontSize: 'clamp(2rem, 4vw, 2.6rem)', fontWeight: 800 }}>My Orders History</h1>
            <p style={{ color: 'var(--muted)', margin: 0 }}>Review all your previous and active orders at Kadai Lane.</p>
          </div>
          <Link to="/menu" className="btn sm">
            Order More Food
          </Link>
        </div>

        {/* Filter Pills */}
        <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1.5rem', overflowX: 'auto', paddingBottom: '0.5rem' }}>
          {['All', 'Active', 'Completed', 'Cancelled'].map((tab) => (
            <button
              key={tab}
              type="button"
              className={`chip ${filter === tab ? 'active' : ''}`}
              aria-pressed={filter === tab}
              onClick={() => setFilter(tab)}
            >
              {tab} ({tab === 'All' ? orders.length : orders.filter((o) => {
                if (tab === 'Active') return !['Delivered', 'Cancelled'].includes(o.orderStatus);
                if (tab === 'Completed') return o.orderStatus === 'Delivered';
                if (tab === 'Cancelled') return o.orderStatus === 'Cancelled';
                return true;
              }).length})
            </button>
          ))}
        </div>

        {/* Order List */}
        {loading ? (
          <div style={{ textAlign: 'center', padding: '4rem 0', color: 'var(--muted)' }}>
            Loading your orders...
          </div>
        ) : filteredOrders.length > 0 ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
            {filteredOrders.map((order) => (
              <div
                key={order._id}
                className="card"
                style={{
                  padding: '1.5rem',
                  display: 'flex',
                  flexWrap: 'wrap',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: '1.5rem',
                }}
              >
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', marginBottom: '0.35rem' }}>
                    <span style={{ fontWeight: 800, fontSize: '1.1rem' }}>#{order.orderNumber}</span>
                    <span className={`badge ${order.orderStatus === 'Delivered' ? 'green' : order.orderStatus === 'Cancelled' ? 'red' : 'saffron'}`}>
                      {order.orderStatus}
                    </span>
                    <span style={{ fontSize: '0.8rem', color: 'var(--muted)' }}>
                      • {order.orderType}
                    </span>
                  </div>

                  <div style={{ fontSize: '0.88rem', color: 'var(--muted)', marginBottom: '0.5rem' }}>
                    Placed on {new Date(order.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </div>

                  <div style={{ fontSize: '0.92rem' }}>
                    {order.items.map((it) => `${it.quantity}× ${it.name}`).join(', ')}
                  </div>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '1.5rem' }}>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: '0.8rem', color: 'var(--muted)' }}>Total Amount</div>
                    <div className="price" style={{ fontSize: '1.3rem', color: 'var(--green)' }}>
                      ₹{order.total}
                    </div>
                  </div>

                  <Link to={`/orders/${order.orderNumber}`} className="btn sm alt" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                    Track Order <ChevronRight size={16} />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="card" style={{ textAlign: 'center', padding: '4rem 1rem' }}>
            <Package size={48} style={{ opacity: 0.4, marginBottom: '1rem' }} />
            <h3 style={{ fontSize: '1.3rem', marginBottom: '0.5rem' }}>No orders in this section</h3>
            <p style={{ color: 'var(--muted)', marginBottom: '1.5rem' }}>You don't have any orders matching the "{filter}" filter.</p>
            <Link to="/menu" className="btn sm">Browse Menu</Link>
          </div>
        )}
      </div>
    </div>
  );
};
