import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { apiClient } from '../services/api';
import { Calendar, Users, Clock, AlertCircle, XCircle } from 'lucide-react';

export const MyReservationsPage = () => {
  const [reservations, setReservations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [cancellingId, setCancellingId] = useState(null);

  const fetchReservations = async () => {
    try {
      const data = await apiClient('/reservations/my/all');
      if (data.success && data.reservations) {
        setReservations(data.reservations);
      }
    } catch (err) {
      console.error('Failed to load reservations:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReservations();
  }, []);

  const handleCancel = async (id) => {
    if (!window.confirm('Are you sure you want to cancel this table reservation?')) {
      return;
    }

    setCancellingId(id);
    try {
      const res = await apiClient(`/reservations/${id}/cancel`, {
        method: 'PATCH',
        body: { reason: 'Cancelled by customer' },
      });

      if (res.success) {
        fetchReservations();
      }
    } catch (err) {
      alert(err.message || 'Failed to cancel reservation.');
    } finally {
      setCancellingId(null);
    }
  };

  return (
    <div className="main-content">
      <div className="wrap">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
          <div>
            <h1 style={{ fontSize: 'clamp(2rem, 4vw, 2.6rem)', fontWeight: 800 }}>My Table Bookings</h1>
            <p style={{ color: 'var(--muted)', margin: 0 }}>View and manage your upcoming dining reservations at Kadai Lane.</p>
          </div>
          <Link to="/reserve" className="btn sm">
            Book Another Table
          </Link>
        </div>

        {loading ? (
          <div style={{ textAlign: 'center', padding: '4rem 0', color: 'var(--muted)' }}>
            Loading reservations...
          </div>
        ) : reservations.length > 0 ? (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '1.5rem' }}>
            {reservations.map((res) => {
              const isPast = new Date(res.date + 'T23:59:59') < new Date();
              const canCancel = res.status === 'Confirmed' && !isPast;

              return (
                <div key={res._id} className="card" style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1rem' }}>
                    <div>
                      <span style={{ fontSize: '0.8rem', color: 'var(--muted)', display: 'block' }}>Reference</span>
                      <b style={{ fontSize: '1.1rem', color: 'var(--green)' }}>#{res.reservationNumber}</b>
                    </div>
                    <span className={`badge ${res.status === 'Confirmed' ? 'green' : res.status === 'Cancelled' ? 'red' : 'gray'}`}>
                      {res.status}
                    </span>
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem', fontSize: '0.92rem', marginBottom: '1.5rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <Calendar size={16} color="var(--green)" />
                      <span>
                        Date: <b>{new Date(res.date + 'T00:00:00').toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' })}</b>
                      </span>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <Clock size={16} color="var(--green)" />
                      <span>Time: <b>{res.time}</b></span>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <Users size={16} color="var(--green)" />
                      <span>Party: <b>{res.guests} Guests</b> ({res.seatingArea})</span>
                    </div>

                    {res.specialRequests && (
                      <div style={{ fontSize: '0.85rem', color: 'var(--muted)', fontStyle: 'italic', background: 'var(--soft)', padding: '0.5rem 0.75rem', borderRadius: '8px' }}>
                        "{res.specialRequests}"
                      </div>
                    )}
                  </div>

                  {canCancel && (
                    <button
                      type="button"
                      disabled={cancellingId === res._id}
                      onClick={() => handleCancel(res._id)}
                      className="btn sm alt"
                      style={{ marginTop: 'auto', color: 'var(--chili)', borderColor: 'var(--line)' }}
                    >
                      {cancellingId === res._id ? 'Cancelling...' : 'Cancel Reservation'}
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="card" style={{ textAlign: 'center', padding: '4rem 1rem' }}>
            <Calendar size={48} style={{ opacity: 0.4, marginBottom: '1rem' }} />
            <h3 style={{ fontSize: '1.3rem', marginBottom: '0.5rem' }}>No Table Reservations Found</h3>
            <p style={{ color: 'var(--muted)', marginBottom: '1.5rem' }}>You don't have any table reservations registered with your account.</p>
            <Link to="/reserve" className="btn sm">Book a Table</Link>
          </div>
        )}
      </div>
    </div>
  );
};
