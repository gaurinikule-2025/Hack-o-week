import React from 'react';
import { Link } from 'react-router-dom';
import { Utensils } from 'lucide-react';

export const NotFoundPage = () => {
  return (
    <div className="main-content wrap" style={{ textAlign: 'center', padding: '5rem 1rem' }}>
      <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>🍲</div>
      <h1 style={{ fontSize: '3rem', fontWeight: 800, marginBottom: '0.5rem' }}>404</h1>
      <h2 style={{ fontSize: '1.6rem', marginBottom: '1rem' }}>Page Not Found</h2>
      <p style={{ color: 'var(--muted)', maxWidth: '42ch', margin: '0 auto 2rem' }}>
        The recipe you're looking for doesn't exist on our menu or has moved to another address.
      </p>
      <Link to="/" className="btn lg">
        <Utensils size={18} /> Return to Homepage
      </Link>
    </div>
  );
};
