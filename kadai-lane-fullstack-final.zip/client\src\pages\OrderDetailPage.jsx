import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { apiClient } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { handleImageError, generateDishSvg } from '../services/imageUtils';
import {
  CheckCircle2,
  Clock,
  Truck,
  PackageCheck,
  AlertTriangle,
  ArrowLeft,
  XCircle,
  MapPin,
  Phone,
  ShieldCheck,
} from 'lucide-react';

export const OrderDetailPage = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [cancelling, setCancelling] = useState(false);
  const [cancelReason, setCancelReason] = useState('');
  const [showCancelPrompt, setShowCancelPrompt] = useState(false);

  const fetchOrder = async () => {
    try {
      const data = await apiClient(`/orders/${id}`);
      if (data.success && data.order) {
        setOrder(data.order);
      }
    } catch (err) {
      setError(err.message || 'Failed to find order.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrder();
    // Poll every 10 seconds for live order status update if order is active
    const interval = setInterval(() => {
      if (order && !['Delivered', 'Cancelled'].includes(order.orderStatus)) {
        fetchOrder();
      }
    }, 10000);

    return () => clearInterval(interval);
  }, [id, order?.orderStatus]);

  const handleCancelOrder = async () => {
    setCancelling(true);
    try {
      const res = await apiClient(`/orders/${order._id}/cancel`, {
        method: 'PATCH',
        body: { reason: cancelReason || 'Cancelled by customer' },
      });

      if (res.success && res.order) {
        setOrder(res.order);
        setShowCancelPrompt(false);
      }
    } catch (err) {
      alert(err.message || 'Could not cancel order.');
    } finally {
      setCancelling(false);
    }
  };

  if (loading) {
    return (
      <div className="main-content wrap" style={{ textAlign: 'center', padding: '4rem 0' }}>
        <p style={{ color: 'var(--muted)' }}>Loading order #{id}...</p>
      </div>
    );
  }

  if (error || !order) {
    return (
      <div className="main-content wrap" style={{ textAlign: 'center', padding: '4rem 1rem' }}>
        <h2>Order Not Found</h2>
        <p style={{ color: 'var(--muted)', margin: '1rem 0 1.5rem' }}>{error || 'The requested order reference could not be located.'}</p>
        <Link to="/orders" className="btn sm">View My Orders</Link>
      </div>
    );
  }

  const steps = order.orderType === 'Pickup'
    ? ['Pending', 'Confirmed', 'Preparing', 'Ready for Pickup', 'Delivered']
    : ['Pending', 'Confirmed', 'Preparing', 'Out for Delivery', 'Delivered'];

  const currentStepIndex = steps.indexOf(order.orderStatus);
  const isCancelled = order.orderStatus === 'Cancelled';
  const canCancel = ['Pending', 'Confirmed'].includes(order.orderStatus);

  return (
    <div className="main-content">
      <div className="wrap">
        <Link to="/orders" className="btn sm alt" style={{ marginBottom: '1.5rem', display: 'inline-flex', alignItems: 'center', gap: '0.4rem' }}>
          <ArrowLeft size={16} /> Back to My Orders
        </Link>

        {/* Status Header */}
        <div className="card" style={{ padding: '2rem', marginBottom: '2rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.5rem' }}>
            <div>
              <span className="badge green" style={{ marginBottom: '0.4rem' }}>{order.orderType}</span>
              <h1 style={{ fontSize: 'clamp(1.8rem, 3.5vw, 2.4rem)' }}>Order #{order.orderNumber}</h1>
              <p style={{ color: 'var(--muted)', margin: '0.2rem 0 0', fontSize: '0.9rem' }}>
                Placed on {new Date(order.createdAt).toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>

            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: '0.85rem', color: 'var(--muted)', marginBottom: '0.3rem' }}>Current Kitchen Status</div>
              <span className={`badge ${isCancelled ? 'red' : order.orderStatus === 'Delivered' ? 'green' : 'saffron'}`} style={{ fontSize: '1rem', padding: '0.35rem 1rem' }}>
                {order.orderStatus}
              </span>
            </div>
          </div>

          {/* Stepper Progress Bar */}
          {!isCancelled ? (
            <div style={{ margin: '2.5rem 0 1.5rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', position: 'relative', marginBottom: '0.75rem' }}>
                <div style={{ position: 'absolute', top: '16px', left: '10px', right: '10px', height: '3px', background: 'var(--line)', zIndex: 1 }} />
                {steps.map((step, idx) => {
                  const isDone = idx <= currentStepIndex;
                  const isCurrent = idx === currentStepIndex;
                  return (
                    <div key={step} style={{ position: 'relative', zIndex: 2, display: 'flex', flexDirection: 'column', alignItems: 'center', width: '80px', textAlign: 'center' }}>
                      <div
                        style={{
                          width: '34px',
                          height: '34px',
                          borderRadius: '50%',
                          background: isDone ? 'var(--green)' : 'var(--surface)',
                          border: `3px solid ${isDone ? 'var(--green)' : 'var(--line)'}`,
                          color: isDone ? 'var(--on-green)' : 'var(--muted)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontWeight: 800,
                          fontSize: '0.82rem',
                          marginBottom: '0.5rem',
                          boxShadow: isCurrent ? '0 0 0 4px var(--soft)' : 'none',
                        }}
                      >
                        {isDone ? '✓' : idx + 1}
                      </div>
                      <span style={{ fontSize: '0.78rem', fontWeight: isCurrent ? 800 : 500, color: isCurrent ? 'var(--ink)' : 'var(--muted)' }}>
                        {step}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="alert error" style={{ margin: '1rem 0' }}>
              <XCircle size={18} />
              <span><b>This order was cancelled.</b> Reason: {order.cancellationReason || 'Cancelled upon request.'}</span>
            </div>
          )}

          {/* Cancellation Control if eligible */}
          {canCancel && (
            <div style={{ marginTop: '1.5rem', borderTop: '1px solid var(--line)', paddingTop: '1rem', display: 'flex', justifyContent: 'flex-end' }}>
              {!showCancelPrompt ? (
                <button
                  type="button"
                  className="btn sm alt"
                  style={{ color: 'var(--chili)', borderColor: 'var(--chili)' }}
                  onClick={() => setShowCancelPrompt(true)}
                >
                  Cancel This Order
                </button>
              ) : (
                <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center', flexWrap: 'wrap' }}>
                  <input
                    type="text"
                    placeholder="Reason for cancellation (optional)"
                    value={cancelReason}
                    onChange={(e) => setCancelReason(e.target.value)}
                    style={{ width: '260px', padding: '0.4rem 0.75rem', fontSize: '0.85rem' }}
                  />
                  <button
                    type="button"
                    className="btn sm chili"
                    disabled={cancelling}
                    onClick={handleCancelOrder}
                  >
                    {cancelling ? 'Cancelling...' : 'Confirm Cancel'}
                  </button>
                  <button
                    type="button"
                    className="btn sm alt"
                    onClick={() => setShowCancelPrompt(false)}
                  >
                    Keep Order
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Order Details & Summary Two-Column */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '2rem', alignItems: 'flex-start' }}>
          {/* Items List */}
          <div className="card" style={{ padding: '1.75rem' }}>
            <h3 style={{ fontSize: '1.25rem', marginBottom: '1.25rem', borderBottom: '1px solid var(--line)', paddingBottom: '0.5rem' }}>
              Ordered Items ({order.items.length})
            </h3>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              {order.items.map((item, idx) => {
                const imgSrc = item.image && item.image.trim() !== ''
                  ? item.image
                  : generateDishSvg(item);

                return (
                  <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '1rem', borderBottom: '1px solid var(--line)', paddingBottom: '0.85rem' }}>
                    <img
                      src={imgSrc}
                      alt={item.name}
                      style={{ width: '60px', height: '60px', borderRadius: '10px', objectFit: 'cover' }}
                      onError={(e) => handleImageError(e, item)}
                    />
                    <div style={{ flex: 1 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                        <span className={`diet ${item.isVeg ? 'veg' : 'nv'}`} style={{ fontSize: '0.75rem' }} />
                        <h4 style={{ margin: 0, fontSize: '1.05rem' }}>{item.name}</h4>
                      </div>
                      <span style={{ fontSize: '0.82rem', color: 'var(--muted)' }}>
                        ₹{item.price} × {item.quantity}
                      </span>
                    </div>
                    <b style={{ fontSize: '1.05rem' }}>₹{item.itemTotal || item.price * item.quantity}</b>
                  </div>
                );
              })}
            </div>

            {/* Bill Summary */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem', marginTop: '1.25rem', fontSize: '0.92rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--muted)' }}>Subtotal</span>
                <span>₹{order.subtotal}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--muted)' }}>GST & Taxes</span>
                <span>₹{order.tax}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--muted)' }}>Delivery Charge</span>
                <span>{order.deliveryFee === 0 ? <b style={{ color: 'var(--green)' }}>FREE</b> : `₹${order.deliveryFee}`}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '2px solid var(--line)', paddingTop: '0.75rem', marginTop: '0.25rem' }}>
                <b style={{ fontSize: '1.15rem' }}>Total Paid / Payable</b>
                <span className="price" style={{ fontSize: '1.5rem', color: 'var(--green)' }}>₹{order.total}</span>
              </div>
            </div>
          </div>

          {/* Delivery & Payment Info */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            <div className="card" style={{ padding: '1.75rem' }}>
              <h3 style={{ fontSize: '1.25rem', marginBottom: '1rem', borderBottom: '1px solid var(--line)', paddingBottom: '0.5rem' }}>
                Fulfillment & Customer Info
              </h3>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem', fontSize: '0.92rem' }}>
                <div>
                  <span style={{ color: 'var(--muted)', display: 'block', fontSize: '0.8rem' }}>Recipient Name</span>
                  <b>{order.customerName}</b>
                </div>
                <div>
                  <span style={{ color: 'var(--muted)', display: 'block', fontSize: '0.8rem' }}>Contact Phone</span>
                  <b>{order.customerPhone}</b>
                </div>

                {order.orderType === 'Delivery' ? (
                  <div>
                    <span style={{ color: 'var(--muted)', display: 'block', fontSize: '0.8rem' }}>Delivery Address</span>
                    <b>
                      {order.deliveryAddress?.street}, {order.deliveryAddress?.area}, {order.deliveryAddress?.city} - {order.deliveryAddress?.pincode}
                    </b>
                  </div>
                ) : (
                  <div>
                    <span style={{ color: 'var(--muted)', display: 'block', fontSize: '0.8rem' }}>Pickup Counter</span>
                    <b>Kadai Lane Kitchen, 14 Lane 5, Koregaon Park, Pune 411001</b>
                  </div>
                )}

                {order.specialInstructions && (
                  <div>
                    <span style={{ color: 'var(--muted)', display: 'block', fontSize: '0.8rem' }}>Special Instructions</span>
                    <span style={{ fontStyle: 'italic' }}>"{order.specialInstructions}"</span>
                  </div>
                )}
              </div>
            </div>

            <div className="card" style={{ padding: '1.75rem' }}>
              <h3 style={{ fontSize: '1.25rem', marginBottom: '1rem', borderBottom: '1px solid var(--line)', paddingBottom: '0.5rem' }}>
                Payment Status
              </h3>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                <span style={{ color: 'var(--muted)' }}>Method</span>
                <b>{order.paymentMethod}</b>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ color: 'var(--muted)' }}>Status</span>
                <span className={`badge ${order.paymentStatus === 'Paid' ? 'green' : 'saffron'}`}>
                  {order.paymentStatus}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
