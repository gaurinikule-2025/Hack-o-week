import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { apiClient } from '../services/api';
import { Calendar, Clock, Users, CheckCircle2, AlertCircle, Sparkles } from 'lucide-react';

export const ReservationPage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  // Today in YYYY-MM-DD
  const todayStr = (() => {
    const d = new Date();
    d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
    return d.toISOString().slice(0, 10);
  })();

  const [date, setDate] = useState(todayStr);
  const [name, setName] = useState(user ? user.name : '');
  const [phone, setPhone] = useState(user ? user.phone : '');
  const [email, setEmail] = useState(user ? user.email : '');
  const [guests, setGuests] = useState(2);
  const [time, setTime] = useState('19:30');
  const [seatingArea, setSeatingArea] = useState('Indoor');
  const [specialRequests, setSpecialRequests] = useState('');

  const [availableSlots, setAvailableSlots] = useState([]);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [confirmedBooking, setConfirmedBooking] = useState(null);

  // Fetch slot availability whenever date changes
  useEffect(() => {
    const fetchSlots = async () => {
      setLoadingSlots(true);
      try {
        const data = await apiClient(`/reservations/availability?date=${date}`);
        if (data.success && data.slots) {
          setAvailableSlots(data.slots);
          // If current selected time is not available, pick first available
          const currentValid = data.slots.find((s) => s.time === time && s.isAvailable);
          if (!currentValid) {
            const firstOpen = data.slots.find((s) => s.isAvailable);
            if (firstOpen) setTime(firstOpen.time);
          }
        }
      } catch (err) {
        console.error('Failed to load slots:', err);
      } finally {
        setLoadingSlots(false);
      }
    };

    fetchSlots();
  }, [date]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!name.trim()) {
      setError('Please enter your full name.');
      return;
    }

    if (!/^\d{10}$/.test(phone.replace(/\s+/g, ''))) {
      setError('Please enter a valid 10-digit mobile number.');
      return;
    }

    if (!time) {
      setError('Please select an available dining time slot.');
      return;
    }

    setSubmitting(true);

    try {
      const response = await apiClient('/reservations', {
        method: 'POST',
        body: {
          name: name.trim(),
          phone: phone.trim(),
          email: email.trim(),
          date,
          time,
          guests: parseInt(guests, 10),
          seatingArea,
          specialRequests: specialRequests.trim(),
        },
      });

      if (response.success && response.reservation) {
        setConfirmedBooking(response.reservation);
      }
    } catch (err) {
      setError(err.message || 'Failed to complete reservation.');
    } finally {
      setSubmitting(false);
    }
  };

  if (confirmedBooking) {
    return (
      <div className="main-content wrap" style={{ padding: '3rem 1rem' }}>
        <div className="card" style={{ maxWidth: '640px', margin: '0 auto', padding: '3rem 2rem', textAlign: 'center' }}>
          <div style={{ color: 'var(--green)', display: 'inline-flex', marginBottom: '1rem' }}>
            <CheckCircle2 size={64} />
          </div>

          <span className="badge green" style={{ marginBottom: '1rem' }}>
            Status: {confirmedBooking.status}
          </span>

          <h2 style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>
            Table Reserved at Kadai Lane!
          </h2>

          <p style={{ color: 'var(--muted)', fontSize: '1rem', lineHeight: 1.6, margin: '0 auto 2rem', maxWidth: '48ch' }}>
            Thank you, <b>{confirmedBooking.name}</b>. We have reserved a table for <b>{confirmedBooking.guests} guests</b> on{' '}
            <b>{new Date(confirmedBooking.date + 'T00:00:00').toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</b> at{' '}
            <b>{confirmedBooking.time}</b> ({confirmedBooking.seatingArea} seating).
          </p>

          <div
            style={{
              background: 'var(--soft)',
              borderRadius: '12px',
              padding: '1.25rem',
              marginBottom: '2rem',
              textAlign: 'left',
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: '0.85rem',
              fontSize: '0.92rem',
            }}
          >
            <div>
              <span style={{ color: 'var(--muted)', display: 'block', fontSize: '0.8rem' }}>Reservation Reference</span>
              <b style={{ color: 'var(--green)', fontSize: '1.1rem' }}>#{confirmedBooking.reservationNumber}</b>
            </div>
            <div>
              <span style={{ color: 'var(--muted)', display: 'block', fontSize: '0.8rem' }}>Contact Phone</span>
              <b>{confirmedBooking.phone}</b>
            </div>
            <div>
              <span style={{ color: 'var(--muted)', display: 'block', fontSize: '0.8rem' }}>Restaurant Location</span>
              <b>14 Lane 5, Koregaon Park</b>
            </div>
            <div>
              <span style={{ color: 'var(--muted)', display: 'block', fontSize: '0.8rem' }}>Table Hold Policy</span>
              <b>Held for 15 mins</b>
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'center', gap: '1rem', flexWrap: 'wrap' }}>
            <Link to="/menu" className="btn">
              Explore Our Menu
            </Link>
            {user ? (
              <Link to="/reservations" className="btn alt">
                View My Reservations
              </Link>
            ) : (
              <button
                type="button"
                className="btn alt"
                onClick={() => {
                  setConfirmedBooking(null);
                  setDate(todayStr);
                }}
              >
                Book Another Table
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="main-content">
      <div className="wrap">
        {/* Banner Section */}
        <section
          className="card"
          style={{
            background: 'var(--green)',
            color: 'var(--on-green)',
            padding: 'clamp(1.5rem, 4vw, 3rem)',
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
            gap: '2.5rem',
            alignItems: 'start',
          }}
        >
          {/* Left Column: Info & Hours */}
          <div>
            <span className="badge saffron" style={{ marginBottom: '1rem', fontWeight: 700 }}>
              <Sparkles size={13} /> Dine-in Experience
            </span>
            <h1 style={{ fontSize: 'clamp(2.2rem, 5vw, 3.5rem)', color: '#ffffff', marginBottom: '1rem' }}>
              Save us a table.
            </h1>
            <p style={{ opacity: 0.92, fontSize: '1.05rem', lineHeight: 1.6, margin: '0 0 2rem', maxWidth: '44ch' }}>
              Pick a date and time slot and we’ll prepare your table in advance. For special requests or groups over 8 guests, please call us directly.
            </p>

            <div
              style={{
                background: 'rgba(255, 255, 255, 0.12)',
                borderRadius: '16px',
                padding: '1.5rem',
                border: '1px solid rgba(255, 255, 255, 0.2)',
              }}
            >
              <h3 style={{ fontSize: '1.2rem', color: '#ffffff', marginBottom: '1rem' }}>
                Restaurant Hours (Pune)
              </h3>
              <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'grid', gap: '0.6rem', fontSize: '0.92rem' }}>
                <li style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid rgba(255,255,255,0.2)', paddingBottom: '0.4rem' }}>
                  <span>Mon – Thu</span>
                  <b>12:00 – 22:30</b>
                </li>
                <li style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid rgba(255,255,255,0.2)', paddingBottom: '0.4rem' }}>
                  <span>Fri – Sat</span>
                  <b>12:00 – 23:30</b>
                </li>
                <li style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid rgba(255,255,255,0.2)', paddingBottom: '0.4rem' }}>
                  <span>Sunday</span>
                  <b>11:00 – 22:30</b>
                </li>
              </ul>
            </div>
          </div>

          {/* Right Column: Reservation Form */}
          <form
            onSubmit={handleSubmit}
            className="card"
            style={{
              padding: '2rem',
              color: 'var(--ink)',
              background: 'var(--surface)',
            }}
          >
            <h2 style={{ fontSize: '1.5rem', marginBottom: '0.2rem' }}>Reserve Your Table</h2>
            <p className="hint" style={{ marginBottom: '1.5rem' }}>Fields marked * are required.</p>

            {error && (
              <div className="alert error" style={{ marginBottom: '1.2rem' }}>
                <AlertCircle size={16} />
                <span>{error}</span>
              </div>
            )}

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div className="form-group">
                <label>Your Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ananya Deshmukh"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>

              <div className="form-group">
                <label>Mobile Number *</label>
                <input
                  type="tel"
                  required
                  placeholder="10-digit number"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                />
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: '1rem' }}>
              <div className="form-group">
                <label>Reservation Date *</label>
                <input
                  type="date"
                  min={todayStr}
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                />
              </div>

              <div className="form-group">
                <label>Number of Guests *</label>
                <select
                  value={guests}
                  onChange={(e) => setGuests(e.target.value)}
                >
                  <option value={1}>1 Guest</option>
                  <option value={2}>2 Guests</option>
                  <option value={3}>3 Guests</option>
                  <option value={4}>4 Guests</option>
                  <option value={5}>5 Guests</option>
                  <option value={6}>6 Guests</option>
                  <option value={7}>7 Guests</option>
                  <option value={8}>8 Guests</option>
                </select>
              </div>
            </div>

            {/* Time Slot Picker */}
            <div className="form-group">
              <label>Available Time Slot *</label>
              {loadingSlots ? (
                <div style={{ fontSize: '0.85rem', color: 'var(--muted)' }}>Checking capacity for {date}...</div>
              ) : (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(85px, 1fr))', gap: '0.5rem', marginTop: '0.3rem' }}>
                  {availableSlots.map((slot) => (
                    <button
                      key={slot.time}
                      type="button"
                      disabled={!slot.isAvailable}
                      onClick={() => setTime(slot.time)}
                      style={{
                        padding: '0.5rem 0.2rem',
                        fontSize: '0.85rem',
                        fontWeight: 700,
                        borderRadius: '8px',
                        border: '2px solid',
                        borderColor: time === slot.time ? 'var(--green)' : 'var(--line)',
                        background: time === slot.time ? 'var(--green)' : slot.isAvailable ? 'var(--bg)' : 'transparent',
                        color: time === slot.time ? 'var(--on-green)' : slot.isAvailable ? 'var(--ink)' : 'var(--muted)',
                        cursor: slot.isAvailable ? 'pointer' : 'not-allowed',
                        opacity: slot.isAvailable ? 1 : 0.4,
                      }}
                    >
                      {slot.time}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Seating Choice */}
            <div className="form-group">
              <label>Seating Preference</label>
              <div style={{ display: 'flex', gap: '1.5rem', marginTop: '0.3rem' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', cursor: 'pointer', fontWeight: 500 }}>
                  <input
                    type="radio"
                    name="seat"
                    value="Indoor"
                    checked={seatingArea === 'Indoor'}
                    onChange={() => setSeatingArea('Indoor')}
                    style={{ width: '16px', height: '16px', accentColor: 'var(--green)' }}
                  />
                  Indoor Dining
                </label>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', cursor: 'pointer', fontWeight: 500 }}>
                  <input
                    type="radio"
                    name="seat"
                    value="Terrace"
                    checked={seatingArea === 'Terrace'}
                    onChange={() => setSeatingArea('Terrace')}
                    style={{ width: '16px', height: '16px', accentColor: 'var(--green)' }}
                  />
                  Terrace Lounge
                </label>
              </div>
            </div>

            {/* Special Request */}
            <div className="form-group">
              <label>Celebration or Food Allergies</label>
              <textarea
                rows={2}
                placeholder="e.g. Birthday celebration, anniversary, high chair needed, Jain food preference."
                value={specialRequests}
                onChange={(e) => setSpecialRequests(e.target.value)}
              />
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="btn full saffron lg"
              style={{ fontWeight: 800, marginTop: '0.5rem' }}
            >
              {submitting ? 'Confirming Table...' : `Request Table for ${guests} Guests`}
            </button>
          </form>
        </section>
      </div>
    </div>
  );
};
