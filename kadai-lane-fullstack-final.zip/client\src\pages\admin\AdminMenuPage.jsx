import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { apiClient } from '../../services/api';
import { handleImageError, generateDishSvg } from '../../services/imageUtils';
import {
  Plus,
  Edit2,
  Trash2,
  Search,
  CheckCircle,
  XCircle,
  ArrowLeft,
  X,
  AlertCircle,
} from 'lucide-react';

export const AdminMenuPage = () => {
  const [dishes, setDishes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');

  // Modal states for Create / Edit
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingDish, setEditingDish] = useState(null);
  const [formError, setFormError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Form Fields
  const [formData, setFormData] = useState({
    name: '',
    category: 'Starters',
    price: '',
    isVeg: true,
    isAvailable: true,
    isPopular: false,
    description: '',
    image: '',
    spiceLevel: 'Medium',
    prepTime: '15-20 mins',
    tags: '',
  });

  const categories = ['Starters', 'Mains', 'Breads', 'Rice', 'Desserts', 'Drinks'];

  const fetchMenu = async () => {
    setLoading(true);
    try {
      // Pass all=true to get both available and unavailable dishes
      const data = await apiClient('/menu?all=true');
      if (data.success && data.items) {
        setDishes(data.items);
      }
    } catch (err) {
      console.error('Failed to load menu items:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMenu();
  }, []);

  const openCreateModal = () => {
    setEditingDish(null);
    setFormData({
      name: '',
      category: 'Starters',
      price: '',
      isVeg: true,
      isAvailable: true,
      isPopular: false,
      description: '',
      image: '',
      spiceLevel: 'Medium',
      prepTime: '15-20 mins',
      tags: '',
    });
    setFormError('');
    setIsModalOpen(true);
  };

  const openEditModal = (dish) => {
    setEditingDish(dish);
    setFormData({
      name: dish.name,
      category: dish.category,
      price: dish.price,
      isVeg: dish.isVeg,
      isAvailable: dish.isAvailable,
      isPopular: dish.isPopular || false,
      description: dish.description,
      image: dish.image || '',
      spiceLevel: dish.spiceLevel || 'Medium',
      prepTime: dish.prepTime || '15-20 mins',
      tags: dish.tags ? dish.tags.join(', ') : '',
    });
    setFormError('');
    setIsModalOpen(true);
  };

  const handleToggleAvailability = async (dish) => {
    try {
      const res = await apiClient(`/menu/${dish._id}/availability`, {
        method: 'PATCH',
      });
      if (res.success) {
        setDishes((prev) =>
          prev.map((d) => (d._id === dish._id ? { ...d, isAvailable: !d.isAvailable } : d))
        );
      }
    } catch (err) {
      alert(err.message || 'Failed to toggle availability.');
    }
  };

  const handleDeleteDish = async (dish) => {
    if (!window.confirm(`Are you sure you want to delete "${dish.name}" from the menu?`)) {
      return;
    }

    try {
      const res = await apiClient(`/menu/${dish._id}`, { method: 'DELETE' });
      if (res.success) {
        setDishes((prev) => prev.filter((d) => d._id !== dish._id));
      }
    } catch (err) {
      alert(err.message || 'Failed to delete dish.');
    }
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    setFormError('');

    if (!formData.name.trim() || !formData.price || !formData.description.trim()) {
      setFormError('Name, price and description are required.');
      return;
    }

    setSubmitting(true);

    try {
      const payload = {
        ...formData,
        price: Number(formData.price),
        tags: formData.tags
          ? formData.tags.split(',').map((t) => t.trim()).filter(Boolean)
          : [],
      };

      if (editingDish) {
        const res = await apiClient(`/menu/${editingDish._id}`, {
          method: 'PUT',
          body: payload,
        });
        if (res.success) {
          setIsModalOpen(false);
          fetchMenu();
        }
      } else {
        const res = await apiClient('/menu', {
          method: 'POST',
          body: payload,
        });
        if (res.success) {
          setIsModalOpen(false);
          fetchMenu();
        }
      }
    } catch (err) {
      setFormError(err.message || 'Failed to save menu item.');
    } finally {
      setSubmitting(false);
    }
  };

  const filteredDishes = dishes.filter((dish) => {
    const matchCat = category === 'All' || dish.category === category;
    const matchSearch =
      search.trim() === '' ||
      dish.name.toLowerCase().includes(search.toLowerCase()) ||
      dish.description.toLowerCase().includes(search.toLowerCase());

    return matchCat && matchSearch;
  });

  return (
    <div className="main-content">
      <div className="wrap">
        <Link to="/admin" className="btn sm alt" style={{ marginBottom: '1.5rem', display: 'inline-flex', alignItems: 'center', gap: '0.4rem' }}>
          <ArrowLeft size={16} /> Back to Dashboard
        </Link>

        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
          <div>
            <h1 style={{ fontSize: 'clamp(2rem, 4vw, 2.6rem)', fontWeight: 800 }}>Menu Catalog Management</h1>
            <p style={{ color: 'var(--muted)', margin: 0 }}>Add, edit, change prices, and toggle dish availability.</p>
          </div>

          <button type="button" className="btn saffron" onClick={openCreateModal} style={{ fontWeight: 800 }}>
            <Plus size={18} /> Add New Dish
          </button>
        </div>

        {/* Filter & Search Bar */}
        <div className="card" style={{ padding: '1rem', marginBottom: '1.5rem', display: 'flex', flexWrap: 'wrap', gap: '1rem', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', alignItems: 'center' }}>
            <span style={{ fontSize: '0.88rem', fontWeight: 700, color: 'var(--muted)' }}>Category:</span>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              style={{ width: 'auto', padding: '0.45rem 0.85rem', fontSize: '0.88rem' }}
            >
              <option value="All">All Categories ({dishes.length})</option>
              {categories.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>

          <div style={{ position: 'relative', width: 'min(300px, 100%)' }}>
            <Search size={16} style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', color: 'var(--muted)' }} />
            <input
              type="text"
              placeholder="Search dishes..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              style={{ paddingLeft: '2.2rem', paddingBlock: '0.45rem', fontSize: '0.88rem' }}
            />
          </div>
        </div>

        {/* Menu Table */}
        <div className="card">
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Dish</th>
                  <th>Category</th>
                  <th>Price</th>
                  <th>Diet</th>
                  <th>Availability</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={6} style={{ textAlign: 'center', padding: '3rem', color: 'var(--muted)' }}>
                      Loading dishes from MongoDB...
                    </td>
                  </tr>
                ) : filteredDishes.length > 0 ? (
                  filteredDishes.map((dish) => {
                    const imgSrc = dish.image && dish.image.trim() !== ''
                      ? dish.image
                      : generateDishSvg(dish);

                    return (
                      <tr key={dish._id}>
                        <td>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
                            <img
                              src={imgSrc}
                              alt={dish.name}
                              style={{ width: '48px', height: '48px', borderRadius: '8px', objectFit: 'cover' }}
                              onError={(e) => handleImageError(e, dish)}
                            />
                            <div>
                              <b style={{ display: 'block', fontSize: '0.98rem' }}>{dish.name}</b>
                              <span style={{ fontSize: '0.8rem', color: 'var(--muted)' }}>
                                {dish.isPopular ? '★ Popular • ' : ''}{dish.spiceLevel} spice
                              </span>
                            </div>
                          </div>
                        </td>
                        <td>{dish.category}</td>
                        <td><b>₹{dish.price}</b></td>
                        <td>
                          <span className={`diet ${dish.isVeg ? 'veg' : 'nv'}`} style={{ fontSize: '0.82rem' }}>
                            {dish.isVeg ? 'Veg' : 'Non-veg'}
                          </span>
                        </td>
                        <td>
                          <button
                            type="button"
                            onClick={() => handleToggleAvailability(dish)}
                            className={`badge ${dish.isAvailable ? 'green' : 'red'}`}
                            style={{ cursor: 'pointer', border: 'none' }}
                            title="Click to toggle availability"
                          >
                            {dish.isAvailable ? '● Available' : '○ Sold Out'}
                          </button>
                        </td>
                        <td>
                          <div style={{ display: 'flex', gap: '0.5rem' }}>
                            <button
                              type="button"
                              className="btn sm alt"
                              onClick={() => openEditModal(dish)}
                              style={{ padding: '0.35rem 0.65rem' }}
                              title="Edit dish"
                            >
                              <Edit2 size={14} />
                            </button>
                            <button
                              type="button"
                              className="btn sm alt"
                              onClick={() => handleDeleteDish(dish)}
                              style={{ padding: '0.35rem 0.65rem', color: 'var(--chili)', borderColor: 'var(--line)' }}
                              title="Delete dish"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={6} style={{ textAlign: 'center', padding: '3rem', color: 'var(--muted)' }}>
                      No dishes found matching criteria.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Create / Edit Dish Modal */}
        {isModalOpen && (
          <div className="modal-overlay" onClick={() => setIsModalOpen(false)}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '600px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
                <h2 style={{ fontSize: '1.5rem', margin: 0 }}>
                  {editingDish ? `Edit "${editingDish.name}"` : 'Add New Dish to Menu'}
                </h2>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--muted)' }}
                >
                  <X size={20} />
                </button>
              </div>

              {formError && (
                <div className="alert error">
                  <AlertCircle size={16} />
                  <span>{formError}</span>
                </div>
              )}

              <form onSubmit={handleFormSubmit}>
                <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: '1rem' }}>
                  <div className="form-group">
                    <label>Dish Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Kolhapuri Mutton Curry"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    />
                  </div>

                  <div className="form-group">
                    <label>Category *</label>
                    <select
                      value={formData.category}
                      onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    >
                      {categories.map((c) => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1rem' }}>
                  <div className="form-group">
                    <label>Price (₹) *</label>
                    <input
                      type="number"
                      required
                      min={1}
                      placeholder="280"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                    />
                  </div>

                  <div className="form-group">
                    <label>Dietary</label>
                    <select
                      value={formData.isVeg ? 'true' : 'false'}
                      onChange={(e) => setFormData({ ...formData, isVeg: e.target.value === 'true' })}
                    >
                      <option value="true">Vegetarian</option>
                      <option value="false">Non-Vegetarian</option>
                    </select>
                  </div>

                  <div className="form-group">
                    <label>Spice Level</label>
                    <select
                      value={formData.spiceLevel}
                      onChange={(e) => setFormData({ ...formData, spiceLevel: e.target.value })}
                    >
                      <option>None</option>
                      <option>Mild</option>
                      <option>Medium</option>
                      <option>Spicy</option>
                      <option>Extra Spicy</option>
                    </select>
                  </div>
                </div>

                <div className="form-group">
                  <label>Description *</label>
                  <textarea
                    required
                    rows={3}
                    placeholder="Describe the flavors, spices, and sides..."
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  />
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: '1rem' }}>
                  <div className="form-group">
                    <label>Image URL or Path</label>
                    <input
                      type="text"
                      placeholder="e.g. /images/misal.jpg"
                      value={formData.image}
                      onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                    />
                  </div>

                  <div className="form-group">
                    <label>Preparation Time</label>
                    <input
                      type="text"
                      placeholder="e.g. 15-20 mins"
                      value={formData.prepTime}
                      onChange={(e) => setFormData({ ...formData, prepTime: e.target.value })}
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label>Tags (comma separated)</label>
                  <input
                    type="text"
                    placeholder="Bestseller, Tandoor, Spicy Lovers"
                    value={formData.tags}
                    onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                  />
                </div>

                <div style={{ display: 'flex', gap: '2rem', margin: '1rem 0 1.5rem' }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', cursor: 'pointer' }}>
                    <input
                      type="checkbox"
                      checked={formData.isAvailable}
                      onChange={(e) => setFormData({ ...formData, isAvailable: e.target.checked })}
                      style={{ width: '16px', height: '16px', accentColor: 'var(--green)' }}
                    />
                    <span>Available for Ordering</span>
                  </label>

                  <label style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', cursor: 'pointer' }}>
                    <input
                      type="checkbox"
                      checked={formData.isPopular}
                      onChange={(e) => setFormData({ ...formData, isPopular: e.target.checked })}
                      style={{ width: '16px', height: '16px', accentColor: 'var(--saffron)' }}
                    />
                    <span>Featured in "Most Ordered"</span>
                  </label>
                </div>

                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem' }}>
                  <button type="button" className="btn alt" onClick={() => setIsModalOpen(false)}>
                    Cancel
                  </button>
                  <button type="submit" disabled={submitting} className="btn saffron">
                    {submitting ? 'Saving...' : editingDish ? 'Update Dish' : 'Add Dish to Menu'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
