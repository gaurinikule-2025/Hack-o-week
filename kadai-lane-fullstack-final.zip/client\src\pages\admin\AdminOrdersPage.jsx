import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { apiClient } from '../../services/api';
import {
  Package,
  Search,
  Filter,
  CheckCircle,
  Clock,
  ArrowLeft,
  X,
  AlertCircle,
  Eye,
} from 'lucide-react';

export const AdminOrdersPage = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('All');
  const [search, setSearch] = useState('');
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [updatingId, setUpdatingId] = useState(null);

  const statuses = [
    'All',
    'Pending',
    'Confirmed',
    'Preparing',
    'Ready for Pickup',
    'Out for Delivery',
    'Delivered',
    'Cancelled',
  ];

  const allowedTransitions = {
    Pending: ['Confirmed', 'Cancelled'],
    Confirmed: ['Preparing', 'Cancelled'],
    Preparing: ['Ready for Pickup', 'Out for Delivery'],
    'Ready for Pickup': ['Delivered'],
    'Out for Delivery': ['Delivered'],
    Delivered: [],
    Cancelled: [],
  };

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const data = await apiClient('/orders/admin/all');
      if (data.success && data.orders) {
        setOrders(data.orders);
      }
    } catch (err) {
      console.error('Failed to load admin orders:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const handleUpdateStatus = async (orderId, newStatus) => {
    setUpdatingId(orderId);
    try {
      const res = await apiClient(`/orders/admin/${orderId}/status`, {
        method: 'PATCH',
        body: { status: newStatus },
      });

      if (res.success && res.order) {
        setOrders((prev) =>
          prev.map((o) => (o._id === orderId ? res.order : o))
        );
        if (selectedOrder && selectedOrder._id === orderId) {
          setSelectedOrder(res.order);
        }
      }
    } catch (err) {
      alert(err.message || 'Failed to update order status.');
    } finally {
      setUpdatingId(null);
    }
  };

  const handleUpdatePayment = async (orderId, paymentStatus) => {
    setUpdatingId(orderId);
    try {
      const res = await apiClient(`/orders/admin/${orderId}/status`, {
        method: 'PATCH',
        body: { paymentStatus },
      });

      if (res.success && res.order) {
        setOrders((prev) =>
          prev.map((o) => (o._id === orderId ? res.order : o))
        );
        if (selectedOrder && selectedOrder._id === orderId) {
          setSelectedOrder(res.order);
        }
      }
    } catch (err) {
      alert(err.message || 'Failed to update payment status.');
    } finally {
      setUpdatingId(null);
    }
  };

  const filteredOrders = orders.filter((order) => {
    const matchStatus = statusFilter === 'All' || order.orderStatus === statusFilter;
    const matchSearch =
      search.trim() === '' ||
      order.orderNumber.toLowerCase().includes(search.toLowerCase()) ||
      order.customerName.toLowerCase().includes(search.toLowerCase()) ||
      order.customerPhone.includes(search);

    return matchStatus && matchSearch;
  });

  return (
    <div className="main-content">
      <div className="wrap">
        <Link to="/admin" className="btn sm alt" style={{ marginBottom: '1.5rem', display: 'inline-flex', alignItems: 'center', gap: '0.4rem' }}>
          <ArrowLeft size={16} /> Back to Dashboard
        </Link>

        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
          <div>
            <h1 style={{ fontSize: 'clamp(2rem, 4vw, 2.6rem)', fontWeight: 800 }}>Restaurant Orders Management</h1>
            <p style={{ color: 'var(--muted)', margin: 0 }}>Review customer orders, advance kitchen states, and verify payments.</p>
          </div>

          <button type="button" className="btn sm alt" onClick={fetchOrders}>
            Refresh Orders
          </button>
        </div>

        {/* Filters */}
        <div className="card" style={{ padding: '1rem', marginBottom: '1.5rem', display: 'flex', flexWrap: 'wrap', gap: '1rem', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', gap: '0.4rem', flexWrap: 'wrap', overflowX: 'auto' }}>
            {statuses.map((st) => (
              <button
                key={st}
                type="button"
                className={`chip ${statusFilter === st ? 'active' : ''}`}
                aria-pressed={statusFilter === st}
                onClick={() => setStatusFilter(st)}
                style={{ fontSize: '0.82rem', padding: '0.35rem 0.85rem' }}
              >
                {st} ({st === 'All' ? orders.length : orders.filter((o) => o.orderStatus === st).length})
              </button>
            ))}
          </div>

          <div style={{ position: 'relative', width: 'min(280px, 100%)' }}>
            <Search size={16} style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', color: 'var(--muted)' }} />
            <input
              type="text"
              placeholder="Search reference, customer..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              style={{ paddingLeft: '2.2rem', paddingBlock: '0.45rem', fontSize: '0.88rem' }}
            />
          </div>
        </div>

        {/* Orders Table */}
        <div className="card">
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Order Reference</th>
                  <th>Customer Info</th>
                  <th>Type</th>
                  <th>Amount</th>
                  <th>Current Status</th>
                  <th>Change Status</th>
                  <th>Payment</th>
                  <th>Details</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={8} style={{ textAlign: 'center', padding: '3rem', color: 'var(--muted)' }}>
                      Loading orders from database...
                    </td>
                  </tr>
                ) : filteredOrders.length > 0 ? (
                  filteredOrders.map((order) => {
                    const nextOptions = allowedTransitions[order.orderStatus] || [];

                    return (
                      <tr key={order._id}>
                        <td>
                          <b style={{ color: 'var(--green)' }}>#{order.orderNumber}</b>
                          <div style={{ fontSize: '0.78rem', color: 'var(--muted)' }}>
                            {new Date(order.createdAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}
                          </div>
                        </td>
                        <td>
                          <div><b>{order.customerName}</b></div>
                          <div style={{ fontSize: '0.8rem', color: 'var(--muted)' }}>{order.customerPhone}</div>
                        </td>
                        <td>
                          <span className="badge gray" style={{ fontSize: '0.75rem' }}>{order.orderType}</span>
                        </td>
                        <td>
                          <b>₹{order.total}</b>
                          <div style={{ fontSize: '0.78rem', color: 'var(--muted)' }}>{order.items.length} items</div>
                        </td>
                        <td>
                          <span className={`badge ${order.orderStatus === 'Delivered' ? 'green' : order.orderStatus === 'Cancelled' ? 'red' : 'saffron'}`}>
                            {order.orderStatus}
                          </span>
                        </td>
                        <td>
                          {nextOptions.length > 0 ? (
                            <select
                              disabled={updatingId === order._id}
                              value=""
                              onChange={(e) => {
                                if (e.target.value) handleUpdateStatus(order._id, e.target.value);
                              }}
                              style={{ width: 'auto', padding: '0.35rem 0.65rem', fontSize: '0.82rem' }}
                            >
                              <option value="">Move status to...</option>
                              {nextOptions.map((opt) => (
                                <option key={opt} value={opt}>→ {opt}</option>
                              ))}
                            </select>
                          ) : (
                            <span style={{ fontSize: '0.8rem', color: 'var(--muted)' }}>Completed</span>
                          )}
                        </td>
                        <td>
                          <button
                            type="button"
                            className={`badge ${order.paymentStatus === 'Paid' ? 'green' : 'saffron'}`}
                            style={{ cursor: 'pointer', border: 'none', fontSize: '0.75rem' }}
                            onClick={() =>
                              handleUpdatePayment(
                                order._id,
                                order.paymentStatus === 'Paid' ? 'Pending' : 'Paid'
                              )
                            }
                            title="Click to toggle Paid/Pending"
                          >
                            {order.paymentStatus}
                          </button>
                        </td>
                        <td>
                          <button
                            type="button"
                            className="btn sm alt"
                            onClick={() => setSelectedOrder(order)}
                            style={{ padding: '0.3rem 0.6rem' }}
                            title="Inspect details"
                          >
                            <Eye size={15} />
                          </button>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={8} style={{ textAlign: 'center', padding: '3rem', color: 'var(--muted)' }}>
                      No orders match this filter.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Order Details Modal */}
        {selectedOrder && (
          <div className="modal-overlay" onClick={() => setSelectedOrder(null)}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '600px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
                <h2 style={{ fontSize: '1.4rem', margin: 0 }}>Order #{selectedOrder.orderNumber}</h2>
                <button
                  type="button"
                  onClick={() => setSelectedOrder(null)}
                  style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--muted)' }}
                >
                  <X size={20} />
                </button>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', background: 'var(--soft)', padding: '1rem', borderRadius: '10px', marginBottom: '1.5rem', fontSize: '0.9rem' }}>
                <div>
                  <span style={{ color: 'var(--muted)', display: 'block', fontSize: '0.78rem' }}>Customer</span>
                  <b>{selectedOrder.customerName}</b> ({selectedOrder.customerPhone})
                </div>
                <div>
                  <span style={{ color: 'var(--muted)', display: 'block', fontSize: '0.78rem' }}>Fulfillment & Payment</span>
                  <b>{selectedOrder.orderType}</b> • {selectedOrder.paymentMethod}
                </div>
                {selectedOrder.orderType === 'Delivery' && selectedOrder.deliveryAddress && (
                  <div style={{ gridColumn: 'span 2' }}>
                    <span style={{ color: 'var(--muted)', display: 'block', fontSize: '0.78rem' }}>Destination</span>
                    <span>{selectedOrder.deliveryAddress.street}, {selectedOrder.deliveryAddress.area}, Pune - {selectedOrder.deliveryAddress.pincode}</span>
                  </div>
                )}
                {selectedOrder.specialInstructions && (
                  <div style={{ gridColumn: 'span 2' }}>
                    <span style={{ color: 'var(--muted)', display: 'block', fontSize: '0.78rem' }}>Instructions</span>
                    <span style={{ fontStyle: 'italic' }}>"{selectedOrder.specialInstructions}"</span>
                  </div>
                )}
              </div>

              <h4 style={{ fontSize: '1.1rem', marginBottom: '0.75rem' }}>Items Snapshot</h4>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem', marginBottom: '1.5rem' }}>
                {selectedOrder.items.map((it, idx) => (
                  <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid var(--line)', paddingBottom: '0.4rem', fontSize: '0.92rem' }}>
                    <span><b>{it.quantity}×</b> {it.name}</span>
                    <b>₹{it.price * it.quantity}</b>
                  </div>
                ))}
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '2px solid var(--line)', paddingTop: '0.75rem', marginBottom: '1.5rem' }}>
                <b style={{ fontSize: '1.1rem' }}>Final Amount</b>
                <span className="price" style={{ fontSize: '1.4rem', color: 'var(--green)' }}>₹{selectedOrder.total}</span>
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem' }}>
                <Link to={`/orders/${selectedOrder.orderNumber}`} className="btn sm">
                  Open Customer Tracking View
                </Link>
                <button type="button" className="btn sm alt" onClick={() => setSelectedOrder(null)}>
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
