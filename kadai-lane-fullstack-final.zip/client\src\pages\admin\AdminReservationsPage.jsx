import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { apiClient } from '../../services/api';
import {
  Calendar,
  Users,
  Clock,
  Search,
  CheckCircle,
  XCircle,
  ArrowLeft,
} from 'lucide-react';

export const AdminReservationsPage = () => {
  const [reservations, setReservations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('All');
  const [dateFilter, setDateFilter] = useState('');
  const [search, setSearch] = useState('');
  const [updatingId, setUpdatingId] = useState(null);

  const statuses = ['All', 'Confirmed', 'Pending', 'Completed', 'Cancelled'];

  const fetchReservations = async () => {
    setLoading(true);
    try {
      let query = '/reservations/admin/all';
      const params = new URLSearchParams();
      if (dateFilter) params.append('date', dateFilter);
      if (statusFilter !== 'All') params.append('status', statusFilter);
      if (search.trim()) params.append('search', search.trim());

      if (params.toString()) {
        query += `?${params.toString()}`;
      }

      const data = await apiClient(query);
      if (data.success && data.reservations) {
        setReservations(data.reservations);
      }
    } catch (err) {
      console.error('Failed to load reservations:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReservations();
  }, [dateFilter, statusFilter]);

  const handleUpdateStatus = async (id, status) => {
    setUpdatingId(id);
    try {
      const res = await apiClient(`/reservations/admin/${id}/status`, {
        method: 'PATCH',
        body: { status },
      });

      if (res.success && res.reservation) {
        setReservations((prev) =>
          prev.map((r) => (r._id === id ? res.reservation : r))
        );
      }
    } catch (err) {
      alert(err.message || 'Failed to update reservation status.');
    } finally {
      setUpdatingId(null);
    }
  };

  return (
    <div className="main-content">
      <div className="wrap">
        <Link to="/admin" className="btn sm alt" style={{ marginBottom: '1.5rem', display: 'inline-flex', alignItems: 'center', gap: '0.4rem' }}>
          <ArrowLeft size={16} /> Back to Dashboard
        </Link>

        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
          <div>
            <h1 style={{ fontSize: 'clamp(2rem, 4vw, 2.6rem)', fontWeight: 800 }}>Table Reservations Management</h1>
            <p style={{ color: 'var(--muted)', margin: 0 }}>Review table booking schedules, capacity, and seat allotments.</p>
          </div>

          <button type="button" className="btn sm alt" onClick={fetchReservations}>
            Refresh Schedule
          </button>
        </div>

        {/* Filter Controls */}
        <div className="card" style={{ padding: '1rem', marginBottom: '1.5rem', display: 'flex', flexWrap: 'wrap', gap: '1rem', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', alignItems: 'center' }}>
            {statuses.map((st) => (
              <button
                key={st}
                type="button"
                className={`chip ${statusFilter === st ? 'active' : ''}`}
                aria-pressed={statusFilter === st}
                onClick={() => setStatusFilter(st)}
                style={{ fontSize: '0.82rem', padding: '0.35rem 0.85rem' }}
              >
                {st}
              </button>
            ))}
          </div>

          <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center', flexWrap: 'wrap' }}>
            <input
              type="date"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              style={{ width: 'auto', padding: '0.45rem 0.75rem', fontSize: '0.88rem' }}
              title="Filter by reservation date"
            />
            {dateFilter && (
              <button type="button" className="btn sm alt" onClick={() => setDateFilter('')} style={{ padding: '0.35rem 0.65rem' }}>
                Clear Date
              </button>
            )}
          </div>
        </div>

        {/* Reservations Table */}
        <div className="card">
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Booking Reference</th>
                  <th>Guest Details</th>
                  <th>Date & Time</th>
                  <th>Party & Seating</th>
                  <th>Notes</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={7} style={{ textAlign: 'center', padding: '3rem', color: 'var(--muted)' }}>
                      Loading reservations...
                    </td>
                  </tr>
                ) : reservations.length > 0 ? (
                  reservations.map((res) => (
                    <tr key={res._id}>
                      <td>
                        <b style={{ color: 'var(--green)' }}>#{res.reservationNumber}</b>
                      </td>
                      <td>
                        <div><b>{res.name}</b></div>
                        <div style={{ fontSize: '0.8rem', color: 'var(--muted)' }}>{res.phone}</div>
                      </td>
                      <td>
                        <div><b>{res.date}</b></div>
                        <div style={{ fontSize: '0.82rem', color: 'var(--green)', fontWeight: 700 }}>{res.time}</div>
                      </td>
                      <td>
                        <b>{res.guests} Guests</b>
                        <div style={{ fontSize: '0.78rem', color: 'var(--muted)' }}>{res.seatingArea} Area</div>
                      </td>
                      <td style={{ maxWidth: '200px', fontSize: '0.82rem' }}>
                        {res.specialRequests || <span style={{ color: 'var(--muted)' }}>None</span>}
                      </td>
                      <td>
                        <span className={`badge ${res.status === 'Confirmed' ? 'green' : res.status === 'Cancelled' ? 'red' : res.status === 'Completed' ? 'blue' : 'saffron'}`}>
                          {res.status}
                        </span>
                      </td>
                      <td>
                        <div style={{ display: 'flex', gap: '0.4rem', flexWrap: 'wrap' }}>
                          {res.status !== 'Confirmed' && res.status !== 'Completed' && (
                            <button
                              type="button"
                              disabled={updatingId === res._id}
                              onClick={() => handleUpdateStatus(res._id, 'Confirmed')}
                              className="btn sm"
                              style={{ padding: '0.25rem 0.6rem', fontSize: '0.75rem' }}
                            >
                              Confirm
                            </button>
                          )}
                          {res.status === 'Confirmed' && (
                            <button
                              type="button"
                              disabled={updatingId === res._id}
                              onClick={() => handleUpdateStatus(res._id, 'Completed')}
                              className="btn sm alt"
                              style={{ padding: '0.25rem 0.6rem', fontSize: '0.75rem' }}
                            >
                              Mark Done
                            </button>
                          )}
                          {res.status !== 'Cancelled' && (
                            <button
                              type="button"
                              disabled={updatingId === res._id}
                              onClick={() => handleUpdateStatus(res._id, 'Cancelled')}
                              className="btn sm alt"
                              style={{ padding: '0.25rem 0.6rem', fontSize: '0.75rem', color: 'var(--chili)', borderColor: 'var(--line)' }}
                            >
                              Cancel
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={7} style={{ textAlign: 'center', padding: '3rem', color: 'var(--muted)' }}>
                      No reservations found for this filter.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
