// Helper to generate dynamic SVG data URI when photo is unavailable or fails to load

export const generateDishSvg = (dish = {}) => {
  const gradient = dish.gradient && dish.gradient.length === 2
    ? dish.gradient
    : ['#f28c28', '#b3202f'];
  const emoji = dish.emoji || '🍲';

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300">
    <defs>
      <linearGradient id="g_${dish.dishKey || 'dish'}" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stop-color="${gradient[0]}"/>
        <stop offset="1" stop-color="${gradient[1]}"/>
      </linearGradient>
    </defs>
    <rect width="400" height="300" fill="url(#g_${dish.dishKey || 'dish'})"/>
    <circle cx="200" cy="150" r="105" fill="#fff" fill-opacity="0.18"/>
    <text x="200" y="195" font-size="130" text-anchor="middle">${emoji}</text>
  </svg>`;

  return `data:image/svg+xml,${encodeURIComponent(svg)}`;
};

export const handleImageError = (e, dish) => {
  const img = e.target;
  if (!img.dataset.failed) {
    img.dataset.failed = 'true';
    img.src = generateDishSvg(dish);
  }
};
