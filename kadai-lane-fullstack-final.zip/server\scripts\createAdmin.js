import mongoose from 'mongoose';
import dotenv from 'dotenv';
import { User } from '../src/models/User.js';

dotenv.config();

const createAdminUser = async () => {
  const uri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/kadai_lane';

  const adminName = process.env.ADMIN_NAME || 'Kadai Lane Admin';
  const adminEmail = (process.env.ADMIN_EMAIL || 'admin@kadailane.in').toLowerCase().trim();
  const adminPassword = process.env.ADMIN_PASSWORD || 'Admin@12345';
  const adminPhone = process.env.ADMIN_PHONE || '9823000000';

  try {
    console.log(`Connecting to database at ${uri}...`);
    await mongoose.connect(uri);
    console.log('Connected to MongoDB.');

    let existingAdmin = await User.findOne({ email: adminEmail });

    if (existingAdmin) {
      existingAdmin.name = adminName;
      existingAdmin.role = 'admin';
      existingAdmin.password = adminPassword; // Will be hashed by pre('save') hook
      existingAdmin.phone = adminPhone;
      await existingAdmin.save();
      console.log(`\n======================================================`);
      console.log(`✅ Existing administrator account updated successfully!`);
    } else {
      existingAdmin = await User.create({
        name: adminName,
        email: adminEmail,
        password: adminPassword,
        phone: adminPhone,
        role: 'admin',
        address: {
          street: '14 Lane 5',
          area: 'Koregaon Park',
          city: 'Pune',
          pincode: '411001',
        },
      });
      console.log(`\n======================================================`);
      console.log(`✅ New administrator account created successfully!`);
    }

    console.log(`📧 Email:    ${existingAdmin.email}`);
    console.log(`🔑 Password: ${adminPassword}`);
    console.log(`👑 Role:     ${existingAdmin.role}`);
    console.log(`📱 Phone:    ${existingAdmin.phone}`);
    console.log(`======================================================\n`);

    await mongoose.connection.close();
    process.exit(0);
  } catch (error) {
    console.error('Failed to create admin:', error.message);
    if (mongoose.connection) {
      await mongoose.connection.close();
    }
    process.exit(1);
  }
};

createAdminUser();
