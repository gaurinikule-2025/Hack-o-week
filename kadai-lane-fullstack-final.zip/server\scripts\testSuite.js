// Automated Test Suite for Kadai Lane MERN Stack Project

import assert from 'assert';
import bcrypt from 'bcryptjs';
import { generateOrderNumber, generateReservationNumber } from '../src/utils/referenceGenerator.js';
import {
  RESTAURANT_CONFIG,
  ORDER_STATUSES,
  VALID_STATUS_TRANSITIONS,
} from '../src/config/constants.js';

console.log('🧪 Starting Kadai Lane Automated Test Suite...\n');

let passedTests = 0;
let totalTests = 0;

const test = (title, fn) => {
  totalTests++;
  try {
    fn();
    console.log(`  ✅ PASS: ${title}`);
    passedTests++;
  } catch (err) {
    console.error(`  ❌ FAIL: ${title}`);
    console.error(`     ${err.message}`);
  }
};

const asyncTest = async (title, fn) => {
  totalTests++;
  try {
    await fn();
    console.log(`  ✅ PASS: ${title}`);
    passedTests++;
  } catch (err) {
    console.error(`  ❌ FAIL: ${title}`);
    console.error(`     ${err.message}`);
  }
};

// 1. Reference Generator Tests
test('Reference generator should produce valid unique Order Numbers', () => {
  const ord1 = generateOrderNumber();
  const ord2 = generateOrderNumber();
  assert(ord1.startsWith('KL-ORD-'), 'Order reference must start with KL-ORD-');
  assert(ord1 !== ord2, 'Consecutive order numbers must be unique');
  assert.strictEqual(ord1.split('-').length, 4, 'Order number format must be KL-ORD-YYYYMMDD-HEX');
});

test('Reference generator should produce valid unique Reservation Numbers', () => {
  const res1 = generateReservationNumber();
  const res2 = generateReservationNumber();
  assert(res1.startsWith('KL-RES-'), 'Reservation reference must start with KL-RES-');
  assert(res1 !== res2, 'Consecutive reservation numbers must be unique');
});

// 2. Financial & Business Rules Tests
test('GST tax calculation should accurately apply 5% rate', () => {
  const subtotal = 560; // e.g. 2 x Veg Dum Biryani
  const tax = Math.round(subtotal * RESTAURANT_CONFIG.financials.gstRate);
  assert.strictEqual(tax, 28, '5% GST on ₹560 must equal ₹28');
});

test('Delivery fee threshold rule: free for orders >= ₹500', () => {
  const eligibleSubtotal = 520;
  const deliveryFee = eligibleSubtotal >= RESTAURANT_CONFIG.financials.freeDeliveryThreshold
    ? 0
    : RESTAURANT_CONFIG.financials.deliveryFee;
  assert.strictEqual(deliveryFee, 0, 'Orders of ₹500 or more should have ₹0 delivery fee');
});

test('Delivery fee rule: ₹40 for orders under ₹500', () => {
  const smallSubtotal = 380;
  const deliveryFee = smallSubtotal >= RESTAURANT_CONFIG.financials.freeDeliveryThreshold
    ? 0
    : RESTAURANT_CONFIG.financials.deliveryFee;
  assert.strictEqual(deliveryFee, 40, 'Orders under ₹500 must incur ₹40 standard delivery fee');
});

test('Table reservation capacity limits: max 8 guests per online booking', () => {
  assert.strictEqual(RESTAURANT_CONFIG.reservationRules.maxGuestsPerBooking, 8);
  assert.strictEqual(RESTAURANT_CONFIG.reservationRules.minGuestsPerBooking, 1);
  assert(RESTAURANT_CONFIG.reservationRules.timeSlots.length >= 8);
});

// 3. Status Transition Rules Tests
test('Permitted order transitions: Pending can advance to Confirmed or Cancelled', () => {
  const allowed = VALID_STATUS_TRANSITIONS['Pending'];
  assert(allowed.includes('Confirmed'));
  assert(allowed.includes('Cancelled'));
  assert(!allowed.includes('Delivered'), 'Pending cannot jump directly to Delivered');
});

test('Permitted order transitions: Confirmed can advance to Preparing', () => {
  const allowed = VALID_STATUS_TRANSITIONS['Confirmed'];
  assert(allowed.includes('Preparing'));
});

test('Permitted order transitions: Preparing can advance to Out for Delivery or Ready for Pickup', () => {
  const allowed = VALID_STATUS_TRANSITIONS['Preparing'];
  assert(allowed.includes('Out for Delivery'));
  assert(allowed.includes('Ready for Pickup'));
});

test('Terminal status: Delivered and Cancelled cannot transition to any other status', () => {
  assert.strictEqual(VALID_STATUS_TRANSITIONS['Delivered'].length, 0);
  assert.strictEqual(VALID_STATUS_TRANSITIONS['Cancelled'].length, 0);
});

// 4. Security & Cryptography Tests
await asyncTest('Password hashing and comparison with bcrypt', async () => {
  const plainPassword = 'StudentSecret@2026';
  const salt = await bcrypt.genSalt(10);
  const hash = await bcrypt.hash(plainPassword, salt);

  assert(hash !== plainPassword, 'Hashed password must not match plaintext');
  const isMatch = await bcrypt.compare(plainPassword, hash);
  assert.strictEqual(isMatch, true, 'bcrypt.compare must verify matching password');

  const isWrong = await bcrypt.compare('WrongPassword', hash);
  assert.strictEqual(isWrong, false, 'bcrypt.compare must reject invalid password');
});

console.log(`\n======================================================`);
console.log(`Test Results: ${passedTests} / ${totalTests} Passed (${Math.round((passedTests / totalTests) * 100)}%)`);
console.log(`======================================================\n`);

if (passedTests === totalTests) {
  process.exit(0);
} else {
  process.exit(1);
}
