// Kadai Lane - System Constants & Business Rules

export const RESTAURANT_CONFIG = {
  name: 'Kadai Lane — Modern Indian Kitchen in Pune',
  shortName: 'Kadai Lane',
  tagline: 'Slow-cooked classics, fast Pune evenings.',
  description: 'Misal, biryani, tandoor and sweets from a kitchen that grinds its own masalas every morning.',
  address: {
    line1: '14 Lane 5',
    area: 'Koregaon Park',
    city: 'Pune',
    state: 'Maharashtra',
    pincode: '411001',
    landmark: 'Near North Main Road'
  },
  contact: {
    phone: '+91 98230 45678',
    email: 'hello@kadailane.in',
    supportPhone: '+91 20 2615 8900'
  },
  operatingHours: {
    weekday: '12:00 – 22:30 (Mon–Thu)',
    weekend: '12:00 – 23:30 (Fri–Sat)',
    sunday: '11:00 – 22:30 (Sunday)',
    kitchenCloses: '30 mins before closing'
  },
  financials: {
    gstRate: 0.05, // 5% GST on restaurant food
    deliveryFee: 40, // ₹40 delivery fee
    freeDeliveryThreshold: 500, // Free delivery on orders above ₹500
    currency: '₹',
    currencyCode: 'INR'
  },
  reservationRules: {
    maxGuestsPerBooking: 8,
    minGuestsPerBooking: 1,
    slotCapacityGuests: 30, // maximum guests per time slot
    timeSlots: [
      '12:30', '13:30', '14:30',
      '19:00', '19:30', '20:00', '20:30', '21:00', '21:30', '22:00'
    ],
    seatingAreas: ['Indoor', 'Terrace'],
    autoConfirm: true // table reservations confirmed automatically if within capacity
  }
};

export const ORDER_STATUSES = {
  PENDING: 'Pending',
  CONFIRMED: 'Confirmed',
  PREPARING: 'Preparing',
  READY_FOR_PICKUP: 'Ready for Pickup',
  OUT_FOR_DELIVERY: 'Out for Delivery',
  DELIVERED: 'Delivered',
  CANCELLED: 'Cancelled'
};

export const VALID_STATUS_TRANSITIONS = {
  'Pending': ['Confirmed', 'Cancelled'],
  'Confirmed': ['Preparing', 'Cancelled'],
  'Preparing': ['Ready for Pickup', 'Out for Delivery'],
  'Ready for Pickup': ['Delivered'],
  'Out for Delivery': ['Delivered'],
  'Delivered': [],
  'Cancelled': []
};

export const PAYMENT_METHODS = {
  COD: 'Cash on Delivery',
  RESTAURANT: 'Pay at Restaurant / Pickup'
};

export const PAYMENT_STATUSES = {
  PENDING: 'Pending',
  PAID: 'Paid',
  REFUNDED: 'Refunded'
};
