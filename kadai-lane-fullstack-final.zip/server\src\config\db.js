import mongoose from 'mongoose';

export const connectDB = async () => {
  const uri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/kadai_lane';

  try {
    const conn = await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 5000,
    });
    console.log(`[MongoDB] Connected to database: ${conn.connection.name} at ${conn.connection.host}:${conn.connection.port}`);
    return conn;
  } catch (error) {
    console.error(`[MongoDB Connection Error] Failed to connect to ${uri}`);
    console.error(`Reason: ${error.message}`);
    console.error(`\n>>> TROUBLESHOOTING TIP <<<`);
    console.error(`1. If using local MongoDB, ensure MongoDB service or "mongod" is running.`);
    console.error(`   In Windows PowerShell: Start-Service MongoDB (or run 'mongod --dbpath <data_folder>')`);
    console.error(`2. If using MongoDB Atlas, check your connection string in server/.env:`);
    console.error(`   MONGODB_URI=mongodb+srv://<username>:<password>@cluster0.mongodb.net/kadai_lane?retryWrites=true&w=majority`);
    console.error(`3. Inspect your database visually using MongoDB Compass with the same URI.\n`);
    // Do not crash the entire node process immediately in development so health check and other endpoints can still inform the client
    return null;
  }
};
