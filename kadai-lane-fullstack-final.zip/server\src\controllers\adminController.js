import { MenuItem } from '../models/MenuItem.js';
import { Order } from '../models/Order.js';
import { Reservation } from '../models/Reservation.js';
import { User } from '../models/User.js';

// Helper for today's date YYYY-MM-DD
const getTodayDateString = () => {
  const d = new Date();
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 10);
};

// @desc    Get Admin Dashboard Stats & Metrics
// @route   GET /api/admin/stats
// @access  Private/Admin
export const getAdminStats = async (req, res, next) => {
  try {
    const today = getTodayDateString();

    // 1. Menu statistics
    const totalMenuItems = await MenuItem.countDocuments();
    const availableMenuItems = await MenuItem.countDocuments({ isAvailable: true });

    // 2. Order statistics
    const totalOrders = await Order.countDocuments();
    const pendingOrders = await Order.countDocuments({
      orderStatus: { $in: ['Pending', 'Confirmed', 'Preparing', 'Out for Delivery'] },
    });
    const deliveredOrders = await Order.countDocuments({ orderStatus: 'Delivered' });

    // Calculate total revenue from delivered/completed orders
    const revenueAgg = await Order.aggregate([
      { $match: { orderStatus: { $ne: 'Cancelled' } } },
      { $group: { _id: null, totalRevenue: { $sum: '$total' } } },
    ]);
    const totalRevenue = revenueAgg.length > 0 ? revenueAgg[0].totalRevenue : 0;

    // 3. Reservation statistics
    const totalReservations = await Reservation.countDocuments();
    const todayReservations = await Reservation.countDocuments({ date: today });
    const pendingReservations = await Reservation.countDocuments({
      date: { $gte: today },
      status: 'Confirmed',
    });

    // 4. Customer count
    const totalCustomers = await User.countDocuments({ role: 'customer' });

    // 5. Recent 5 orders and 5 reservations
    const recentOrders = await Order.find()
      .populate('customer', 'name email phone')
      .sort({ createdAt: -1 })
      .limit(5);

    const upcomingReservations = await Reservation.find({ date: { $gte: today } })
      .sort({ date: 1, time: 1 })
      .limit(5);

    res.status(200).json({
      success: true,
      stats: {
        menu: {
          total: totalMenuItems,
          available: availableMenuItems,
          soldOut: totalMenuItems - availableMenuItems,
        },
        orders: {
          total: totalOrders,
          active: pendingOrders,
          delivered: deliveredOrders,
          revenue: totalRevenue,
        },
        reservations: {
          total: totalReservations,
          today: todayReservations,
          upcoming: pendingReservations,
        },
        customers: {
          total: totalCustomers,
        },
      },
      recentOrders,
      upcomingReservations,
    });
  } catch (error) {
    next(error);
  }
};
