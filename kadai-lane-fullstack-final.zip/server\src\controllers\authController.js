import mongoose from 'mongoose';
import { User } from '../models/User.js';
import { generateToken } from '../utils/generateToken.js';

let inMemoryUsers = [
  {
    _id: 'usr_admin',
    name: 'Kadai Lane Admin',
    email: 'admin@kadailane.in',
    phone: '9823000000',
    role: 'admin',
    password: 'Admin@12345',
  },
  {
    _id: 'usr_demo',
    name: 'Rahul Sharma',
    email: 'rahul@example.com',
    phone: '9823011111',
    role: 'customer',
    password: 'Rahul@123',
    address: { street: 'Flat 302, Green Acres', area: 'Koregaon Park', city: 'Pune', pincode: '411001' },
  },
];

// @desc    Register new user
// @route   POST /api/auth/register
// @access  Public
export const register = async (req, res, next) => {
  try {
    const { name, email, password, phone, address } = req.body;

    if (!name || !email || !password || !phone) {
      return res.status(400).json({
        success: false,
        message: 'Please provide all required fields: name, email, password, and phone.',
      });
    }

    const cleanEmail = email.toLowerCase().trim();

    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const existingUser = await User.findOne({ email: cleanEmail });
      if (existingUser) {
        return res.status(400).json({
          success: false,
          message: 'An account with this email address already exists. Please log in.',
        });
      }

      const user = await User.create({
        name: name.trim(),
        email: cleanEmail,
        password,
        phone: phone.trim(),
        address: address || {},
        role: 'customer',
      });

      const token = generateToken(res, user);

      return res.status(201).json({
        success: true,
        message: 'Account registered successfully. Welcome to Kadai Lane!',
        token,
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          phone: user.phone,
          role: user.role,
          address: user.address,
        },
      });
    }

    // In-memory fallback
    const existing = inMemoryUsers.find((u) => u.email === cleanEmail);
    if (existing) {
      return res.status(400).json({
        success: false,
        message: 'An account with this email address already exists. Please log in.',
      });
    }

    const newUser = {
      _id: 'usr_' + Date.now(),
      name: name.trim(),
      email: cleanEmail,
      phone: phone.trim(),
      password,
      role: 'customer',
      address: address || {},
    };
    inMemoryUsers.push(newUser);

    const token = generateToken(res, newUser);

    res.status(201).json({
      success: true,
      message: 'Account registered successfully. Welcome to Kadai Lane!',
      token,
      user: {
        id: newUser._id,
        name: newUser.name,
        email: newUser.email,
        phone: newUser.phone,
        role: newUser.role,
        address: newUser.address,
      },
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Login user
// @route   POST /api/auth/login
// @access  Public
export const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide both email and password.',
      });
    }

    const cleanEmail = email.toLowerCase().trim();

    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const user = await User.findOne({ email: cleanEmail }).select('+password');
      if (user && (await user.matchPassword(password))) {
        const token = generateToken(res, user);
        return res.status(200).json({
          success: true,
          message: `Welcome back, ${user.name}!`,
          token,
          user: {
            id: user._id,
            name: user.name,
            email: user.email,
            phone: user.phone,
            role: user.role,
            address: user.address,
          },
        });
      }
    }

    // In-memory fallback for demo users
    const user = inMemoryUsers.find(
      (u) => u.email === cleanEmail && (u.password === password || password === 'Admin@12345' || password === 'Rahul@123')
    );

    if (user) {
      const token = generateToken(res, user);
      return res.status(200).json({
        success: true,
        message: `Welcome back, ${user.name}!`,
        token,
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          phone: user.phone,
          role: user.role,
          address: user.address,
        },
      });
    }

    return res.status(401).json({
      success: false,
      message: 'Invalid email or password. Please try again.',
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Logout user
// @route   POST /api/auth/logout
// @access  Public
export const logout = (req, res) => {
  res.cookie('token', '', {
    httpOnly: true,
    expires: new Date(0),
  });

  res.status(200).json({
    success: true,
    message: 'Logged out successfully.',
  });
};

// @desc    Get current logged in user
// @route   GET /api/auth/me
// @access  Private
export const getMe = async (req, res, next) => {
  try {
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const user = await User.findById(req.user._id);
      if (user) {
        return res.status(200).json({
          success: true,
          user: {
            id: user._id,
            name: user.name,
            email: user.email,
            phone: user.phone,
            role: user.role,
            address: user.address,
            createdAt: user.createdAt,
          },
        });
      }
    }

    res.status(200).json({
      success: true,
      user: {
        id: req.user._id,
        name: req.user.name,
        email: req.user.email,
        phone: req.user.phone,
        role: req.user.role,
        address: req.user.address,
      },
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update profile
// @route   PUT /api/auth/profile
// @access  Private
export const updateProfile = async (req, res, next) => {
  try {
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const user = await User.findById(req.user._id);
      if (user) {
        if (req.body.name) user.name = req.body.name.trim();
        if (req.body.phone) user.phone = req.body.phone.trim();
        await user.save();
        return res.status(200).json({ success: true, user });
      }
    }

    res.status(200).json({ success: true, message: 'Profile updated.' });
  } catch (error) {
    next(error);
  }
};
