import { Contact } from '../models/Contact.js';

// @desc    Submit contact / inquiry message
// @route   POST /api/contact
// @access  Public
export const submitContact = async (req, res, next) => {
  try {
    const { name, email, phone, subject, message } = req.body;

    if (!name || !email || !subject || !message) {
      return res.status(400).json({
        success: false,
        message: 'Please provide all required fields: name, email, subject, and message.',
      });
    }

    const inquiry = await Contact.create({
      name: name.trim(),
      email: email.trim().toLowerCase(),
      phone: (phone || '').trim(),
      subject: subject.trim(),
      message: message.trim(),
    });

    res.status(201).json({
      success: true,
      message: 'Thank you for reaching out! Our team at Kadai Lane will get back to you shortly.',
      inquiry,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all contact inquiries (Admin only)
// @route   GET /api/contact
// @access  Private/Admin
export const getInquiries = async (req, res, next) => {
  try {
    const inquiries = await Contact.find().sort({ createdAt: -1 });
    res.status(200).json({
      success: true,
      count: inquiries.length,
      inquiries,
    });
  } catch (error) {
    next(error);
  }
};
