import mongoose from 'mongoose';
import { MenuItem } from '../models/MenuItem.js';
import { SAMPLE_MENU } from '../data/sampleMenu.js';

// In-memory runtime store used when MongoDB is offline
let inMemoryMenu = [...SAMPLE_MENU];

// @desc    Get all menu items with search and category filters
// @route   GET /api/menu
// @access  Public
export const getMenuItems = async (req, res, next) => {
  try {
    const { category, search, veg, popular, all } = req.query;

    // If MongoDB is connected (readyState === 1), query live database
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const query = {};

      if (all !== 'true') {
        query.isAvailable = true;
      }
      if (category && category !== 'All') {
        query.category = category;
      }
      if (veg === 'true') {
        query.isVeg = true;
      } else if (veg === 'false') {
        query.isVeg = false;
      }
      if (popular === 'true') {
        query.isPopular = true;
      }
      if (search && search.trim()) {
        const searchRegex = new RegExp(search.trim(), 'i');
        query.$or = [
          { name: searchRegex },
          { description: searchRegex },
          { tags: searchRegex },
        ];
      }

      const items = await MenuItem.find(query).sort({ category: 1, name: 1 });
      if (items.length > 0) {
        return res.status(200).json({
          success: true,
          count: items.length,
          items,
        });
      }
    }

    // Fast zero-latency fallback from in-memory catalog
    let items = inMemoryMenu.filter((dish) => {
      if (all !== 'true' && !dish.isAvailable) return false;
      if (category && category !== 'All' && dish.category !== category) return false;
      if (veg === 'true' && !dish.isVeg) return false;
      if (veg === 'false' && dish.isVeg) return false;
      if (popular === 'true' && !dish.isPopular) return false;
      if (search && search.trim()) {
        const q = search.trim().toLowerCase();
        const match =
          dish.name.toLowerCase().includes(q) ||
          dish.description.toLowerCase().includes(q) ||
          (dish.tags && dish.tags.some((t) => t.toLowerCase().includes(q)));
        if (!match) return false;
      }
      return true;
    });

    res.status(200).json({
      success: true,
      count: items.length,
      items,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single menu item details
// @route   GET /api/menu/:id
// @access  Public
export const getMenuItemById = async (req, res, next) => {
  try {
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const item = await MenuItem.findById(req.params.id);
      if (item) {
        return res.status(200).json({ success: true, item });
      }
    }

    const fallback = inMemoryMenu.find((m) => m._id === req.params.id || m.dishKey === req.params.id);
    if (!fallback) {
      return res.status(404).json({ success: false, message: 'Menu item not found.' });
    }

    res.status(200).json({ success: true, item: fallback });
  } catch (error) {
    next(error);
  }
};

// @desc    Create menu item
// @route   POST /api/menu
// @access  Private/Admin
export const createMenuItem = async (req, res, next) => {
  try {
    const {
      name,
      dishKey,
      description,
      category,
      price,
      isVeg,
      isAvailable,
      isPopular,
      image,
      emoji,
      gradient,
      spiceLevel,
      prepTime,
      tags,
    } = req.body;

    const generatedKey = (dishKey || name).toLowerCase().replace(/[^a-z0-9]/g, '');

    const newItem = {
      _id: 'dish_' + Date.now(),
      name: name.trim(),
      dishKey: generatedKey,
      description: description.trim(),
      category,
      price: Number(price),
      isVeg: isVeg !== undefined ? isVeg : true,
      isAvailable: isAvailable !== undefined ? isAvailable : true,
      isPopular: isPopular || false,
      image: image || '',
      emoji: emoji || '🍲',
      gradient: gradient || ['#f28c28', '#b3202f'],
      spiceLevel: spiceLevel || 'Medium',
      prepTime: prepTime || '15-20 mins',
      tags: tags || [],
    };

    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const item = await MenuItem.create(newItem);
      return res.status(201).json({ success: true, item });
    }

    inMemoryMenu.unshift(newItem);
    res.status(201).json({ success: true, item: newItem });
  } catch (error) {
    next(error);
  }
};

// @desc    Update menu item
// @route   PUT /api/menu/:id
// @access  Private/Admin
export const updateMenuItem = async (req, res, next) => {
  try {
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const item = await MenuItem.findByIdAndUpdate(req.params.id, req.body, { new: true });
      if (item) return res.status(200).json({ success: true, item });
    }

    const idx = inMemoryMenu.findIndex((m) => m._id === req.params.id);
    if (idx !== -1) {
      inMemoryMenu[idx] = { ...inMemoryMenu[idx], ...req.body };
      return res.status(200).json({ success: true, item: inMemoryMenu[idx] });
    }

    res.status(404).json({ success: false, message: 'Menu item not found.' });
  } catch (error) {
    next(error);
  }
};

// @desc    Toggle menu item availability
// @route   PATCH /api/menu/:id/availability
// @access  Private/Admin
export const toggleMenuItemAvailability = async (req, res, next) => {
  try {
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const item = await MenuItem.findById(req.params.id);
      if (item) {
        item.isAvailable = !item.isAvailable;
        await item.save();
        return res.status(200).json({ success: true, item });
      }
    }

    const idx = inMemoryMenu.findIndex((m) => m._id === req.params.id);
    if (idx !== -1) {
      inMemoryMenu[idx].isAvailable = !inMemoryMenu[idx].isAvailable;
      return res.status(200).json({ success: true, item: inMemoryMenu[idx] });
    }

    res.status(404).json({ success: false, message: 'Menu item not found.' });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete menu item
// @route   DELETE /api/menu/:id
// @access  Private/Admin
export const deleteMenuItem = async (req, res, next) => {
  try {
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      await MenuItem.findByIdAndDelete(req.params.id);
      return res.status(200).json({ success: true, message: 'Dish deleted.' });
    }

    inMemoryMenu = inMemoryMenu.filter((m) => m._id !== req.params.id);
    res.status(200).json({ success: true, message: 'Dish deleted.' });
  } catch (error) {
    next(error);
  }
};
