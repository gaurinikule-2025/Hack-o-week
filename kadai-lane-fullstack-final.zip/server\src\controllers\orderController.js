import mongoose from 'mongoose';
import { Order } from '../models/Order.js';
import { MenuItem } from '../models/MenuItem.js';
import { SAMPLE_MENU } from '../data/sampleMenu.js';
import { generateOrderNumber } from '../utils/referenceGenerator.js';
import {
  RESTAURANT_CONFIG,
  ORDER_STATUSES,
  VALID_STATUS_TRANSITIONS,
} from '../config/constants.js';

let inMemoryOrders = [];

// @desc    Create new order
// @route   POST /api/orders
// @access  Private (Customer)
export const createOrder = async (req, res, next) => {
  try {
    const {
      items,
      orderType,
      deliveryAddress,
      customerPhone,
      customerName,
      specialInstructions,
      paymentMethod,
    } = req.body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Your cart is empty. Please add dishes to place an order.',
      });
    }

    const type = orderType === 'Pickup' ? 'Pickup' : 'Delivery';

    if (type === 'Delivery') {
      if (
        !deliveryAddress ||
        !deliveryAddress.street ||
        !deliveryAddress.street.trim()
      ) {
        return res.status(400).json({
          success: false,
          message: 'Please provide a valid delivery address.',
        });
      }
    }

    let calculatedSubtotal = 0;
    const verifiedItems = [];

    for (const item of items) {
      const menuItemId = item.menuItemId || item._id;
      const quantity = parseInt(item.quantity, 10);

      if (!menuItemId || isNaN(quantity) || quantity <= 0) {
        return res.status(400).json({
          success: false,
          message: 'Invalid item or quantity submitted in cart.',
        });
      }

      let dbDish = null;
      if (mongoose.connection && mongoose.connection.readyState === 1) {
        try {
          dbDish = await MenuItem.findById(menuItemId);
        } catch {}
      }

      if (!dbDish) {
        dbDish = SAMPLE_MENU.find((m) => m._id === menuItemId || m.dishKey === menuItemId);
      }

      if (!dbDish) {
        return res.status(400).json({
          success: false,
          message: `Dish "${item.name || 'Selected item'}" is no longer on our menu.`,
        });
      }

      const itemTotal = dbDish.price * quantity;
      calculatedSubtotal += itemTotal;

      verifiedItems.push({
        menuItem: dbDish._id,
        name: dbDish.name,
        price: dbDish.price,
        quantity,
        isVeg: dbDish.isVeg,
        image: dbDish.image || '',
        itemTotal,
      });
    }

    const gstRate = RESTAURANT_CONFIG.financials.gstRate;
    const tax = Math.round(calculatedSubtotal * gstRate);
    let deliveryFee = 0;

    if (type === 'Delivery') {
      deliveryFee =
        calculatedSubtotal >=
        RESTAURANT_CONFIG.financials.freeDeliveryThreshold
          ? 0
          : RESTAURANT_CONFIG.financials.deliveryFee;
    }

    const finalTotal = calculatedSubtotal + tax + deliveryFee;
    const orderNumber = generateOrderNumber();

    const orderDoc = {
      _id: 'ord_' + Date.now(),
      orderNumber,
      customer: req.user ? req.user._id : 'cust_guest',
      customerName: customerName || (req.user ? req.user.name : 'Customer'),
      customerPhone: customerPhone || (req.user ? req.user.phone : '9823000000'),
      items: verifiedItems,
      orderType: type,
      deliveryAddress:
        type === 'Delivery'
          ? {
              street: deliveryAddress.street.trim(),
              area: deliveryAddress.area || 'Koregaon Park',
              city: deliveryAddress.city || 'Pune',
              pincode: deliveryAddress.pincode || '411001',
              landmark: deliveryAddress.landmark || '',
            }
          : undefined,
      specialInstructions: (specialInstructions || '').trim(),
      subtotal: calculatedSubtotal,
      tax,
      deliveryFee,
      total: finalTotal,
      paymentMethod:
        paymentMethod === 'Pay at Restaurant / Pickup'
          ? 'Pay at Restaurant / Pickup'
          : 'Cash on Delivery',
      paymentStatus: 'Pending',
      orderStatus: ORDER_STATUSES.PENDING,
      statusHistory: [
        {
          status: ORDER_STATUSES.PENDING,
          timestamp: new Date(),
          note: 'Order placed by customer.',
        },
      ],
      createdAt: new Date(),
    };

    if (mongoose.connection && mongoose.connection.readyState === 1) {
      try {
        const saved = await Order.create(orderDoc);
        return res.status(201).json({
          success: true,
          message: `Order #${saved.orderNumber} placed successfully!`,
          orderNumber: saved.orderNumber,
          order: saved,
        });
      } catch (err) {
        console.warn('DB order save failed, falling back to memory store:', err.message);
      }
    }

    inMemoryOrders.unshift(orderDoc);

    res.status(201).json({
      success: true,
      message: `Order #${orderDoc.orderNumber} placed successfully!`,
      orderNumber: orderDoc.orderNumber,
      order: orderDoc,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get customer's orders
// @route   GET /api/orders/my-orders
// @access  Private (Customer)
export const getMyOrders = async (req, res, next) => {
  try {
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const orders = await Order.find({ customer: req.user._id }).sort({ createdAt: -1 });
      if (orders.length > 0) {
        return res.status(200).json({ success: true, count: orders.length, orders });
      }
    }

    res.status(200).json({
      success: true,
      count: inMemoryOrders.length,
      orders: inMemoryOrders,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single order details by ID or OrderNumber
// @route   GET /api/orders/:id
// @access  Private
export const getOrderById = async (req, res, next) => {
  try {
    const query = req.params.id.startsWith('KL-ORD-')
      ? { orderNumber: req.params.id }
      : { _id: req.params.id };

    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const order = await Order.findOne(query);
      if (order) return res.status(200).json({ success: true, order });
    }

    const order = inMemoryOrders.find(
      (o) => o.orderNumber === req.params.id || o._id === req.params.id
    );

    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found.' });
    }

    res.status(200).json({ success: true, order });
  } catch (error) {
    next(error);
  }
};

// @desc    Cancel order
// @route   PATCH /api/orders/:id/cancel
// @access  Private
export const cancelOrder = async (req, res, next) => {
  try {
    const { reason } = req.body;
    let order = null;

    if (mongoose.connection && mongoose.connection.readyState === 1) {
      order = await Order.findById(req.params.id);
      if (order) {
        order.orderStatus = ORDER_STATUSES.CANCELLED;
        order.cancellationReason = reason || 'Cancelled by customer';
        order.statusHistory.push({
          status: ORDER_STATUSES.CANCELLED,
          timestamp: new Date(),
          note: order.cancellationReason,
        });
        await order.save();
        return res.status(200).json({ success: true, order });
      }
    }

    order = inMemoryOrders.find(
      (o) => o._id === req.params.id || o.orderNumber === req.params.id
    );

    if (order) {
      order.orderStatus = ORDER_STATUSES.CANCELLED;
      order.cancellationReason = reason || 'Cancelled by customer';
      return res.status(200).json({ success: true, order });
    }

    res.status(404).json({ success: false, message: 'Order not found.' });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all orders (Admin only)
// @route   GET /api/admin/orders
// @access  Private/Admin
export const getAllOrders = async (req, res, next) => {
  try {
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const orders = await Order.find().sort({ createdAt: -1 });
      if (orders.length > 0) {
        return res.status(200).json({ success: true, count: orders.length, orders });
      }
    }

    res.status(200).json({
      success: true,
      count: inMemoryOrders.length,
      orders: inMemoryOrders,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update order status
// @route   PATCH /api/admin/orders/:id/status
// @access  Private/Admin
export const updateOrderStatus = async (req, res, next) => {
  try {
    const { status, note, paymentStatus } = req.body;

    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const order = await Order.findById(req.params.id);
      if (order) {
        if (status) {
          order.orderStatus = status;
          order.statusHistory.push({
            status,
            timestamp: new Date(),
            note: note || `Updated to ${status}`,
          });
        }
        if (paymentStatus) order.paymentStatus = paymentStatus;
        await order.save();
        return res.status(200).json({ success: true, order });
      }
    }

    const order = inMemoryOrders.find(
      (o) => o._id === req.params.id || o.orderNumber === req.params.id
    );

    if (order) {
      if (status) order.orderStatus = status;
      if (paymentStatus) order.paymentStatus = paymentStatus;
      return res.status(200).json({ success: true, order });
    }

    res.status(404).json({ success: false, message: 'Order not found.' });
  } catch (error) {
    next(error);
  }
};
