import mongoose from 'mongoose';
import { Reservation } from '../models/Reservation.js';
import { generateReservationNumber } from '../utils/referenceGenerator.js';
import { RESTAURANT_CONFIG } from '../config/constants.js';

let inMemoryReservations = [];

const getTodayDateString = () => {
  const d = new Date();
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 10);
};

// @desc    Check available time slots
// @route   GET /api/reservations/availability
// @access  Public
export const checkAvailability = async (req, res, next) => {
  try {
    const { date } = req.query;
    const { timeSlots, slotCapacityGuests } = RESTAURANT_CONFIG.reservationRules;

    let existingBookings = [];
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      try {
        existingBookings = await Reservation.find({
          date,
          status: { $in: ['Pending', 'Confirmed'] },
        });
      } catch {}
    } else {
      existingBookings = inMemoryReservations.filter(
        (r) => r.date === date && ['Pending', 'Confirmed'].includes(r.status)
      );
    }

    const slotBookingsMap = {};
    timeSlots.forEach((slot) => {
      slotBookingsMap[slot] = 0;
    });

    existingBookings.forEach((b) => {
      if (slotBookingsMap[b.time] !== undefined) {
        slotBookingsMap[b.time] += b.guests;
      }
    });

    const slots = timeSlots.map((slot) => {
      const booked = slotBookingsMap[slot] || 0;
      const remaining = Math.max(0, slotCapacityGuests - booked);
      return {
        time: slot,
        bookedGuests: booked,
        remainingCapacity: remaining,
        isAvailable: remaining >= 1,
      };
    });

    res.status(200).json({
      success: true,
      date: date || getTodayDateString(),
      slots,
      operatingHours: RESTAURANT_CONFIG.operatingHours,
      seatingAreas: RESTAURANT_CONFIG.reservationRules.seatingAreas,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Create new table reservation
// @route   POST /api/reservations
// @access  Public
export const createReservation = async (req, res, next) => {
  try {
    const {
      name,
      phone,
      email,
      date,
      time,
      guests,
      seatingArea,
      specialRequests,
    } = req.body;

    const reservationNumber = generateReservationNumber();

    const reservationDoc = {
      _id: 'res_' + Date.now(),
      reservationNumber,
      customer: req.user ? req.user._id : null,
      name: (name || 'Guest').trim(),
      phone: (phone || '9823000000').toString().replace(/\s+/g, ''),
      email: (email || '').trim().toLowerCase(),
      date: date || getTodayDateString(),
      time: time || '19:30',
      guests: parseInt(guests, 10) || 2,
      seatingArea: seatingArea === 'Terrace' ? 'Terrace' : 'Indoor',
      specialRequests: (specialRequests || '').trim(),
      status: 'Confirmed',
      createdAt: new Date(),
    };

    if (mongoose.connection && mongoose.connection.readyState === 1) {
      try {
        const saved = await Reservation.create(reservationDoc);
        return res.status(201).json({
          success: true,
          message: `Table reserved successfully! Your booking reference is #${saved.reservationNumber}.`,
          reservationNumber: saved.reservationNumber,
          reservation: saved,
        });
      } catch (err) {
        console.warn('DB reservation save failed, falling back to memory store:', err.message);
      }
    }

    inMemoryReservations.unshift(reservationDoc);

    res.status(201).json({
      success: true,
      message: `Table reserved successfully! Your booking reference is #${reservationDoc.reservationNumber}.`,
      reservationNumber: reservationDoc.reservationNumber,
      reservation: reservationDoc,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get user's reservations
// @route   GET /api/reservations/my-reservations
// @access  Private
export const getMyReservations = async (req, res, next) => {
  try {
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const reservations = await Reservation.find({
        $or: [{ customer: req.user._id }, { phone: req.user.phone }],
      }).sort({ date: -1 });

      if (reservations.length > 0) {
        return res.status(200).json({ success: true, count: reservations.length, reservations });
      }
    }

    res.status(200).json({
      success: true,
      count: inMemoryReservations.length,
      reservations: inMemoryReservations,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get reservation by ID
// @route   GET /api/reservations/:id
// @access  Public
export const getReservationById = async (req, res, next) => {
  try {
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const reservation = await Reservation.findOne({
        $or: [{ reservationNumber: req.params.id }, { _id: req.params.id }],
      });
      if (reservation) return res.status(200).json({ success: true, reservation });
    }

    const reservation = inMemoryReservations.find(
      (r) => r.reservationNumber === req.params.id || r._id === req.params.id
    );

    if (!reservation) {
      return res.status(404).json({ success: false, message: 'Reservation not found.' });
    }

    res.status(200).json({ success: true, reservation });
  } catch (error) {
    next(error);
  }
};

// @desc    Cancel reservation
// @route   PATCH /api/reservations/:id/cancel
// @access  Private
export const cancelReservation = async (req, res, next) => {
  try {
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const reservation = await Reservation.findById(req.params.id);
      if (reservation) {
        reservation.status = 'Cancelled';
        await reservation.save();
        return res.status(200).json({ success: true, reservation });
      }
    }

    const reservation = inMemoryReservations.find(
      (r) => r._id === req.params.id || r.reservationNumber === req.params.id
    );

    if (reservation) {
      reservation.status = 'Cancelled';
      return res.status(200).json({ success: true, reservation });
    }

    res.status(404).json({ success: false, message: 'Reservation not found.' });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all reservations (Admin only)
// @route   GET /api/admin/reservations
// @access  Private/Admin
export const getAllReservations = async (req, res, next) => {
  try {
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const reservations = await Reservation.find().sort({ date: 1, time: 1 });
      if (reservations.length > 0) {
        return res.status(200).json({ success: true, count: reservations.length, reservations });
      }
    }

    res.status(200).json({
      success: true,
      count: inMemoryReservations.length,
      reservations: inMemoryReservations,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update reservation status
// @route   PATCH /api/admin/reservations/:id/status
// @access  Private/Admin
export const updateReservationStatus = async (req, res, next) => {
  try {
    const { status } = req.body;

    if (mongoose.connection && mongoose.connection.readyState === 1) {
      const reservation = await Reservation.findById(req.params.id);
      if (reservation) {
        reservation.status = status;
        await reservation.save();
        return res.status(200).json({ success: true, reservation });
      }
    }

    const reservation = inMemoryReservations.find(
      (r) => r._id === req.params.id || r.reservationNumber === req.params.id
    );

    if (reservation) {
      reservation.status = status;
      return res.status(200).json({ success: true, reservation });
    }

    res.status(404).json({ success: false, message: 'Reservation not found.' });
  } catch (error) {
    next(error);
  }
};
