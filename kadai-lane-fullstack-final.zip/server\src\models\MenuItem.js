import mongoose from 'mongoose';

const menuItemSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Dish name is required'],
      trim: true,
      maxlength: [80, 'Dish name cannot exceed 80 characters'],
    },
    dishKey: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      lowercase: true,
    },
    description: {
      type: String,
      required: [true, 'Dish description is required'],
      trim: true,
      maxlength: [300, 'Description cannot exceed 300 characters'],
    },
    category: {
      type: String,
      required: [true, 'Category is required'],
      enum: {
        values: ['Starters', 'Mains', 'Breads', 'Rice', 'Desserts', 'Drinks'],
        message: '{VALUE} is not a valid category',
      },
    },
    price: {
      type: Number,
      required: [true, 'Price is required'],
      min: [1, 'Price must be at least ₹1'],
    },
    isVeg: {
      type: Boolean,
      default: true,
    },
    isAvailable: {
      type: Boolean,
      default: true,
    },
    isPopular: {
      type: Boolean,
      default: false,
    },
    image: {
      type: String,
      default: '',
    },
    emoji: {
      type: String,
      default: '🍲',
    },
    gradient: {
      type: [String],
      default: ['#f28c28', '#b3202f'],
    },
    spiceLevel: {
      type: String,
      enum: ['None', 'Mild', 'Medium', 'Spicy', 'Extra Spicy'],
      default: 'Medium',
    },
    prepTime: {
      type: String,
      default: '15-20 mins',
    },
    tags: {
      type: [String],
      default: [],
    },
  },
  {
    timestamps: true,
  }
);

// Indexes for fast searching and category filtering
menuItemSchema.index({ category: 1, isAvailable: 1 });
menuItemSchema.index({ name: 'text', description: 'text', tags: 'text' });

export const MenuItem = mongoose.model('MenuItem', menuItemSchema);
