import mongoose from 'mongoose';

const reservationSchema = new mongoose.Schema(
  {
    reservationNumber: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },
    customer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
      index: true,
    },
    name: {
      type: String,
      required: [true, 'Please provide the guest name'],
      trim: true,
      minlength: [2, 'Name must be at least 2 characters'],
      maxlength: [60, 'Name cannot exceed 60 characters'],
    },
    phone: {
      type: String,
      required: [true, 'Please provide a 10-digit mobile number'],
      trim: true,
      match: [/^\d{10}$/, 'Mobile number must be exactly 10 digits'],
    },
    email: {
      type: String,
      trim: true,
      lowercase: true,
      default: '',
    },
    date: {
      type: String,
      required: [true, 'Reservation date is required (YYYY-MM-DD)'],
      match: [/^\d{4}-\d{2}-\d{2}$/, 'Date must be in YYYY-MM-DD format'],
      index: true,
    },
    time: {
      type: String,
      required: [true, 'Reservation time slot is required (HH:MM)'],
      match: [/^\d{2}:\d{2}$/, 'Time must be in HH:MM format'],
      index: true,
    },
    guests: {
      type: Number,
      required: [true, 'Number of guests is required'],
      min: [1, 'At least 1 guest required'],
      max: [8, 'Maximum 8 guests per online booking. For larger parties, please call us.'],
    },
    seatingArea: {
      type: String,
      enum: ['Indoor', 'Terrace'],
      default: 'Indoor',
    },
    specialRequests: {
      type: String,
      default: '',
      maxlength: [300, 'Special requests cannot exceed 300 characters'],
    },
    status: {
      type: String,
      enum: ['Pending', 'Confirmed', 'Completed', 'Cancelled'],
      default: 'Confirmed',
      index: true,
    },
    cancellationReason: {
      type: String,
      default: '',
    },
  },
  {
    timestamps: true,
  }
);

// Compound index for querying capacity per date and time
reservationSchema.index({ date: 1, time: 1, status: 1 });

export const Reservation = mongoose.model('Reservation', reservationSchema);
