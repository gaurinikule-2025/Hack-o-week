import express from 'express';
import { submitContact, getInquiries } from '../controllers/contactController.js';
import { protect, adminOnly } from '../middleware/auth.js';

const router = express.Router();

router.post('/', submitContact);
router.get('/', protect, adminOnly, getInquiries);

export default router;
