import express from 'express';
import {
  checkAvailability,
  createReservation,
  getMyReservations,
  getReservationById,
  cancelReservation,
  getAllReservations,
  updateReservationStatus,
} from '../controllers/reservationController.js';
import { protect, optionalAuth, adminOnly } from '../middleware/auth.js';

const router = express.Router();

// Public routes
router.get('/availability', checkAvailability);
router.post('/', optionalAuth, createReservation);
router.get('/:id', getReservationById);

// Customer protected routes
router.get('/my/all', protect, getMyReservations);
router.patch('/:id/cancel', protect, cancelReservation);

// Admin protected routes
router.get('/admin/all', protect, adminOnly, getAllReservations);
router.patch('/admin/:id/status', protect, adminOnly, updateReservationStatus);

export default router;
