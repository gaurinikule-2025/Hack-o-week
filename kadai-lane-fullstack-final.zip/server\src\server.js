import dotenv from 'dotenv';
import app from './app.js';
import { connectDB } from './config/db.js';

// Load environment variables
dotenv.config();

const PORT = process.env.PORT || 5000;

const startServer = async () => {
  const server = app.listen(PORT, () => {
    console.log(`\n======================================================`);
    console.log(`🍲 KADAI LANE — Backend API Server Running!`);
    console.log(`📡 URL: http://localhost:${PORT}`);
    console.log(`🩺 Health: http://localhost:${PORT}/api/health`);
    console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
    console.log(`======================================================\n`);
  });

  // Attempt database connection in background
  connectDB().catch((err) => {
    console.warn(`[MongoDB Warning] Initial connection could not be established: ${err.message}`);
  });

  return server;
};

startServer();
