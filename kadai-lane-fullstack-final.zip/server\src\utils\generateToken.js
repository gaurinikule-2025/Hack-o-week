import jwt from 'jsonwebtoken';

export const generateToken = (res, user) => {
  const secret = process.env.JWT_SECRET || 'kadai_lane_super_secret_jwt_key_2026_btech_project';
  const expiresIn = process.env.JWT_EXPIRES_IN || '7d';

  const token = jwt.sign(
    {
      id: user._id,
      email: user.email,
      role: user.role,
    },
    secret,
    { expiresIn }
  );

  // Set HTTP-only cookie
  if (res && res.cookie) {
    res.cookie('token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    });
  }

  return token;
};
