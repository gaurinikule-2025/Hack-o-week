@echo off
title Kadai Lane - Starting Full-Stack Website
echo ======================================================
echo 🍲 Starting Kadai Lane - Modern Indian Kitchen
echo ======================================================

set "PATH=C:\Users\GAURI\.gemini\antigravity\scratch\nodejs;%PATH%"

echo [1/2] Starting Backend API Server on Port 5000...
start "Kadai Lane - Backend Server (Port 5000)" cmd /k "cd /d C:\Users\GAURI\.gemini\antigravity\scratch\kadai-lane\server && npm run dev"

timeout /t 3 /nobreak >nul

echo [2/2] Starting React Frontend on Port 5173...
start "Kadai Lane - React Frontend (Port 5173)" cmd /k "cd /d C:\Users\GAURI\.gemini\antigravity\scratch\kadai-lane\client && npm run dev"

timeout /t 4 /nobreak >nul

echo Opening website in your default browser...
start http://localhost:5173

echo.
echo ======================================================
echo ✅ Kadai Lane is now running!
echo 🌐 Website: http://localhost:5173
echo 📡 Backend: http://localhost:5000
echo ======================================================
pause
